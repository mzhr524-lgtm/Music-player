package com.ali.musicplayer

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

object YamNet {
    private const val RATE = 16000
    private var tried = false
    private var interp: Interpreter? = null
    private var inLen = 15600
    private var outIdx = -1
    private var outType = DataType.FLOAT32
    private var outScale = 1f
    private var outZero = 0
    private var inBuf: ByteBuffer? = null
    private var outBuf: ByteBuffer? = null
    private var dim = 0

    @Synchronized
    fun ready(ctx: Context): Boolean {
        if (!tried) {
            tried = true
            try {
                load(ctx)
            } catch (e: Throwable) {
                interp = null
            }
        }
        return interp != null
    }

    private fun load(ctx: Context) {
        val bytes = ctx.assets.open("yamnet.tflite").use { it.readBytes() }
        val mb = ByteBuffer.allocateDirect(bytes.size).order(ByteOrder.nativeOrder())
        mb.put(bytes)
        mb.rewind()
        val ip = Interpreter(mb, Interpreter.Options().setNumThreads(2))
        val ish = ip.getInputTensor(0).shape()
        if (ish.size == 1 && ish[0] <= 1) {
            ip.resizeInput(0, intArrayOf(15600))
            ip.allocateTensors()
        }
        if (ip.getInputTensor(0).dataType() != DataType.FLOAT32) throw IllegalStateException("input type")
        var n = 1
        for (v in ip.getInputTensor(0).shape()) n *= v
        inLen = n
        var emb = -1
        var sc = -1
        for (i in 0 until ip.outputTensorCount) {
            val sh = ip.getOutputTensor(i).shape()
            val last = if (sh.isNotEmpty()) sh[sh.size - 1] else 0
            if (last == 1024 && emb < 0) emb = i
            if (last == 521 && sc < 0) sc = i
        }
        val idx = if (emb >= 0) emb else sc
        if (idx < 0) throw IllegalStateException("no output")
        outIdx = idx
        val t = ip.getOutputTensor(idx)
        outType = t.dataType()
        outScale = t.quantizationParams().scale
        outZero = t.quantizationParams().zeroPoint
        dim = t.shape()[t.shape().size - 1]
        inBuf = ByteBuffer.allocateDirect(inLen * 4).order(ByteOrder.nativeOrder())
        outBuf = ByteBuffer.allocateDirect(t.numBytes()).order(ByteOrder.nativeOrder())
        interp = ip
    }

    private fun runWindow(w: FloatArray): FloatArray? {
        val ip = interp ?: return null
        val ib = inBuf ?: return null
        val ob = outBuf ?: return null
        ib.rewind()
        ib.asFloatBuffer().put(w, 0, minOf(w.size, inLen))
        ob.rewind()
        ip.runForMultipleInputsOutputs(arrayOf<Any>(ib), hashMapOf<Int, Any>(outIdx to ob))
        ob.rewind()
        val out = FloatArray(dim)
        if (outType == DataType.FLOAT32) {
            ob.asFloatBuffer().get(out)
        } else {
            for (i in 0 until dim) {
                val b = ob.get(i).toInt()
                val v = if (outType == DataType.UINT8) (b and 0xFF) else b
                out[i] = (v - outZero) * outScale
            }
        }
        return out
    }

    @Synchronized
    fun embed(ctx: Context, uri: Uri, durationMs: Long): FloatArray? {
        if (!ready(ctx)) return null
        val fr = if (durationMs > 90_000L) floatArrayOf(0.3f, 0.7f) else floatArrayOf(0.5f)
        val acc = DoubleArray(dim)
        var cnt = 0
        for (f in fr) {
            val dec = decode(ctx, uri, durationMs, f, 8) ?: continue
            val pcm = resample(dec.first, dec.second)
            var off = 0
            while (off + inLen <= pcm.size) {
                val e = runWindow(pcm.copyOfRange(off, off + inLen))
                if (e != null) {
                    for (i in 0 until dim) acc[i] += e[i].toDouble()
                    cnt++
                }
                off += RATE
            }
        }
        if (cnt == 0) return null
        return FloatArray(dim) { (acc[it] / cnt).toFloat() }
    }

    private fun resample(x: FloatArray, sr: Int): FloatArray {
        if (sr == RATE) return x
        val ratio = sr.toDouble() / RATE
        val outN = (x.size / ratio).toInt()
        val out = FloatArray(outN)
        for (i in 0 until outN) {
            val a = (i * ratio).toInt()
            val b = minOf(x.size, maxOf(a + 1, ((i + 1) * ratio).toInt()))
            var s = 0f
            for (k in a until b) s += x[k]
            out[i] = s / (b - a)
        }
        return out
    }

    private fun decode(ctx: Context, uri: Uri, durationMs: Long, frac: Float, seconds: Int): Pair<FloatArray, Int>? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            for (i in 0 until ex.trackCount) {
                val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                if (m.startsWith("audio/")) {
                    track = i
                    break
                }
            }
            if (track < 0) return null
            ex.selectTrack(track)
            val format = ex.getTrackFormat(track)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return null
            var sr = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            if (ch < 1) ch = 1
            if (durationMs > 45_000L) {
                ex.seekTo(maxOf(0L, (durationMs * frac).toLong() - seconds * 500L) * 1000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            }
            val c = MediaCodec.createDecoderByType(mime)
            codec = c
            c.configure(format, null, null, 0)
            c.start()
            val maxSamples = sr * seconds
            val pcm = FloatArray(maxSamples)
            var n = 0
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var guard = 0
            while (!outputDone && n < maxSamples && guard++ < 20000) {
                if (!inputDone) {
                    val ii = c.dequeueInputBuffer(5000)
                    if (ii >= 0) {
                        val buf = c.getInputBuffer(ii)!!
                        val sz = ex.readSampleData(buf, 0)
                        if (sz < 0) {
                            c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            c.queueInputBuffer(ii, 0, sz, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = c.dequeueOutputBuffer(info, 5000)
                if (oi >= 0) {
                    val ob = c.getOutputBuffer(oi)!!
                    ob.position(info.offset)
                    ob.limit(info.offset + info.size)
                    val sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                    val total = sb.remaining()
                    var i = 0
                    while (i + ch <= total && n < maxSamples) {
                        var sum = 0f
                        for (k in 0 until ch) sum += sb.get(i + k)
                        pcm[n++] = sum / ch / 32768f
                        i += ch
                    }
                    c.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = c.outputFormat
                    sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    if (ch < 1) ch = 1
                }
            }
            if (n < sr * 3) return null
            return pcm.copyOf(n) to sr
        } catch (e: Exception) {
            return null
        } finally {
            try { codec?.stop() } catch (e: Exception) { }
            try { codec?.release() } catch (e: Exception) { }
            try { ex.release() } catch (e: Exception) { }
        }
    }

    private fun file(ctx: Context) = File(ctx.filesDir, "yam_v1.bin")

    fun loadAll(ctx: Context): HashMap<Int, FloatArray> {
        val m = HashMap<Int, FloatArray>()
        val f = file(ctx)
        if (!f.exists()) return m
        try {
            DataInputStream(BufferedInputStream(FileInputStream(f), 1 shl 16)).use { ins ->
                while (true) {
                    val key = ins.readInt()
                    val d = ins.readInt()
                    if (d < 0 || d > 4096) break
                    val v = FloatArray(d)
                    for (i in 0 until d) v[i] = ins.readFloat()
                    m[key] = v
                }
            }
        } catch (e: Exception) {
        }
        return m
    }

    fun append(ctx: Context, key: Int, e: FloatArray) {
        try {
            DataOutputStream(BufferedOutputStream(FileOutputStream(file(ctx), true))).use { o ->
                o.writeInt(key)
                o.writeInt(e.size)
                for (v in e) o.writeFloat(v)
            }
        } catch (x: Exception) {
        }
    }

    fun status(ctx: Context, have: Int, total: Int): String {
        if (ready(ctx)) return "الاستماع المتقدم (YAMNet): " + have + " من " + total
        val present = try {
            ctx.assets.list("")?.contains("yamnet.tflite") == true
        } catch (e: Exception) {
            false
        }
        return if (present) "الاستماع المتقدم (YAMNet): الملف موجود بس ما انفتح (نسخة غير مناسبة)"
        else "الاستماع المتقدم (YAMNet): غير مفعّل، ملف yamnet.tflite غير موجود بالتطبيق"
    }
}
