package com.ali.musicplayer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

object AnalysisBridge {
    @Volatile
    var onStop: (() -> Unit)? = null
}

class AnalysisService : Service() {
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            AnalysisBridge.onStop?.invoke()
            stopSelf()
            return START_NOT_STICKY
        }
        val done = intent?.getIntExtra("done", 0) ?: 0
        val total = intent?.getIntExtra("total", 0) ?: 0
        ServiceCompat.startForeground(
            this, NOTIF_ID, build(this, done, total), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )
        if (wake == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val w = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "music:analysis")
            w.acquire(6L * 60L * 60L * 1000L)
            wake = w
        }
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        AnalysisBridge.onStop?.invoke()
        stopSelf()
    }

    override fun onDestroy() {
        try {
            wake?.let { if (it.isHeld) it.release() }
        } catch (e: Exception) {
        }
        wake = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.ali.musicplayer.STOP_ANALYSIS"
        const val NOTIF_ID = 7731
        const val CHANNEL = "analysis"

        fun build(ctx: Context, done: Int, total: Int): Notification {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "تحليل الأغاني", NotificationManager.IMPORTANCE_LOW)
            )
            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
            )
            val stop = PendingIntent.getService(
                ctx, 1, Intent(ctx, AnalysisService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE
            )
            return NotificationCompat.Builder(ctx, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentTitle("جاري الاستماع للأغاني")
                .setContentText(done.toString() + " / " + total)
                .setProgress(maxOf(total, 1), done, false)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(open)
                .addAction(0, "إيقاف", stop)
                .build()
        }

        fun start(ctx: Context, done: Int, total: Int) {
            try {
                ContextCompat.startForegroundService(
                    ctx,
                    Intent(ctx, AnalysisService::class.java).putExtra("done", done).putExtra("total", total)
                )
            } catch (e: Exception) {
            }
        }

        fun update(ctx: Context, done: Int, total: Int) {
            try {
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.notify(NOTIF_ID, build(ctx, done, total))
            } catch (e: Exception) {
            }
        }

        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, AnalysisService::class.java))
            } catch (e: Exception) {
            }
        }
    }
}
