package com.ali.musicplayer

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

object AudioAnalyzer {
    const val D = 12

    fun analyze(ctx: Context, uri: Uri, durationMs: Long): FloatArray? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            for (i in 0 until ex.trackCount) {
                val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                if (m.startsWith("audio/")) {
                    track = i
                    break
                }
            }
            if (track < 0) return null
            ex.selectTrack(track)
            val format = ex.getTrackFormat(track)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return null
            var sr = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            if (ch < 1) ch = 1
            if (durationMs > 45_000L) {
                ex.seekTo((durationMs / 2 - 8_000L) * 1000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            }
            val c = MediaCodec.createDecoderByType(mime)
            codec = c
            c.configure(format, null, null, 0)
            c.start()
            val maxSamples = sr * 15
            val pcm = FloatArray(maxSamples)
            var n = 0
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var guard = 0
            while (!outputDone && n < maxSamples && guard++ < 20000) {
                if (!inputDone) {
                    val ii = c.dequeueInputBuffer(5000)
                    if (ii >= 0) {
                        val buf = c.getInputBuffer(ii)!!
                        val sz = ex.readSampleData(buf, 0)
                        if (sz < 0) {
                            c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            c.queueInputBuffer(ii, 0, sz, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = c.dequeueOutputBuffer(info, 5000)
                if (oi >= 0) {
                    val ob = c.getOutputBuffer(oi)!!
                    ob.position(info.offset)
                    ob.limit(info.offset + info.size)
                    val sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                    val total = sb.remaining()
                    var i = 0
                    while (i + ch <= total && n < maxSamples) {
                        var sum = 0f
                        for (k in 0 until ch) sum += sb.get(i + k)
                        pcm[n++] = sum / ch / 32768f
                        i += ch
                    }
                    c.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = c.outputFormat
                    sr = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    if (ch < 1) ch = 1
                }
            }
            if (n < sr * 3) return null
            return features(pcm, n, sr)
        } catch (e: Exception) {
            return null
        } finally {
            try { codec?.stop() } catch (e: Exception) { }
            try { codec?.release() } catch (e: Exception) { }
            try { ex.release() } catch (e: Exception) { }
        }
    }

    private fun features(x: FloatArray, n: Int, sr: Int): FloatArray? {
        val frame = 1024
        val hop = 512
        val frames = (n - frame) / hop
        if (frames < 40) return null
        val win = FloatArray(frame) { (0.5 - 0.5 * cos(2.0 * Math.PI * it / (frame - 1))).toFloat() }
        val rms = FloatArray(frames)
        val zcr = FloatArray(frames)
        val cent = FloatArray(frames)
        val flux = FloatArray(frames)
        val re = FloatArray(frame)
        val im = FloatArray(frame)
        val prev = FloatArray(frame / 2)
        var eLow = 0.0
        var eMid = 0.0
        var eHigh = 0.0
        val binHz = sr.toFloat() / frame
        for (f in 0 until frames) {
            val off = f * hop
            var s = 0f
            var z = 0
            for (i in 0 until frame) {
                val v = x[off + i]
                s += v * v
                if (i > 0 && ((v >= 0f) != (x[off + i - 1] >= 0f))) z++
                re[i] = v * win[i]
                im[i] = 0f
            }
            rms[f] = sqrt(s / frame)
            zcr[f] = z.toFloat() / frame
            fft(re, im)
            var ms = 0f
            var mc = 0f
            var fl = 0f
            for (k in 1 until frame / 2) {
                val m = sqrt(re[k] * re[k] + im[k] * im[k])
                ms += m
                mc += m * k
                val d = m - prev[k]
                if (d > 0f) fl += d
                prev[k] = m
                val hz = k * binHz
                val e = (m * m).toDouble()
                if (hz < 250f) eLow += e else if (hz < 2000f) eMid += e else eHigh += e
            }
            cent[f] = if (ms > 1e-6f) (mc / ms) * binHz else 0f
            flux[f] = if (ms > 1e-6f) fl / ms else 0f
        }
        val meanRms = rms.average().toFloat()
        if (meanRms < 1e-4f) return null
        val stdRms = sqrt(rms.map { (it - meanRms) * (it - meanRms) }.average()).toFloat()
        val lowRatio = rms.count { it < 0.4f * meanRms }.toFloat() / frames
        val tot = (eLow + eMid + eHigh).coerceAtLeast(1e-9)

        val fps = sr.toFloat() / hop
        val fm = flux.average().toFloat()
        val env = FloatArray(frames) { flux[it] - fm }
        var r0 = 0f
        for (v in env) r0 += v * v
        var bestLag = 0
        var bestR = 0f
        val minLag = (fps * 60f / 180f).toInt().coerceAtLeast(2)
        val maxLag = minOf((fps * 60f / 60f).toInt(), frames / 2)
        for (lag in minLag..maxLag) {
            var r = 0f
            for (i in 0 until frames - lag) r += env[i] * env[i + lag]
            if (r > bestR) {
                bestR = r
                bestLag = lag
            }
        }
        val bpm = if (bestLag > 0) 60f * fps / bestLag else 0f
        val strength = if (r0 > 1e-9f) bestR / r0 else 0f
        val centMean = cent.average().toFloat()
        val centStd = sqrt(cent.map { (it - centMean) * (it - centMean) }.average()).toFloat()
        return floatArrayOf(
            meanRms, stdRms / meanRms, lowRatio, zcr.average().toFloat(), centMean / 1000f, fm,
            (eLow / tot).toFloat(), (eMid / tot).toFloat(), (eHigh / tot).toFloat(),
            bpm, strength, centStd / 1000f
        )
    }

    private fun fft(re: FloatArray, im: FloatArray) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while ((j and bit) != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]
                re[i] = re[j]
                re[j] = tr
                val ti = im[i]
                im[i] = im[j]
                im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = -2.0 * Math.PI / len
            val wr = cos(ang).toFloat()
            val wi = sin(ang).toFloat()
            var i = 0
            while (i < n) {
                var cr = 1f
                var ci = 0f
                val half = len / 2
                for (k in 0 until half) {
                    val ur = re[i + k]
                    val ui = im[i + k]
                    val vr = re[i + k + half] * cr - im[i + k + half] * ci
                    val vi = re[i + k + half] * ci + im[i + k + half] * cr
                    re[i + k] = ur + vr
                    im[i + k] = ui + vi
                    re[i + k + half] = ur - vr
                    im[i + k + half] = ui - vi
                    val ncr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = ncr
                }
                i += len
            }
            len = len shl 1
        }
    }
}
