package com.ali.musicplayer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import kotlin.math.cos
import kotlin.math.sin
import android.content.Context
import android.media.AudioManager
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material.icons.filled.CropSquare
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Switch
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.ui.graphics.toArgb
import androidx.media3.common.Player
import kotlinx.coroutines.delay
import androidx.activity.result.PickVisualMediaRequest
import androidx.compose.foundation.Image
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.draw.blur
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

var Gold by mutableStateOf(Color(0xFFF5B63A))
val Bg = Color(0xFF12142B)
val CardColor = Color(0xFF1E2140)
val Muted = Color(0xFF9AA0C0)

val Categories = listOf(
    "قرآن" to Color(0xFF4CAF7D), "أدعية" to Color(0xFF5BA4E6), "حسينيات" to Color(0xFF8E7CC3),
    "أغاني عراقية" to Color(0xFFE5703E), "أغاني عربية" to Color(0xFFE5B83E), "راب" to Color(0xFFD9534F),
    "موال" to Color(0xFFC77DA5), "شعر" to Color(0xFF3FB6B2), "موسيقى" to Color(0xFF9AA0C0),
    "أغاني أجنبية" to Color(0xFF7DB84C)
)

val AccentColors = listOf(
    Color(0xFFF5B63A), Color(0xFF4CAF7D), Color(0xFF5BA4E6), Color(0xFF8E7CC3),
    Color(0xFFE5703E), Color(0xFFD9534F), Color(0xFFC77DA5), Color(0xFF3FB6B2)
)

fun catColor(name: String?): Color = Categories.firstOrNull { it.first == name }?.second ?: Gold

class MainActivity : ComponentActivity() {
    private val vm: PlayerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Gold = Color(getSharedPreferences("lib", MODE_PRIVATE).getInt("accent", Gold.toArgb()))
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Bg, surface = CardColor)) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Root(vm)
                }
            }
        }
    }
}

fun fmt(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun Root(vm: PlayerViewModel) {
    val ctx = LocalContext.current
    val perms = remember {
        (if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)) + Manifest.permission.RECORD_AUDIO
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (ContextCompat.checkSelfPermission(ctx, perms[0]) == PackageManager.PERMISSION_GRANTED) vm.load()
        if (r[Manifest.permission.RECORD_AUDIO] == true) vm.pingViz()
    }
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(ctx, perms[0]) == PackageManager.PERMISSION_GRANTED) vm.load()
        val missing = perms.filter { ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) launcher.launch(missing.toTypedArray())
    }

    var showFull by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    BackHandler(enabled = showFull) { showFull = false }
    BackHandler(enabled = showSettings && !showFull) { showSettings = false }
    var filter by remember { mutableStateOf("الكل") }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var menuSong by remember { mutableStateOf<Song?>(null) }
    val chips = remember { listOf("الكل", "المفضلة") + Categories.map { it.first } + "غير مصنف" }
    val shownBase = remember(vm.songs, vm.cats, vm.favs, filter) {
        when (filter) {
            "الكل" -> vm.songs
            "المفضلة" -> vm.songs.filter { it.path in vm.favs }
            "غير مصنف" -> vm.songs.filter { it.path !in vm.cats }
            else -> vm.songs.filter { vm.cats[it.path] == filter }
        }
    }
    val shown = remember(shownBase, query) {
        if (query.isBlank()) shownBase
        else shownBase.filter { it.title.contains(query, true) || it.artist.contains(query, true) }
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
        vm.bg?.let { b ->
            Image(
                bitmap = b, contentDescription = null,
                modifier = Modifier.fillMaxSize().blur(vm.bgBlur.dp),
                contentScale = ContentScale.Crop
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 1f - vm.bgBright)))
        }
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "مكتبتي (${shown.size})",
                    color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = {
                    searching = !searching
                    if (!searching) query = ""
                }) {
                    Icon(Icons.Filled.Search, null, tint = if (searching) Gold else Color.White)
                }
                IconButton(onClick = { showSettings = true }) {
                    Icon(Icons.Filled.Settings, null, tint = Color.White)
                }
            }
            if (searching) {
                TextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    placeholder = { Text("ابحث عن أغنية...", color = Muted) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = CardColor, unfocusedContainerColor = CardColor,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Gold
                    ),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(16.dp))
                )
            }
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(chips) { name ->
                    val sel = name == filter
                    Text(
                        name, color = if (sel) Bg else Color.White,
                        modifier = Modifier.clip(RoundedCornerShape(50))
                            .background(if (sel) Gold else CardColor)
                            .clickable { filter = name }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                itemsIndexed(shown, key = { _, s -> s.id }) { i, s ->
                    SongRow(
                        s, s.id == vm.current?.id, s.path in vm.favs, catColor(vm.cats[s.path]),
                        onLong = { menuSong = s }
                    ) { vm.play(shown, i) }
                }
            }
            menuSong?.let { s ->
                AlertDialog(
                    onDismissRequest = { menuSong = null },
                    confirmButton = {},
                    containerColor = CardColor,
                    title = { Text(s.title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                    text = {
                        Column(Modifier.verticalScroll(rememberScrollState())) {
                            Row(
                                Modifier.fillMaxWidth().clickable { vm.toggleFav(s); menuSong = null }
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    if (s.path in vm.favs) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                    null, tint = Color(0xFFE5575F)
                                )
                                Spacer(Modifier.width(10.dp))
                                Text(if (s.path in vm.favs) "إزالة من المفضلة" else "إضافة للمفضلة", color = Color.White)
                            }
                            Categories.forEach { (name, color) ->
                                Text(
                                    name,
                                    color = if (vm.cats[s.path] == name) color else Color.White,
                                    fontWeight = if (vm.cats[s.path] == name) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.fillMaxWidth()
                                        .clickable { vm.setCategory(s, name); menuSong = null }
                                        .padding(vertical = 10.dp)
                                )
                            }
                            Text(
                                "إزالة التصنيف", color = Muted,
                                modifier = Modifier.fillMaxWidth()
                                    .clickable { vm.setCategory(s, null); menuSong = null }
                                    .padding(vertical = 10.dp)
                            )
                        }
                    }
                )
            }
            if (vm.current != null) MiniPlayer(vm) { showFull = true }
        }
        AnimatedVisibility(
            visible = showFull,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            NowPlaying(vm) { showFull = false }
        }
        AnimatedVisibility(
            visible = showSettings,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            SettingsScreen(vm) { showSettings = false }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SongRow(s: Song, active: Boolean, fav: Boolean, color: Color, onLong: () -> Unit, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLong).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(if (active) color else CardColor),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.MusicNote, null, tint = if (active) Bg else color)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                s.title, color = if (active) Gold else Color.White,
                fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            if (s.artist.isNotBlank())
                Text(s.artist, color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (fav) {
            Icon(Icons.Filled.Favorite, null, tint = Color(0xFFE5575F), modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(fmt(s.durationMs), color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun MiniPlayer(vm: PlayerViewModel, onOpen: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(20.dp))
            .background(CardColor).clickable(onClick = onOpen).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            vm.current?.title ?: "", color = Color.White,
            modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis
        )
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = vm::prev) { Icon(Icons.Filled.SkipPrevious, null, tint = Color.White) }
            IconButton(onClick = vm::toggle) {
                Icon(
                    if (vm.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null,
                    tint = Gold, modifier = Modifier.size(32.dp)
                )
            }
            IconButton(onClick = vm::next) { Icon(Icons.Filled.SkipNext, null, tint = Color.White) }
          }
        }
    }
}

@Composable
fun Pill(text: String, on: Boolean = false, onClick: () -> Unit) {
    Text(
        text, color = if (on) Bg else Color.White, fontSize = 14.sp,
        modifier = Modifier.clip(RoundedCornerShape(50))
            .background(if (on) Gold else Color(0x33FFFFFF))
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

@Composable
fun NowPlaying(vm: PlayerViewModel, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat() }
    var vol by remember { mutableStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(500)
            vol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
        }
    }
    val scale by animateFloatAsState(
        if (vm.playing) 1f else 0.9f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "cover"
    )
    val top by animateColorAsState(vm.artColor, label = "bg")
    val shape = if (vm.coverSquare) RoundedCornerShape(28.dp) else CircleShape
    var showVol by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(top, Bg)))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.KeyboardArrowDown, null, tint = Color.White, modifier = Modifier.size(32.dp))
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { showVol = !showVol }) {
                Icon(Icons.Filled.VolumeUp, null, tint = if (showVol) Gold else Color.White)
            }
            IconButton(onClick = vm::toggleCover) {
                Icon(
                    if (vm.coverSquare) Icons.Filled.RadioButtonUnchecked else Icons.Filled.CropSquare,
                    null, tint = Color.White
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        val bands = Spectrum.bands
        val accent = Gold
        Box(Modifier.fillMaxWidth(0.94f).aspectRatio(1f), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val w = size.minDimension
                val cx = size.width / 2f
                val cy = size.height / 2f
                val start = w * (if (vm.coverSquare) 0.40f else 0.285f)
                val maxLen = w * (if (vm.coverSquare) 0.09f else 0.20f)
                val count = 64
                val pi = Math.PI.toFloat()
                for (i in 0 until count) {
                    val band = if (i < 32) i else 63 - i
                    val lvl = if (vm.playing) bands[band] else 0f
                    val len = maxLen * (0.06f + 0.94f * lvl)
                    val ang = (i.toFloat() / count) * 2f * pi - pi / 2f
                    val c = cos(ang)
                    val s = sin(ang)
                    drawLine(
                        accent.copy(alpha = 0.35f + 0.65f * lvl),
                        Offset(cx + c * start, cy + s * start),
                        Offset(cx + c * (start + len), cy + s * (start + len)),
                        strokeWidth = w * 0.012f,
                        cap = StrokeCap.Round
                    )
                }
            }
            Box(
                Modifier.fillMaxWidth(0.55f).aspectRatio(1f).scale(scale).clip(shape)
                    .background(Brush.linearGradient(listOf(Gold, Color(0xFFB5473A)))),
                contentAlignment = Alignment.Center
            ) {
                val a = vm.art
                if (a != null) {
                    Image(
                        bitmap = a, contentDescription = null,
                        modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(Icons.Filled.MusicNote, null, tint = Bg, modifier = Modifier.size(64.dp))
                }
            }
        }
        Spacer(Modifier.height(28.dp))
        Text(
            vm.current?.title ?: "", color = Color.White, fontSize = 22.sp,
            fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis
        )
        Text(vm.current?.artist ?: "", color = Muted)
        Spacer(Modifier.height(16.dp))
        LtrSlider(vm.position.toFloat(), 0f..maxOf(1f, vm.duration.toFloat()), { vm.seek(it.toLong()) })
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(fmt(vm.position), color = Muted, fontSize = 12.sp)
                Text(fmt(vm.duration), color = Muted, fontSize = 12.sp)
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = vm::toggleShuffle) {
                    Icon(Icons.Filled.Shuffle, null, tint = if (vm.shuffle) Gold else Muted)
                }
                IconButton(onClick = vm::prev) {
                    Icon(Icons.Filled.SkipPrevious, null, tint = Color.White, modifier = Modifier.size(40.dp))
                }
                FilledIconButton(onClick = vm::toggle, modifier = Modifier.size(72.dp)) {
                    Icon(
                        if (vm.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null,
                        modifier = Modifier.size(40.dp)
                    )
                }
                IconButton(onClick = vm::next) {
                    Icon(Icons.Filled.SkipNext, null, tint = Color.White, modifier = Modifier.size(40.dp))
                }
                IconButton(onClick = vm::cycleRepeat) {
                    Icon(
                        if (vm.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                        null, tint = if (vm.repeatMode == Player.REPEAT_MODE_OFF) Muted else Gold
                    )
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Pill("-" + vm.skipSec + " ث") { vm.skip(-1) }
            Pill("+" + vm.skipSec + " ث") { vm.skip(1) }
            Pill("إيقاف بعد الأغنية", vm.sleepEndOfSong) {
                if (vm.sleepEndOfSong) vm.cancelSleep() else vm.sleepAfterSong()
            }
        }
        Spacer(Modifier.height(16.dp))
        AnimatedVisibility(visible = showVol, enter = fadeIn(), exit = fadeOut()) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                    .background(Color(0x33FFFFFF)).padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.VolumeDown, null, tint = Color.White)
                Box(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                    LtrSlider(vol, 0f..maxVol, {
                        vol = it
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, it.toInt(), 0)
                    })
                }
                Icon(Icons.Filled.VolumeUp, null, tint = Color.White)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun Section(t: String) {
    Text(t, color = Gold, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 24.dp, bottom = 8.dp))
}

@Composable
fun ChipsRow(opts: List<Pair<String, () -> Unit>>) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(opts) { (label, act) ->
            Text(
                label, color = Color.White,
                modifier = Modifier.clip(RoundedCornerShape(50)).background(CardColor)
                    .clickable(onClick = act).padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }
    }
}

@Composable
fun LtrSlider(
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    onFinished: (() -> Unit)? = null
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Slider(value = value, onValueChange = onChange, valueRange = range, onValueChangeFinished = onFinished)
    }
}

@Composable
fun SettingsScreen(vm: PlayerViewModel, onClose: () -> Unit) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.setBgFromUri(uri)
    }
    var minTmp by remember { mutableStateOf(vm.minSec.toFloat()) }
    val presets = listOf(
        "عادي" to listOf(0, 0, 0, 0, 0),
        "جهير" to listOf(700, 500, 0, -100, 0),
        "صوت بشري" to listOf(-300, 0, 400, 500, 200),
        "راب" to listOf(600, 400, 0, 300, 400),
        "هادئ" to listOf(200, 200, 0, -200, -300)
    )
    val freqs = listOf("60 هرتز", "230", "910", "3.6 ك", "14 ك")
    Column(
        Modifier.fillMaxSize().background(Bg)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .verticalScroll(rememberScrollState()).padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "الإعدادات", color = Color.White, fontSize = 22.sp,
                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.KeyboardArrowDown, null, tint = Color.White, modifier = Modifier.size(32.dp))
            }
        }

        Section(
            "مؤقت النوم" + when {
                vm.sleepLeft > 0 -> " (باقي " + fmt(vm.sleepLeft * 1000) + ")"
                vm.sleepEndOfSong -> " (بعد هذه الأغنية)"
                else -> ""
            }
        )
        ChipsRow(
            listOf(
                "15 دقيقة" to { vm.startSleep(15) },
                "30 دقيقة" to { vm.startSleep(30) },
                "45 دقيقة" to { vm.startSleep(45) },
                "ساعة" to { vm.startSleep(60) },
                "بعد الأغنية الحالية" to { vm.sleepAfterSong() },
                "إلغاء" to { vm.cancelSleep() }
            )
        )

        Section("معادل الصوت")
        ChipsRow(presets.map { (name, lv) -> name to { vm.setEq(lv) } })
        vm.eqLevels.forEachIndexed { i, lv ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(freqs[i], color = Muted, fontSize = 12.sp, modifier = Modifier.width(64.dp))
                Box(Modifier.weight(1f)) {
                    LtrSlider(lv.toFloat(), -1500f..1500f, { v ->
                        vm.setEq(vm.eqLevels.toMutableList().also { it[i] = v.toInt() })
                    })
                }
            }
        }

        Section("خلفية التطبيق")
        ChipsRow(
            buildList<Pair<String, () -> Unit>> {
                add("اختيار صورة" to {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                })
                if (vm.bg != null) add("إزالة الصورة" to { vm.clearBg() })
            }
        )
        if (vm.bg != null) {
            Text("السطوع", color = Muted, fontSize = 12.sp)
            LtrSlider(vm.bgBright, 0.1f..1f, { vm.updateBright(it) })
            Text("التغويش", color = Muted, fontSize = 12.sp)
            LtrSlider(vm.bgBlur, 0f..25f, { vm.updateBlur(it) })
        }

        Section("إخفاء الأغاني الأقصر من " + minTmp.toInt() + " ثانية")
        LtrSlider(minTmp, 0f..180f, { minTmp = it }, { vm.updateMinSec(minTmp.toInt()) })

        Section("لون التطبيق")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(AccentColors) { c ->
                Box(Modifier.size(40.dp).clip(CircleShape).background(c).clickable { vm.saveAccent(c) })
            }
        }

        Section("قفزة التقديم والتأخير")
        ChipsRow(listOf(10, 15, 30).map { n -> (n.toString() + " ثانية") to { vm.updateSkip(n) } })

        Section("المجلدات")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "إخفاء تسجيلات واتساب والمسجلات تلقائياً", color = Color.White,
                modifier = Modifier.weight(1f)
            )
            Switch(checked = vm.autoVoice, onCheckedChange = { vm.updateAutoVoice(it) })
        }
        vm.folderStats().forEach { (dir, n) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(dir.substringAfterLast('/'), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(n.toString() + " أغنية", color = Muted, fontSize = 12.sp)
                }
                Switch(checked = !vm.dirHidden(dir), onCheckedChange = { vm.toggleDir(dir) })
            }
        }
        Spacer(Modifier.height(40.dp))
    }
}
