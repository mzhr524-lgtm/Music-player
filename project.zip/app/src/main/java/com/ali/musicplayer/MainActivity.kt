package com.ali.musicplayer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalView
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.Subject
import androidx.compose.material.icons.filled.Timer
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Send
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import kotlinx.coroutines.launch
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.filled.Brightness3
import androidx.compose.ui.text.style.TextAlign
import android.app.Activity
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.foundation.Canvas
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import kotlin.math.cos
import kotlin.math.sin
import android.content.Context
import android.media.AudioManager
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material.icons.filled.CropSquare
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Switch
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.ui.graphics.toArgb
import androidx.media3.common.Player
import kotlinx.coroutines.delay
import androidx.activity.result.PickVisualMediaRequest
import androidx.compose.foundation.Image
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.draw.blur
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

var Gold by mutableStateOf(Color(0xFFF5B63A))
val Bg = Color(0xFF12142B)
val CardColor = Color(0xFF1E2140)
val Muted = Color(0xFF9AA0C0)

val Categories = listOf(
    "قرآن" to Color(0xFF4CAF7D), "أدعية" to Color(0xFF5BA4E6), "حسينيات" to Color(0xFF8E7CC3),
    "أغاني عراقية" to Color(0xFFE5703E), "أغاني عربية" to Color(0xFFE5B83E), "راب" to Color(0xFFD9534F),
    "موال" to Color(0xFFC77DA5), "شعر" to Color(0xFF3FB6B2), "موسيقى" to Color(0xFF9AA0C0),
    "أغاني أجنبية" to Color(0xFF7DB84C)
)

val AccentColors = listOf(
    Color(0xFFF5B63A), Color(0xFF4CAF7D), Color(0xFF5BA4E6), Color(0xFF8E7CC3),
    Color(0xFFE5703E), Color(0xFFD9534F), Color(0xFFC77DA5), Color(0xFF3FB6B2)
)

val MuharramCats = setOf("حسينيات", "قرآن", "أدعية")

fun catColor(name: String?): Color = Categories.firstOrNull { it.first == name }?.second ?: Gold

class MainActivity : ComponentActivity() {
    private val vm: PlayerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Gold = Color(getSharedPreferences("lib", MODE_PRIVATE).getInt("accent", Gold.toArgb()))
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Bg, surface = CardColor)) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Root(vm)
                }
            }
        }
    }
}

fun fmt(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun Root(vm: PlayerViewModel) {
    val ctx = LocalContext.current
    val perms = remember {
        (if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)) + Manifest.permission.RECORD_AUDIO
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (ContextCompat.checkSelfPermission(ctx, perms[0]) == PackageManager.PERMISSION_GRANTED) vm.load()
        if (r[Manifest.permission.RECORD_AUDIO] == true) vm.pingViz()
    }
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(ctx, perms[0]) == PackageManager.PERMISSION_GRANTED) vm.load()
        val missing = perms.filter { ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) launcher.launch(missing.toTypedArray())
    }

    var showFull by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    BackHandler(enabled = showFull) { showFull = false }
    BackHandler(enabled = showSettings && !showFull) { showSettings = false }
    var filter by remember { mutableStateOf("الكل") }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var menuSong by remember { mutableStateOf<Song?>(null) }
    var selected by remember { mutableStateOf(setOf<Long>()) }
    var batchDialog by remember { mutableStateOf(false) }
    var showDups by remember { mutableStateOf(false) }
    var showSmart by remember { mutableStateOf(false) }
    var showAssistant by remember { mutableStateOf(false) }
    var moodDialog by remember { mutableStateOf(false) }
    BackHandler(enabled = showDups) { showDups = false }
    BackHandler(enabled = showSmart) { showSmart = false }
    BackHandler(enabled = showAssistant) { showAssistant = false }
    LaunchedEffect(vm.nav) {
        when (vm.nav) {
            "settings" -> {
                showAssistant = false
                showSettings = true
            }
            "smart" -> {
                showAssistant = false
                showSmart = true
            }
            "dups" -> {
                showAssistant = false
                showDups = true
            }
        }
        if (vm.nav != null) vm.clearNav()
    }
    BackHandler(enabled = selected.isNotEmpty()) { selected = emptySet() }
    val deleter = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            selected = emptySet()
            vm.load()
        }
    }
    fun deleteSongs(list: List<Song>) {
        if (list.isEmpty()) return
        if (Build.VERSION.SDK_INT >= 30) {
            val pi = MediaStore.createDeleteRequest(ctx.contentResolver, list.map { it.uri })
            deleter.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } else {
            try {
                list.forEach { ctx.contentResolver.delete(it.uri, null, null) }
                selected = emptySet()
                vm.load()
            } catch (e: Exception) {
                Toast.makeText(ctx, "تعذر الحذف", Toast.LENGTH_SHORT).show()
            }
        }
    }
    fun shareSong(s: Song) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "audio/*"
            putExtra(Intent.EXTRA_STREAM, s.uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, null))
    }
    fun setRingtone(s: Song) {
        if (!android.provider.Settings.System.canWrite(ctx)) {
            Toast.makeText(ctx, "فعّل الإذن ثم ارجع واضغط مرة ثانية", Toast.LENGTH_LONG).show()
            ctx.startActivity(
                Intent(
                    android.provider.Settings.ACTION_MANAGE_WRITE_SETTINGS,
                    Uri.parse("package:" + ctx.packageName)
                ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return
        }
        try {
            RingtoneManager.setActualDefaultRingtoneUri(ctx, RingtoneManager.TYPE_RINGTONE, s.uri)
            Toast.makeText(ctx, "تم تعيينها كنغمة رنين", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(ctx, "تعذر تعيين النغمة", Toast.LENGTH_SHORT).show()
        }
    }
    val chips = remember(vm.muharram) {
        if (vm.muharram) listOf("الكل", "المفضلة", "قرآن", "أدعية", "حسينيات")
        else listOf("الكل", "المفضلة", "الأكثر سماعاً") + Categories.map { it.first } + "غير مصنف"
    }
    LaunchedEffect(vm.muharram) { filter = "الكل" }
    val songsNow = remember(vm.songs, vm.cats, vm.muharram) {
        if (vm.muharram) vm.songs.filter { x -> vm.cats[x.path]?.let { it in MuharramCats } == true } else vm.songs
    }
    val shownBase = remember(songsNow, vm.cats, vm.favs, filter, vm.plays) {
        when (filter) {
            "الكل" -> songsNow
            "المفضلة" -> songsNow.filter { it.path in vm.favs }
            "غير مصنف" -> songsNow.filter { it.path !in vm.cats }
            "الأكثر سماعاً" -> songsNow.filter { vm.playCount(it) > 0 }.sortedByDescending { vm.playCount(it) }
            "قرآن" -> vm.sortQuran(songsNow.filter { vm.cats[it.path] == "قرآن" })
            else -> songsNow.filter { vm.cats[it.path] == filter }
        }
    }
    val shown = remember(shownBase, query) {
        if (query.isBlank()) shownBase
        else shownBase.filter { it.title.contains(query, true) || it.artist.contains(query, true) }
    }
    val counts = remember(vm.songs, vm.cats, vm.favs, vm.plays) {
        val m = HashMap<String, Int>()
        m["الكل"] = vm.songs.size
        m["المفضلة"] = vm.songs.count { it.path in vm.favs }
        m["غير مصنف"] = vm.songs.count { it.path !in vm.cats }
        m["الأكثر سماعاً"] = vm.songs.count { vm.playCount(it) > 0 }
        for (x in vm.songs) {
            val c = vm.cats[x.path]
            if (c != null) m[c] = (m[c] ?: 0) + 1
        }
        m
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
        vm.bg?.let { b ->
            Image(
                bitmap = b, contentDescription = null,
                modifier = Modifier.fillMaxSize().blur(vm.bgBlur.dp),
                contentScale = ContentScale.Crop
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 1f - vm.bgBright)))
        }
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "مكتبتي (${shown.size})", color = Color.White, fontSize = 20.sp,
                    fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f)
                )
                HeaderIcon(Icons.Filled.AutoAwesome, Gold) { showAssistant = true }
                HeaderIcon(Icons.Filled.Mood, Color.White) { moodDialog = true }
                HeaderIcon(Icons.Filled.Brightness3, if (vm.muharram) Gold else Color.White) { vm.toggleMuharram() }
                HeaderIcon(Icons.Filled.Search, if (searching) Gold else Color.White) {
                    searching = !searching
                    if (!searching) query = ""
                }
                HeaderIcon(Icons.Filled.Settings, Color.White) { showSettings = true }
            }
            if (selected.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${selected.size} محدد", color = Gold, fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    Pill("تصنيف") { batchDialog = true }
                    Pill("الكل") { selected = shown.map { it.id }.toSet() }
                    Pill("حذف") { deleteSongs(shown.filter { it.id in selected }) }
                    Pill("إلغاء") { selected = emptySet() }
                }
            }
            if (searching) {
                TextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    placeholder = { Text("ابحث عن أغنية...", color = Muted) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = CardColor, unfocusedContainerColor = CardColor,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Gold
                    ),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(16.dp))
                )
            }
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(chips) { name ->
                    val sel = name == filter
                    Text(
                        name + " (" + (counts[name] ?: 0) + ")", color = if (sel) Bg else Color.White,
                        modifier = Modifier.clip(RoundedCornerShape(50))
                            .background(if (sel) Gold else CardColor)
                            .clickable { filter = name }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            val listState = rememberLazyListState()
            LaunchedEffect(filter, query) { listState.scrollToItem(0) }
            Box(Modifier.weight(1f)) {
            LazyColumn(
                Modifier.fillMaxSize(), state = listState,
                contentPadding = PaddingValues(end = 22.dp)
            ) {
                itemsIndexed(shown, key = { _, s -> s.id }) { i, s ->
                    SongRow(
                        s, s.id == vm.current?.id, s.path in vm.favs, catColor(vm.cats[s.path]),
                        selected = s.id in selected,
                        divider = vm.dividers,
                        onMore = { menuSong = s },
                        onLong = { selected = selected + s.id }
                    ) {
                        if (selected.isNotEmpty()) {
                            selected = if (s.id in selected) selected - s.id else selected + s.id
                        } else {
                            vm.play(shown, i)
                        }
                    }
                }
            }
            FastScroller(
                listState, shown.size,
                { i -> shown.getOrNull(i)?.title?.trim()?.take(1)?.uppercase() ?: "" },
                Modifier.align(Alignment.CenterEnd)
            )
            }
            menuSong?.let { s ->
                AlertDialog(
                    onDismissRequest = { menuSong = null },
                    confirmButton = {},
                    containerColor = CardColor,
                    title = { Text(s.title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                    text = {
                        Column(Modifier.verticalScroll(rememberScrollState())) {
                            Text(
                                "سمعتها " + vm.playCount(s) + " مرة" +
                                    (if (vm.lastPlayedAt(s) > 0) {
                                        "، آخر مرة " + java.text.SimpleDateFormat("d/M HH:mm", java.util.Locale.US)
                                            .format(java.util.Date(vm.lastPlayedAt(s)))
                                    } else ""),
                                color = Muted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp)
                            )
                            Text("المزاج", color = Muted, fontSize = 12.sp)
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.padding(bottom = 8.dp)
                            ) {
                                items(MoodNames) { m ->
                                    Pill(m, m in vm.songMoodSet(s)) { vm.toggleSongMood(s, m) }
                                }
                            }
                            Row(
                                Modifier.fillMaxWidth().clickable { vm.toggleFav(s); menuSong = null }
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    if (s.path in vm.favs) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                    null, tint = Color(0xFFE5575F)
                                )
                                Spacer(Modifier.width(10.dp))
                                Text(if (s.path in vm.favs) "إزالة من المفضلة" else "إضافة للمفضلة", color = Color.White)
                            }
                            Categories.forEach { (name, color) ->
                                Text(
                                    name,
                                    color = if (vm.cats[s.path] == name) color else Color.White,
                                    fontWeight = if (vm.cats[s.path] == name) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.fillMaxWidth()
                                        .clickable { vm.setCategory(s, name); menuSong = null }
                                        .padding(vertical = 10.dp)
                                )
                            }
                            Text(
                                "إزالة التصنيف", color = Muted,
                                modifier = Modifier.fillMaxWidth()
                                    .clickable { vm.setCategory(s, null); menuSong = null }
                                    .padding(vertical = 10.dp)
                            )
                            Text(
                                "مشاركة", color = Color.White,
                                modifier = Modifier.fillMaxWidth()
                                    .clickable { shareSong(s); menuSong = null }
                                    .padding(vertical = 10.dp)
                            )
                            Text(
                                "تعيين كنغمة رنين", color = Color.White,
                                modifier = Modifier.fillMaxWidth()
                                    .clickable { setRingtone(s); menuSong = null }
                                    .padding(vertical = 10.dp)
                            )
                            Text(
                                "حذف", color = Color(0xFFE5575F),
                                modifier = Modifier.fillMaxWidth()
                                    .clickable { deleteSongs(listOf(s)); menuSong = null }
                                    .padding(vertical = 10.dp)
                            )
                        }
                    }
                )
            }
            if (moodDialog) {
                AlertDialog(
                    onDismissRequest = { moodDialog = false },
                    confirmButton = {},
                    containerColor = CardColor,
                    title = { Text("شغّل حسب المزاج") },
                    text = {
                        Column {
                            MoodNames.forEach { m ->
                                val cnt = vm.moodSongs(m).size
                                Text(
                                    m + " (" + cnt + ")",
                                    color = if (cnt > 0) Color.White else Muted, fontSize = 18.sp,
                                    modifier = Modifier.fillMaxWidth()
                                        .clickable(enabled = cnt > 0) {
                                            vm.playMood(m)
                                            moodDialog = false
                                        }
                                        .padding(vertical = 12.dp)
                                )
                            }
                            Text(
                                "تغيّر الأقسام من الإعدادات، ومزاج أي أغنية من قائمة ⋮",
                                color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                    }
                )
            }
            if (batchDialog) {
                AlertDialog(
                    onDismissRequest = { batchDialog = false },
                    confirmButton = {},
                    containerColor = CardColor,
                    title = { Text("تصنيف " + selected.size + " أغنية") },
                    text = {
                        Column(Modifier.verticalScroll(rememberScrollState())) {
                            Categories.forEach { (name, _) ->
                                Text(
                                    name, color = Color.White,
                                    modifier = Modifier.fillMaxWidth()
                                        .clickable {
                                            vm.setCategoryMany(shown.filter { it.id in selected }, name)
                                            batchDialog = false
                                            selected = emptySet()
                                        }
                                        .padding(vertical = 10.dp)
                                )
                            }
                            Text(
                                "إضافة للمفضلة", color = Color.White,
                                modifier = Modifier.fillMaxWidth()
                                    .clickable {
                                        vm.favMany(shown.filter { it.id in selected }, true)
                                        batchDialog = false
                                        selected = emptySet()
                                    }
                                    .padding(vertical = 10.dp)
                            )
                            Text(
                                "إزالة التصنيف", color = Muted,
                                modifier = Modifier.fillMaxWidth()
                                    .clickable {
                                        vm.setCategoryMany(shown.filter { it.id in selected }, null)
                                        batchDialog = false
                                        selected = emptySet()
                                    }
                                    .padding(vertical = 10.dp)
                            )
                        }
                    }
                )
            }
            if (vm.current != null) MiniPlayer(vm) { showFull = true }
        }
        AnimatedVisibility(
            visible = showFull,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            NowPlaying(vm) { showFull = false }
        }
        AnimatedVisibility(
            visible = showSettings,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            SettingsScreen(vm, onDups = { showDups = true }, onSmart = { showSmart = true }) { showSettings = false }
        }
        AnimatedVisibility(
            visible = showDups,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            DuplicatesScreen(vm, onDelete = { deleteSongs(it) }) { showDups = false }
        }
        AnimatedVisibility(
            visible = showSmart,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            SmartScreen(vm) { showSmart = false }
        }
        AnimatedVisibility(
            visible = showAssistant,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            AssistantScreen(vm) { showAssistant = false }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SongRow(
    s: Song, active: Boolean, fav: Boolean, color: Color, selected: Boolean, divider: Boolean,
    onMore: () -> Unit, onLong: () -> Unit, onClick: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().background(if (selected) Color(0x33FFFFFF) else Color.Transparent)
            .drawBehind {
                if (divider) {
                    val y = size.height - 1f
                    drawLine(
                        Color(0x26FFFFFF), Offset(24.dp.toPx(), y),
                        Offset(size.width - 78.dp.toPx(), y), strokeWidth = 1f
                    )
                }
            }
            .combinedClickable(onClick = onClick, onLongClick = onLong).padding(start = 20.dp, end = 8.dp, top = 12.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(if (active) color else CardColor),
            contentAlignment = Alignment.Center
        ) {
            Icon(if (selected) Icons.Filled.Check else Icons.Filled.MusicNote, null, tint = if (active) Bg else color)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                s.title, color = if (active) Gold else Color.White,
                fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            if (s.artist.isNotBlank())
                Text(s.artist, color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (fav) {
            Icon(Icons.Filled.Favorite, null, tint = Color(0xFFE5575F), modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(fmt(s.durationMs), color = Muted, fontSize = 12.sp)
        IconButton(onClick = onMore, modifier = Modifier.size(36.dp)) {
            Icon(Icons.Filled.MoreVert, null, tint = Muted)
        }
    }
}

@Composable
fun MiniPlayer(vm: PlayerViewModel, onOpen: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(20.dp))
            .background(CardColor).clickable(onClick = onOpen).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            vm.current?.title ?: "", color = Color.White,
            modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis
        )
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = vm::prev) { Icon(Icons.Filled.SkipPrevious, null, tint = Color.White) }
            IconButton(onClick = vm::toggle) {
                Icon(
                    if (vm.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null,
                    tint = Gold, modifier = Modifier.size(32.dp)
                )
            }
            IconButton(onClick = vm::next) { Icon(Icons.Filled.SkipNext, null, tint = Color.White) }
          }
        }
    }
}

@Composable
fun Pill(text: String, on: Boolean = false, onClick: () -> Unit) {
    Text(
        text, color = if (on) Bg else Color.White, fontSize = 14.sp,
        modifier = Modifier.clip(RoundedCornerShape(50))
            .background(if (on) Gold else Color(0x33FFFFFF))
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp)
    )
}

@Composable
fun NowPlaying(vm: PlayerViewModel, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVol = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat() }
    var vol by remember { mutableStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(500)
            vol = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
        }
    }
    val scale by animateFloatAsState(
        if (vm.playing) 1f else 0.9f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "cover"
    )
    val top by animateColorAsState(vm.artColor, label = "bg")
    val shape = if (vm.coverSquare) RoundedCornerShape(28.dp) else CircleShape
    var showVol by remember { mutableStateOf(false) }
    var showLyrics by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf(0) }
    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(top, Bg)))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.KeyboardArrowDown, null, tint = Color.White, modifier = Modifier.size(32.dp))
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = vm::toggleCover) {
                Icon(
                    if (vm.coverSquare) Icons.Filled.RadioButtonUnchecked else Icons.Filled.CropSquare,
                    null, tint = Color.White
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        if (showLyrics) {
            LyricsPanel(vm)
        } else {
        val bands = Spectrum.bands
        val accent = Gold
        Box(Modifier.fillMaxWidth(0.94f).aspectRatio(1f), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val w = size.minDimension
                val cx = size.width / 2f
                val cy = size.height / 2f
                val start = w * (if (vm.coverSquare) 0.40f else 0.285f)
                val maxLen = w * (if (vm.coverSquare) 0.09f else 0.20f)
                val count = 64
                val pi = Math.PI.toFloat()
                for (i in 0 until count) {
                    val band = if (i < 32) i else 63 - i
                    val lvl = if (vm.playing) bands[band] else 0f
                    val len = maxLen * (0.06f + 0.94f * lvl)
                    val ang = (i.toFloat() / count) * 2f * pi - pi / 2f
                    val c = cos(ang)
                    val s = sin(ang)
                    drawLine(
                        accent.copy(alpha = 0.35f + 0.65f * lvl),
                        Offset(cx + c * start, cy + s * start),
                        Offset(cx + c * (start + len), cy + s * (start + len)),
                        strokeWidth = w * 0.012f,
                        cap = StrokeCap.Round
                    )
                }
            }
            Box(
                Modifier.fillMaxWidth(0.55f).aspectRatio(1f).scale(scale).clip(shape)
                    .background(Brush.linearGradient(listOf(Gold, Color(0xFFB5473A)))),
                contentAlignment = Alignment.Center
            ) {
                val a = vm.art
                if (a != null) {
                    Image(
                        bitmap = a, contentDescription = null,
                        modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(Icons.Filled.MusicNote, null, tint = Bg, modifier = Modifier.size(64.dp))
                }
            }
        }
        }
        Spacer(Modifier.height(28.dp))
        Text(
            vm.current?.title ?: "", color = Color.White, fontSize = 22.sp,
            fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis
        )
        Text(vm.current?.artist ?: "", color = Muted)
        vm.current?.let { Text("سمعتها " + vm.playCount(it) + " مرة", color = Muted, fontSize = 12.sp) }
        Spacer(Modifier.height(16.dp))
        LtrSlider(vm.position.toFloat(), 0f..maxOf(1f, vm.duration.toFloat()), { vm.seek(it.toLong()) })
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(fmt(vm.position), color = Muted, fontSize = 12.sp)
                Text(fmt(vm.duration), color = Muted, fontSize = 12.sp)
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = vm::toggleShuffle) {
                    Icon(Icons.Filled.Shuffle, null, tint = if (vm.shuffle) Gold else Muted)
                }
                IconButton(onClick = vm::prev) {
                    Icon(Icons.Filled.SkipPrevious, null, tint = Color.White, modifier = Modifier.size(40.dp))
                }
                FilledIconButton(onClick = vm::toggle, modifier = Modifier.size(72.dp)) {
                    Icon(
                        if (vm.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null,
                        modifier = Modifier.size(40.dp)
                    )
                }
                IconButton(onClick = vm::next) {
                    Icon(Icons.Filled.SkipNext, null, tint = Color.White, modifier = Modifier.size(40.dp))
                }
                IconButton(onClick = vm::cycleRepeat) {
                    Icon(
                        if (vm.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                        null, tint = if (vm.repeatMode == Player.REPEAT_MODE_OFF) Muted else Gold
                    )
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ToolButton(onClick = { vm.skip(-1) }) {
                Text("-" + vm.skipSec, color = Color.White, fontSize = 12.sp)
            }
            ToolButton(onClick = { vm.skip(1) }) {
                Text("+" + vm.skipSec, color = Color.White, fontSize = 12.sp)
            }
            ToolButton(vm.speed != 1f, { vm.cycleSpeed() }) {
                Text(
                    vm.speed.toString().removeSuffix(".0") + "x",
                    color = if (vm.speed != 1f) Bg else Color.White, fontSize = 12.sp
                )
            }
            ToolButton(vm.sleepLeft > 0 || vm.sleepEndOfSong, { panel = 2 }) {
                Icon(
                    Icons.Filled.Timer, null,
                    tint = if (vm.sleepLeft > 0 || vm.sleepEndOfSong) Bg else Color.White
                )
            }
            ToolButton(showVol, { showVol = !showVol }) {
                Icon(Icons.Filled.VolumeUp, null, tint = if (showVol) Bg else Color.White)
            }
            ToolButton(false, { panel = 1 }) {
                Icon(Icons.Filled.GraphicEq, null, tint = Color.White)
            }
            ToolButton(showLyrics, { showLyrics = !showLyrics }) {
                Icon(Icons.Filled.Subject, null, tint = if (showLyrics) Bg else Color.White)
            }
        }
        if (panel == 1) {
            AlertDialog(
                onDismissRequest = { panel = 0 },
                containerColor = CardColor,
                title = { Text("معادل الصوت") },
                text = { EqPanel(vm) },
                confirmButton = { Pill("تم", true) { panel = 0 } }
            )
        }
        if (panel == 2) {
            AlertDialog(
                onDismissRequest = { panel = 0 },
                containerColor = CardColor,
                title = { Text("مؤقت النوم") },
                text = { SleepPanel(vm) },
                confirmButton = { Pill("تم", true) { panel = 0 } }
            )
        }
        Spacer(Modifier.height(16.dp))
        AnimatedVisibility(visible = showVol, enter = fadeIn(), exit = fadeOut()) {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                    .background(Color(0x33FFFFFF)).padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.VolumeDown, null, tint = Color.White)
                Box(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                    LtrSlider(vol, 0f..maxVol, {
                        vol = it
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, it.toInt(), 0)
                    })
                }
                Icon(Icons.Filled.VolumeUp, null, tint = Color.White)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun Section(t: String) {
    Text(t, color = Gold, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 24.dp, bottom = 8.dp))
}

@Composable
fun ChipsRow(opts: List<Pair<String, () -> Unit>>) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(opts) { (label, act) ->
            Text(
                label, color = Color.White,
                modifier = Modifier.clip(RoundedCornerShape(50)).background(CardColor)
                    .clickable(onClick = act).padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }
    }
}

@Composable
fun LtrSlider(
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
    onFinished: (() -> Unit)? = null
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Slider(value = value, onValueChange = onChange, valueRange = range, onValueChangeFinished = onFinished)
    }
}

@Composable
fun SettingsScreen(vm: PlayerViewModel, onDups: () -> Unit, onSmart: () -> Unit, onClose: () -> Unit) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.setBgFromUri(uri)
    }
    var minTmp by remember { mutableStateOf(vm.minSec.toFloat()) }
    var open by remember { mutableStateOf(setOf<String>()) }
    fun tog(k: String) {
        open = if (k in open) open - k else open + k
    }
    Column(
        Modifier.fillMaxSize().background(Bg)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .verticalScroll(rememberScrollState()).padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "الإعدادات", color = Color.White, fontSize = 22.sp,
                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.KeyboardArrowDown, null, tint = Color.White, modifier = Modifier.size(32.dp))
            }
        }
        Text(
            "المعادل ومؤقت النوم والسرعة صارت داخل شاشة التشغيل.",
            color = Muted, fontSize = 12.sp
        )

        Group("المظهر", "ui" in open, { tog("ui") }) {
            Section("لون التطبيق")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(AccentColors) { c ->
                    Box(Modifier.size(40.dp).clip(CircleShape).background(c).clickable { vm.saveAccent(c) })
                }
            }
            Section("خلفية التطبيق")
            ChipsRow(
                buildList<Pair<String, () -> Unit>> {
                    add("اختيار صورة" to {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    })
                    if (vm.bg != null) add("إزالة الصورة" to { vm.clearBg() })
                }
            )
            if (vm.bg != null) {
                Text("السطوع", color = Muted, fontSize = 12.sp)
                LtrSlider(vm.bgBright, 0.1f..1f, { vm.updateBright(it) })
                Text("التغويش", color = Muted, fontSize = 12.sp)
                LtrSlider(vm.bgBlur, 0f..25f, { vm.updateBlur(it) })
            }
            Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("خطوط فاصلة بين الأغاني", color = Color.White, modifier = Modifier.weight(1f))
                Switch(checked = vm.dividers, onCheckedChange = { vm.toggleDividers() })
            }
        }

        Group("التشغيل", "play" in open, { tog("play") }) {
            Section("قفزة التقديم والتأخير")
            ChipsRow(listOf(10, 15, 30).map { n -> (n.toString() + " ثانية") to { vm.updateSkip(n) } })
            Section(
                "تذكر موضع التشغيل (" +
                    (if (vm.resumeMin == 0) "إيقاف" else vm.resumeMin.toString() + " د") + ")"
            )
            ChipsRow(
                listOf(
                    "إيقاف" to { vm.updateResume(0) },
                    "أطول من 5 دقائق" to { vm.updateResume(5) },
                    "أطول من 10 دقائق" to { vm.updateResume(10) },
                    "أطول من 20 دقيقة" to { vm.updateResume(20) }
                )
            )
            Section("إخفاء الأغاني الأقصر من " + minTmp.toInt() + " ثانية")
            LtrSlider(minTmp, 0f..180f, { minTmp = it }, { vm.updateMinSec(minTmp.toInt()) })
        }

        Group("المزاج", "mood" in open, { tog("mood") }) {
            Text(
                "حدد أي أقسام تدخل بكل مزاج. ومزاج أي أغنية تغيره من قائمة ⋮ الخاصة بيها.",
                color = Muted, fontSize = 12.sp
            )
            MoodNames.forEach { mood ->
                Section(mood)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(Categories.map { it.first }) { c ->
                        Pill(c, c in (vm.moodMap[mood] ?: emptySet())) { vm.toggleMoodCat(mood, c) }
                    }
                }
            }
        }

        Group("المكتبة", "lib" in open, { tog("lib") }) {
            ChipsRow(
                listOf(
                    "فحص التخزين (أغاني ناقصة)" to { vm.rescan() },
                    "المكرر (" + vm.dupGroups.size + ")" to { onDups() },
                    "التصنيف الذكي" to { onSmart() }
                )
            )
            Section("المجلدات")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "إخفاء تسجيلات واتساب والمسجلات تلقائياً", color = Color.White,
                    modifier = Modifier.weight(1f)
                )
                Switch(checked = vm.autoVoice, onCheckedChange = { vm.updateAutoVoice(it) })
            }
            vm.folderStats().forEach { (dir, n) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(dir.substringAfterLast('/'), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(n.toString() + " أغنية", color = Muted, fontSize = 12.sp)
                    }
                    Switch(checked = !vm.dirHidden(dir), onCheckedChange = { vm.toggleDir(dir) })
                }
            }
        }
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
fun DuplicatesScreen(vm: PlayerViewModel, onDelete: (List<Song>) -> Unit, onClose: () -> Unit) {
    val extras = vm.dupGroups.flatMap { g -> g.drop(1) }
    Column(
        Modifier.fillMaxSize().background(Bg)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "الأغاني المكررة", color = Color.White, fontSize = 22.sp,
                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.KeyboardArrowDown, null, tint = Color.White, modifier = Modifier.size(32.dp))
            }
        }
        Text(
            vm.dupGroups.size.toString() + " مجموعة، " + extras.size + " نسخة زائدة. " +
                "تبقى نسخة واحدة من كل مجموعة (✓) وتُحذف الباقي (✗).",
            color = Muted, fontSize = 13.sp
        )
        Spacer(Modifier.height(12.dp))
        if (extras.isNotEmpty()) {
            Pill("حذف كل النسخ الزائدة (" + extras.size + ")", true) { onDelete(extras) }
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(vm.dupGroups) { g ->
                Column(Modifier.padding(vertical = 8.dp)) {
                    g.forEachIndexed { i, s ->
                        Text(
                            (if (i == 0) "✓ " else "✗ ") + s.title,
                            color = if (i == 0) Color.White else Muted,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            s.path.removePrefix("/storage/emulated/0/"),
                            color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LyricsPanel(vm: PlayerViewModel) {
    val lines = vm.lyricLines
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importLyrics(uri)
    }
    var paste by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    Column(Modifier.fillMaxWidth().height(340.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        if (lines.isEmpty()) {
            Spacer(Modifier.weight(1f))
            Text("ماكو كلمات لهذي الأغنية", color = Muted)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("لصق كلمات") { paste = true }
                Pill("اختيار ملف") { picker.launch(arrayOf("*/*")) }
            }
            Spacer(Modifier.weight(1f))
        } else {
            val synced = lines.any { it.first >= 0 }
            val idx = if (synced) lines.indexOfLast { it.first in 0..vm.position } else -1
            val state = rememberLazyListState()
            LaunchedEffect(idx) {
                if (idx >= 0) state.animateScrollToItem(maxOf(0, idx - 2))
            }
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = state) {
                itemsIndexed(lines) { i, l ->
                    Text(
                        l.second,
                        color = if (i == idx) Gold else Color.White.copy(alpha = 0.8f),
                        fontSize = if (i == idx) 20.sp else 17.sp,
                        fontWeight = if (i == idx) FontWeight.Bold else FontWeight.Normal,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Pill("حذف الكلمات") { vm.clearLyrics() }
        }
    }
    if (paste) {
        AlertDialog(
            onDismissRequest = { paste = false },
            containerColor = CardColor,
            title = { Text("الصق الكلمات هنا") },
            text = {
                TextField(
                    value = text, onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth().height(220.dp)
                )
            },
            confirmButton = {
                Pill("حفظ", true) {
                    if (text.isNotBlank()) vm.saveLyrics(text)
                    paste = false
                    text = ""
                }
            }
        )
    }
}

@Composable
fun SmartScreen(vm: PlayerViewModel, onClose: () -> Unit) {
    var thr by remember { mutableStateOf(0.9f) }
    val view = LocalView.current
    DisposableEffect(vm.analyzing) {
        view.keepScreenOn = vm.analyzing
        onDispose { view.keepScreenOn = false }
    }
    val count = vm.suggestions.count { it.conf >= thr }
    Column(
        Modifier.fillMaxSize().background(Bg)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .padding(20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "التصنيف الذكي", color = Color.White, fontSize = 22.sp,
                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.KeyboardArrowDown, null, tint = Color.White, modifier = Modifier.size(32.dp))
            }
        }
        Text(
            "يتعلم من الأغاني اللي صنفتها (العنوان، الفنان، المجلد، اللغة، المدة) ويقترح تصنيف الباقي.",
            color = Muted, fontSize = 13.sp
        )
        Spacer(Modifier.height(12.dp))
        Text("1) الاستماع للصوت", color = Gold, fontWeight = FontWeight.Bold)
        Text(
            "يحلل مقطع من كل أغنية (الإيقاع، قوة الصوت، نوع الصوت). لازم تبقي التطبيق مفتوح والشاشة شغالة حتى يخلص، ويكمل من وين وقف.",
            color = Muted, fontSize = 12.sp
        )
        Text(vm.audioStatus(), color = Color.White, fontSize = 13.sp)
        if (vm.analyzing) {
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { vm.analysisDone.toFloat() / maxOf(1, vm.analysisTotal) },
                color = Gold, modifier = Modifier.fillMaxWidth()
            )
            Text(vm.analysisDone.toString() + " / " + vm.analysisTotal, color = Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.height(6.dp))
        Pill(if (vm.analyzing) "إيقاف الاستماع" else "ابدأ الاستماع", !vm.analyzing) {
            if (vm.analyzing) vm.stopAnalysis() else vm.startAnalysis()
        }
        Spacer(Modifier.height(14.dp))
        Text("2) التدريب والاقتراحات", color = Gold, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Pill(if (vm.smartBusy) "جاري التحليل..." else "درّب وحلّل", true) {
            if (!vm.smartBusy) vm.runSmart()
        }
        if (vm.smartInfo.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Text(vm.smartInfo, color = Color.White, fontSize = 13.sp)
        }
        if (vm.suggestions.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text("حد الثقة: " + (thr * 100).toInt() + "%", color = Gold)
            LtrSlider(thr, 0.5f..0.99f, { thr = it })
            Pill("قبول " + count + " اقتراح") { vm.acceptSuggestions(thr.toDouble()) }
            Spacer(Modifier.height(8.dp))
            Text("اضغط على أي أغنية لقبول اقتراحها لحالها", color = Muted, fontSize = 12.sp)
            LazyColumn(Modifier.weight(1f)) {
                items(vm.suggestions) { sg ->
                    Column(
                        Modifier.fillMaxWidth().clickable { vm.acceptSuggestion(sg) }.padding(vertical = 8.dp)
                    ) {
                        Text(sg.song.title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            sg.cat + "  •  " + (sg.conf * 100).toInt() + "%",
                            color = catColor(sg.cat), fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FastScroller(state: LazyListState, total: Int, label: (Int) -> String, modifier: Modifier = Modifier) {
    if (total < 12) return
    var dragging by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    BoxWithConstraints(modifier.fillMaxHeight().width(30.dp)) {
        val trackPx = with(density) { maxHeight.toPx() }
        val thumbPx = with(density) { 56.dp.toPx() }
        val frac = (state.firstVisibleItemIndex.toFloat() / maxOf(1, total - 1)).coerceIn(0f, 1f)
        val offsetDp = with(density) { (frac * (trackPx - thumbPx)).toDp() }
        Box(
            Modifier.fillMaxSize().pointerInput(total, trackPx) {
                detectVerticalDragGestures(
                    onDragStart = { dragging = true },
                    onDragEnd = { dragging = false },
                    onDragCancel = { dragging = false }
                ) { change, _ ->
                    change.consume()
                    val f = ((change.position.y - thumbPx / 2f) / (trackPx - thumbPx)).coerceIn(0f, 1f)
                    scope.launch { state.scrollToItem((f * (total - 1)).toInt()) }
                }
            }
        )
        Box(
            Modifier.align(Alignment.TopEnd).offset(y = offsetDp).padding(end = 4.dp)
                .width(6.dp).height(56.dp).clip(RoundedCornerShape(3.dp))
                .background(if (dragging) Gold else Color(0x66FFFFFF))
        )
        if (dragging) {
            Box(
                Modifier.align(Alignment.TopEnd).offset(x = 40.dp, y = offsetDp)
                    .size(52.dp).clip(CircleShape).background(Gold),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label(state.firstVisibleItemIndex), color = Bg,
                    fontSize = 22.sp, fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun AssistantScreen(vm: PlayerViewModel, onClose: () -> Unit) {
    var text by remember { mutableStateOf("") }
    val state = rememberLazyListState()
    LaunchedEffect(vm.chat.size) {
        if (vm.chat.isNotEmpty()) state.animateScrollToItem(vm.chat.size - 1)
    }
    val quick = listOf(
        "هاي الأغنية كم مرة سمعتها؟", "شنو أكثر أغاني سمعتها؟", "شنو أكثر قسم أسمعه؟",
        "أغاني ما سمعتها", "شنو سمعت اليوم؟", "شنو أسمع بالليل؟", "شغل لي قرآن", "شنو تتذكر عني؟",
        "شغل المعادل صوت بشري", "نوّمني بعد 30 دقيقة", "شغل لي شي حزين", "خلي السرعة 1.5"
    )
    Column(
        Modifier.fillMaxSize().background(Bg)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "المساعد", color = Color.White, fontSize = 22.sp,
                fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.KeyboardArrowDown, null, tint = Color.White, modifier = Modifier.size(32.dp))
            }
        }
        if (vm.chat.isEmpty()) {
            Text(
                "اسألني عن سماعك وأغانيك بلهجتك. اضغط على أي اقتراح تحت أو اكتب سؤالك.",
                color = Muted, fontSize = 13.sp
            )
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = state) {
            itemsIndexed(vm.chat) { _, m ->
                val mine = m.first
                Box(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    contentAlignment = if (mine) Alignment.CenterStart else Alignment.CenterEnd
                ) {
                    Text(
                        m.second, color = if (mine) Bg else Color.White,
                        modifier = Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(16.dp))
                            .background(if (mine) Gold else CardColor).padding(12.dp)
                    )
                }
            }
        }
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(vertical = 6.dp)
        ) {
            items(quick) { q -> Pill(q) { vm.ask(q) } }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextField(
                value = text, onValueChange = { text = it }, singleLine = true,
                placeholder = { Text("اكتب سؤالك...", color = Muted) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = CardColor, unfocusedContainerColor = CardColor,
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Gold
                ),
                modifier = Modifier.weight(1f).clip(RoundedCornerShape(24.dp))
            )
            IconButton(onClick = {
                vm.ask(text)
                text = ""
            }) {
                Icon(Icons.Filled.Send, null, tint = Gold)
            }
        }
    }
}

@Composable
fun HeaderIcon(icon: ImageVector, tint: Color, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(40.dp)) {
        Icon(icon, null, tint = tint)
    }
}

@Composable
fun ToolButton(on: Boolean = false, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.size(42.dp).clip(CircleShape)
            .background(if (on) Gold else Color(0x22FFFFFF)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}

@Composable
fun EqPanel(vm: PlayerViewModel) {
    val freqs = listOf("60 هرتز", "230", "910", "3.6 ك", "14 ك")
    Column {
        ChipsRow(EqPresets.map { (name, lv) -> name to { vm.setEq(lv) } })
        Spacer(Modifier.height(8.dp))
        vm.eqLevels.forEachIndexed { i, lv ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(freqs[i], color = Muted, fontSize = 12.sp, modifier = Modifier.width(64.dp))
                Box(Modifier.weight(1f)) {
                    LtrSlider(lv.toFloat(), -1500f..1500f, { v ->
                        vm.setEq(vm.eqLevels.toMutableList().also { it[i] = v.toInt() })
                    })
                }
            }
        }
    }
}

@Composable
fun SleepPanel(vm: PlayerViewModel) {
    Column {
        Text(
            when {
                vm.sleepLeft > 0 -> "باقي " + fmt(vm.sleepLeft * 1000)
                vm.sleepEndOfSong -> "راح يطفي بعد هذه الأغنية"
                else -> "المؤقت مطفّى"
            },
            color = Gold
        )
        Spacer(Modifier.height(8.dp))
        ChipsRow(
            listOf(
                "15 دقيقة" to { vm.startSleep(15) },
                "30 دقيقة" to { vm.startSleep(30) },
                "45 دقيقة" to { vm.startSleep(45) },
                "ساعة" to { vm.startSleep(60) },
                "بعد الأغنية الحالية" to { vm.sleepAfterSong() },
                "إلغاء" to { vm.cancelSleep() }
            )
        )
    }
}

@Composable
fun Group(title: String, open: Boolean, onToggle: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(top = 12.dp).clip(RoundedCornerShape(16.dp)).background(CardColor)
    ) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                title, color = Color.White, fontWeight = FontWeight.Bold,
                fontSize = 16.sp, modifier = Modifier.weight(1f)
            )
            Icon(if (open) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown, null, tint = Muted)
        }
        if (open) {
            Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 16.dp), content = content)
        }
    }
}
