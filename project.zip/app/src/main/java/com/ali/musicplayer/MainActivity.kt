package com.ali.musicplayer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

val Gold = Color(0xFFF5B63A)
val Bg = Color(0xFF12142B)
val CardColor = Color(0xFF1E2140)
val Muted = Color(0xFF9AA0C0)

val Categories = listOf(
    "قرآن" to Color(0xFF4CAF7D), "أدعية" to Color(0xFF5BA4E6), "حسينيات" to Color(0xFF8E7CC3),
    "أغاني عراقية" to Color(0xFFE5703E), "أغاني عربية" to Color(0xFFE5B83E), "راب" to Color(0xFFD9534F),
    "موال" to Color(0xFFC77DA5), "شعر" to Color(0xFF3FB6B2), "موسيقى" to Color(0xFF9AA0C0),
    "أغاني أجنبية" to Color(0xFF7DB84C)
)

fun catColor(name: String?): Color = Categories.firstOrNull { it.first == name }?.second ?: Gold

class MainActivity : ComponentActivity() {
    private val vm: PlayerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Bg, surface = CardColor)) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Root(vm)
                }
            }
        }
    }
}

fun fmt(ms: Long): String {
    val s = ms / 1000
    return "%d:%02d".format(s / 60, s % 60)
}

@Composable
fun Root(vm: PlayerViewModel) {
    val ctx = LocalContext.current
    val perms = remember {
        if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[perms[0]] == true) vm.load()
    }
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(ctx, perms[0]) == PackageManager.PERMISSION_GRANTED) vm.load()
        else launcher.launch(perms)
    }

    var showFull by remember { mutableStateOf(false) }
    BackHandler(enabled = showFull) { showFull = false }
    var filter by remember { mutableStateOf("الكل") }
    var menuSong by remember { mutableStateOf<Song?>(null) }
    val chips = remember { listOf("الكل", "المفضلة") + Categories.map { it.first } + "غير مصنف" }
    val shown = remember(vm.songs, vm.cats, vm.favs, filter) {
        when (filter) {
            "الكل" -> vm.songs
            "المفضلة" -> vm.songs.filter { it.path in vm.favs }
            "غير مصنف" -> vm.songs.filter { it.path !in vm.cats }
            else -> vm.songs.filter { vm.cats[it.path] == filter }
        }
    }

    Box(Modifier.fillMaxSize().background(Bg)) {
        Column(Modifier.fillMaxSize()) {
            Text(
                "مكتبتي (${shown.size})",
                color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 16.dp)
            )
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(chips) { name ->
                    val sel = name == filter
                    Text(
                        name, color = if (sel) Bg else Color.White,
                        modifier = Modifier.clip(RoundedCornerShape(50))
                            .background(if (sel) Gold else CardColor)
                            .clickable { filter = name }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                itemsIndexed(shown, key = { _, s -> s.id }) { i, s ->
                    SongRow(
                        s, s.id == vm.current?.id, s.path in vm.favs, catColor(vm.cats[s.path]),
                        onLong = { menuSong = s }
                    ) { vm.play(shown, i) }
                }
            }
            menuSong?.let { s ->
                AlertDialog(
                    onDismissRequest = { menuSong = null },
                    confirmButton = {},
                    containerColor = CardColor,
                    title = { Text(s.title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                    text = {
                        Column(Modifier.verticalScroll(rememberScrollState())) {
                            Row(
                                Modifier.fillMaxWidth().clickable { vm.toggleFav(s); menuSong = null }
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    if (s.path in vm.favs) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                    null, tint = Color(0xFFE5575F)
                                )
                                Spacer(Modifier.width(10.dp))
                                Text(if (s.path in vm.favs) "إزالة من المفضلة" else "إضافة للمفضلة", color = Color.White)
                            }
                            Categories.forEach { (name, color) ->
                                Text(
                                    name,
                                    color = if (vm.cats[s.path] == name) color else Color.White,
                                    fontWeight = if (vm.cats[s.path] == name) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.fillMaxWidth()
                                        .clickable { vm.setCategory(s, name); menuSong = null }
                                        .padding(vertical = 10.dp)
                                )
                            }
                            Text(
                                "إزالة التصنيف", color = Muted,
                                modifier = Modifier.fillMaxWidth()
                                    .clickable { vm.setCategory(s, null); menuSong = null }
                                    .padding(vertical = 10.dp)
                            )
                        }
                    }
                )
            }
            if (vm.current != null) MiniPlayer(vm) { showFull = true }
        }
        AnimatedVisibility(
            visible = showFull,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            NowPlaying(vm) { showFull = false }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SongRow(s: Song, active: Boolean, fav: Boolean, color: Color, onLong: () -> Unit, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLong).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(if (active) color else CardColor),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.MusicNote, null, tint = if (active) Bg else color)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                s.title, color = if (active) Gold else Color.White,
                fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            if (s.artist.isNotBlank())
                Text(s.artist, color = Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (fav) {
            Icon(Icons.Filled.Favorite, null, tint = Color(0xFFE5575F), modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(fmt(s.durationMs), color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun MiniPlayer(vm: PlayerViewModel, onOpen: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(20.dp))
            .background(CardColor).clickable(onClick = onOpen).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            vm.current?.title ?: "", color = Color.White,
            modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis
        )
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = vm::prev) { Icon(Icons.Filled.SkipPrevious, null, tint = Color.White) }
            IconButton(onClick = vm::toggle) {
                Icon(
                    if (vm.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null,
                    tint = Gold, modifier = Modifier.size(32.dp)
                )
            }
            IconButton(onClick = vm::next) { Icon(Icons.Filled.SkipNext, null, tint = Color.White) }
          }
        }
    }
}

@Composable
fun NowPlaying(vm: PlayerViewModel, onClose: () -> Unit) {
    val scale by animateFloatAsState(
        if (vm.playing) 1f else 0.88f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "disc"
    )
    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF3A2A5E), Bg)))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth()) {
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.KeyboardArrowDown, null, tint = Color.White, modifier = Modifier.size(32.dp))
            }
        }
        Spacer(Modifier.weight(1f))
        Box(
            Modifier.size(260.dp).scale(scale).clip(CircleShape)
                .background(Brush.linearGradient(listOf(Gold, Color(0xFFB5473A)))),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.MusicNote, null, tint = Bg, modifier = Modifier.size(100.dp))
        }
        Spacer(Modifier.height(32.dp))
        Text(
            vm.current?.title ?: "", color = Color.White, fontSize = 22.sp,
            fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis
        )
        Text(vm.current?.artist ?: "", color = Muted)
        Spacer(Modifier.height(24.dp))
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Slider(
                value = vm.position.toFloat(),
                onValueChange = { vm.seek(it.toLong()) },
                valueRange = 0f..maxOf(1f, vm.duration.toFloat())
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(fmt(vm.position), color = Muted, fontSize = 12.sp)
                Text(fmt(vm.duration), color = Muted, fontSize = 12.sp)
            }
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(24.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = vm::prev) {
                    Icon(Icons.Filled.SkipPrevious, null, tint = Color.White, modifier = Modifier.size(40.dp))
                }
                FilledIconButton(onClick = vm::toggle, modifier = Modifier.size(72.dp)) {
                    Icon(
                        if (vm.playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, null,
                        modifier = Modifier.size(40.dp)
                    )
                }
                IconButton(onClick = vm::next) {
                    Icon(Icons.Filled.SkipNext, null, tint = Color.White, modifier = Modifier.size(40.dp))
                }
            }
        }
        Spacer(Modifier.weight(1f))
    }
}
