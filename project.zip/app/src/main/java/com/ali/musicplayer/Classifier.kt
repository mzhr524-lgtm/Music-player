package com.ali.musicplayer

import java.io.File
import kotlin.math.exp
import kotlin.math.ln

data class Suggestion(val song: Song, val cat: String, val conf: Double)

fun normAr(t: String): String {
    val sb = StringBuilder()
    for (ch in t) {
        when {
            ch in '\u064B'..'\u0652' || ch == '\u0670' || ch == '\u0640' -> {}
            ch == 'أ' || ch == 'إ' || ch == 'آ' || ch == 'ٱ' -> sb.append('ا')
            ch == 'ة' -> sb.append('ه')
            ch == 'ى' -> sb.append('ي')
            else -> sb.append(ch)
        }
    }
    return sb.toString()
}

fun tokenize(s: Song): List<String> {
    val out = ArrayList<String>()
    val splitter = Regex("[^\\p{L}\\p{N}]+")
    fun add(prefix: String, text: String) {
        val clean = normAr(text.lowercase())
        for (w in clean.split(splitter)) {
            if (w.length >= 2 && !w.all { it.isDigit() }) out.add(prefix + w)
        }
    }
    add("", s.title)
    add("a:", s.artist)
    add("f:", File(s.path).parent?.substringAfterLast('/') ?: "")
    add("n:", File(s.path).nameWithoutExtension)
    val letters = s.title.filter { it.isLetter() }
    val ar = letters.count { it in '\u0600'..'\u06FF' }
    val la = letters.count { it in 'a'..'z' || it in 'A'..'Z' }
    out.add(
        when {
            letters.isEmpty() -> "script:none"
            ar > la -> "script:ar"
            la > ar -> "script:la"
            else -> "script:mix"
        }
    )
    val m = s.durationMs / 60000
    out.add(
        "dur:" + when {
            m < 1 -> "0"
            m < 3 -> "1"
            m < 6 -> "3"
            m < 15 -> "6"
            else -> "15"
        }
    )
    return out
}

class NbModel {
    private val docCount = HashMap<String, Int>()
    private val tokCount = HashMap<String, HashMap<String, Int>>()
    private val totalTok = HashMap<String, Int>()
    private val vocab = HashSet<String>()
    private var docs = 0

    fun add(cls: String, toks: List<String>, sign: Int = 1) {
        docs += sign
        docCount[cls] = (docCount[cls] ?: 0) + sign
        val tc = tokCount.getOrPut(cls) { HashMap() }
        for (t in toks) {
            tc[t] = (tc[t] ?: 0) + sign
            vocab.add(t)
        }
        totalTok[cls] = (totalTok[cls] ?: 0) + sign * toks.size
    }

    fun predict(toks: List<String>): List<Pair<String, Double>> {
        val v = maxOf(1, vocab.size).toDouble()
        val scores = ArrayList<Pair<String, Double>>()
        for ((c, n) in docCount) {
            if (n <= 0) continue
            val tc = tokCount[c]
            val tot = (totalTok[c] ?: 0).toDouble()
            var lp = 0.0
            for (t in toks) {
                lp += ln(((tc?.get(t) ?: 0).coerceAtLeast(0) + 1.0) / (tot + v))
            }
            scores.add(c to (ln(n.toDouble() / maxOf(1, docs)) + lp * TEMP))
        }
        if (scores.isEmpty()) return emptyList()
        val mx = scores.maxOf { it.second }
        val exps = scores.map { it.first to exp(it.second - mx) }
        val sum = exps.sumOf { it.second }
        return exps.map { it.first to it.second / sum }.sortedByDescending { it.second }
    }

    companion object {
        const val TEMP = 0.6
    }
}

object SmartTrainer {
    fun run(all: List<Song>, visible: List<Song>, cats: Map<String, String>): Pair<String, List<Suggestion>> {
        val labeled = all.filter { cats[it.path] != null }
        if (labeled.size < 20) {
            return ("صنّف 20 أغنية على الأقل حتى يتعلم (عندك " + labeled.size + ").") to emptyList<Suggestion>()
        }
        val model = NbModel()
        val toks = HashMap<Long, List<String>>()
        for (s in labeled) {
            val t = tokenize(s)
            toks[s.id] = t
            model.add(cats[s.path]!!, t)
        }
        val total = HashMap<String, Int>()
        val ok = HashMap<String, Int>()
        var correct = 0
        for (s in labeled) {
            val c = cats[s.path]!!
            val t = toks[s.id]!!
            model.add(c, t, -1)
            val p = model.predict(t).firstOrNull()?.first
            model.add(c, t, 1)
            total[c] = (total[c] ?: 0) + 1
            if (p == c) {
                correct++
                ok[c] = (ok[c] ?: 0) + 1
            }
        }
        val sb = StringBuilder()
        sb.append("تدرب على ").append(labeled.size).append(" أغنية. الدقة التقريبية: ")
            .append(correct * 100 / labeled.size).append("%\n")
        for ((c, n) in total.entries.sortedByDescending { it.value }) {
            sb.append(c).append(" ").append((ok[c] ?: 0) * 100 / n).append("% (").append(n).append(")   ")
        }
        val sugg = visible.filter { cats[it.path] == null }.mapNotNull { s ->
            val p = model.predict(tokenize(s)).firstOrNull()
            if (p == null) null else Suggestion(s, p.first, p.second)
        }.sortedByDescending { it.conf }
        return sb.toString() to sugg
    }
}
