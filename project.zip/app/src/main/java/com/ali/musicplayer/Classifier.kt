package com.ali.musicplayer

import java.io.File
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sqrt

data class Suggestion(val song: Song, val cat: String, val conf: Double)

fun normAr(t: String): String {
    val sb = StringBuilder()
    for (ch in t) {
        when {
            ch in '\u064B'..'\u0652' || ch == '\u0670' || ch == '\u0640' -> {}
            ch == 'أ' || ch == 'إ' || ch == 'آ' || ch == 'ٱ' -> sb.append('ا')
            ch == 'ة' -> sb.append('ه')
            ch == 'ى' -> sb.append('ي')
            else -> sb.append(ch)
        }
    }
    return sb.toString()
}

fun tokenize(s: Song): List<String> {
    val out = ArrayList<String>()
    val splitter = Regex("[^\\p{L}\\p{N}]+")
    fun add(prefix: String, text: String) {
        val clean = normAr(text.lowercase())
        for (w in clean.split(splitter)) {
            if (w.length >= 2 && !w.all { it.isDigit() }) out.add(prefix + w)
        }
    }
    add("", s.title)
    add("a:", s.artist)
    add("f:", File(s.path).parent?.substringAfterLast('/') ?: "")
    add("n:", File(s.path).nameWithoutExtension)
    val letters = s.title.filter { it.isLetter() }
    val ar = letters.count { it in '\u0600'..'\u06FF' }
    val la = letters.count { it in 'a'..'z' || it in 'A'..'Z' }
    out.add(
        when {
            letters.isEmpty() -> "script:none"
            ar > la -> "script:ar"
            la > ar -> "script:la"
            else -> "script:mix"
        }
    )
    val m = s.durationMs / 60000
    out.add(
        "dur:" + when {
            m < 1 -> "0"
            m < 3 -> "1"
            m < 6 -> "3"
            m < 15 -> "6"
            else -> "15"
        }
    )
    return out
}

class NbModel {
    private val docCount = HashMap<String, Int>()
    private val tokCount = HashMap<String, HashMap<String, Int>>()
    private val totalTok = HashMap<String, Int>()
    private val vocab = HashSet<String>()
    private var docs = 0

    fun add(cls: String, toks: List<String>, sign: Int = 1) {
        docs += sign
        docCount[cls] = (docCount[cls] ?: 0) + sign
        val tc = tokCount.getOrPut(cls) { HashMap() }
        for (t in toks) {
            tc[t] = (tc[t] ?: 0) + sign
            vocab.add(t)
        }
        totalTok[cls] = (totalTok[cls] ?: 0) + sign * toks.size
    }

    fun predict(toks: List<String>): List<Pair<String, Double>> {
        val v = maxOf(1, vocab.size).toDouble()
        val scores = ArrayList<Pair<String, Double>>()
        for ((c, n) in docCount) {
            if (n <= 0) continue
            val tc = tokCount[c]
            val tot = (totalTok[c] ?: 0).toDouble()
            var lp = 0.0
            for (t in toks) {
                lp += ln(((tc?.get(t) ?: 0).coerceAtLeast(0) + 1.0) / (tot + v))
            }
            scores.add(c to (ln(n.toDouble() / maxOf(1, docs)) + lp * TEMP))
        }
        if (scores.isEmpty()) return emptyList()
        val mx = scores.maxOf { it.second }
        val exps = scores.map { it.first to exp(it.second - mx) }
        val sum = exps.sumOf { it.second }
        return exps.map { it.first to it.second / sum }.sortedByDescending { it.second }
    }

    companion object {
        const val TEMP = 0.6
    }
}

class AudioNb(private val d: Int) {
    private val cnt = HashMap<String, Int>()
    private val sum = HashMap<String, DoubleArray>()
    private val sq = HashMap<String, DoubleArray>()

    fun add(c: String, z: FloatArray, sign: Int = 1) {
        cnt[c] = (cnt[c] ?: 0) + sign
        val s = sum.getOrPut(c) { DoubleArray(d) }
        val q = sq.getOrPut(c) { DoubleArray(d) }
        for (i in 0 until d) {
            val v = z[i].toDouble()
            s[i] += sign * v
            q[i] += sign * v * v
        }
    }

    fun predict(z: FloatArray): Map<String, Double>? {
        val scores = ArrayList<Pair<String, Double>>()
        for ((c, n) in cnt) {
            if (n < 2) continue
            val s = sum[c]!!
            val q = sq[c]!!
            var ll = 0.0
            for (i in 0 until d) {
                val m = s[i] / n
                val v = maxOf(q[i] / n - m * m, VAR_FLOOR)
                val diff = z[i] - m
                ll += -0.5 * ln(v) - diff * diff / (2 * v)
            }
            scores.add(c to ll * TEMP_A)
        }
        if (scores.size < 2) return null
        val mx = scores.maxOf { it.second }
        val ex = scores.map { it.first to kotlin.math.exp(it.second - mx) }
        val tot = ex.sumOf { it.second }
        return ex.associate { it.first to it.second / tot }
    }

    companion object {
        const val VAR_FLOOR = 0.15
        const val TEMP_A = 0.35
    }
}

object SmartTrainer {
    private const val W_AUDIO = 0.7

    private fun softmaxList(scores: List<Pair<String, Double>>): List<Pair<String, Double>> {
        if (scores.isEmpty()) return emptyList()
        val mx = scores.maxOf { it.second }
        val ex = scores.map { it.first to kotlin.math.exp(it.second - mx) }
        val tot = ex.sumOf { it.second }
        return ex.map { it.first to it.second / tot }.sortedByDescending { it.second }
    }

    fun run(
        all: List<Song>,
        visible: List<Song>,
        cats: Map<String, String>,
        feats: Map<Int, FloatArray>
    ): Pair<String, List<Suggestion>> {
        val labeled = all.filter { cats[it.path] != null }
        if (labeled.size < 20) {
            return ("صنّف 20 أغنية على الأقل حتى يتعلم (عندك " + labeled.size + ").") to emptyList<Suggestion>()
        }
        val d = AudioAnalyzer.D
        val valid = feats.values.filter { it.size == d }
        val useAudio = valid.size >= 30
        val mu = FloatArray(d)
        val sd = FloatArray(d) { 1f }
        if (useAudio) {
            for (i in 0 until d) {
                val m = valid.map { it[i] }.average()
                val v = valid.map { (it[i] - m) * (it[i] - m) }.average()
                mu[i] = m.toFloat()
                sd[i] = sqrt(v).toFloat().coerceAtLeast(1e-6f)
            }
        }
        fun zOf(s: Song): FloatArray? {
            val f = feats[s.path.hashCode()]
            if (!useAudio || f == null || f.size != d) return null
            return FloatArray(d) { (f[it] - mu[it]) / sd[it] }
        }

        val text = NbModel()
        val audio = AudioNb(d)
        val toks = HashMap<Long, List<String>>()
        val zs = HashMap<Long, FloatArray?>()
        for (s in labeled) {
            val c = cats[s.path]!!
            val t = tokenize(s)
            toks[s.id] = t
            text.add(c, t)
            val zz = zOf(s)
            zs[s.id] = zz
            if (zz != null) audio.add(c, zz)
        }

        fun predictBoth(t: List<String>, zz: FloatArray?): List<Pair<String, Double>> {
            val tp = text.predict(t)
            if (zz == null) return tp
            val ap = audio.predict(zz) ?: return tp
            return softmaxList(
                tp.map { (c, p) ->
                    c to (ln(maxOf(p, 1e-9)) + W_AUDIO * ln(maxOf(ap[c] ?: (1.0 / ap.size), 1e-9)))
                }
            )
        }

        val total = HashMap<String, Int>()
        val ok = HashMap<String, Int>()
        var correctText = 0
        var correctAll = 0
        for (s in labeled) {
            val c = cats[s.path]!!
            val t = toks[s.id]!!
            val zz = zs[s.id]
            text.add(c, t, -1)
            if (zz != null) audio.add(c, zz, -1)
            val pt = text.predict(t).firstOrNull()?.first
            val pa = predictBoth(t, zz).firstOrNull()?.first
            text.add(c, t, 1)
            if (zz != null) audio.add(c, zz, 1)
            total[c] = (total[c] ?: 0) + 1
            if (pt == c) correctText++
            if (pa == c) {
                correctAll++
                ok[c] = (ok[c] ?: 0) + 1
            }
        }
        val sb = StringBuilder()
        sb.append("تدرب على ").append(labeled.size).append(" أغنية.\n")
        if (useAudio) {
            sb.append("الدقة بالأسماء فقط: ").append(correctText * 100 / labeled.size).append("%")
                .append("، وبعد دمج الاستماع: ").append(correctAll * 100 / labeled.size).append("%\n")
        } else {
            sb.append("الدقة التقريبية: ").append(correctAll * 100 / labeled.size).append("%")
                .append(" (ما في استماع كافي للأغاني بعد)\n")
        }
        for ((c, n) in total.entries.sortedByDescending { it.value }) {
            sb.append(c).append(" ").append((ok[c] ?: 0) * 100 / n).append("% (").append(n).append(")   ")
        }
        val sugg = visible.filter { cats[it.path] == null }.mapNotNull { s ->
            val p = predictBoth(tokenize(s), zOf(s)).firstOrNull()
            if (p == null) null else Suggestion(s, p.first, p.second)
        }.sortedByDescending { it.conf }
        return sb.toString() to sugg
    }
}
