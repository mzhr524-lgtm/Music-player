package com.ali.musicplayer

import androidx.media3.common.Player
import java.util.Calendar

data class Event(val ts: Long, val key: Int, val cat: String)

object Assistant {
    private val catWords = listOf(
        "قران" to "قرآن", "دعاء" to "أدعية", "ادعيه" to "أدعية", "حسيني" to "حسينيات",
        "لطمي" to "حسينيات", "عراقي" to "أغاني عراقية", "عربي" to "أغاني عربية", "راب" to "راب",
        "موال" to "موال", "شعر" to "شعر", "موسيق" to "موسيقى", "اجنبي" to "أغاني أجنبية"
    )

    private val stop = setOf(
        "كم", "مره", "سمعت", "سمعتها", "شغلت", "اغنيه", "الاغنيه", "هاي", "هذي", "هذه", "هذا",
        "شغل", "لي", "اغاني", "بالمكتبه", "عندي", "شنو", "اسمع", "مال", "اللي", "الحاليه",
        "ضيف", "ضيفها", "اضف", "اضفها", "حط", "حطها", "للمفضله", "المفضله", "بالمفضله", "خلي", "خليها",
        "شيل", "شيلها", "انتظار", "للانتظار", "بعد", "بعدها", "قائمه", "للقائمه", "لقائمه", "حزينه", "هادئه",
        "رتب", "وافق", "اقبل", "صنف", "كمل"
    )

    private fun yes(a: String): Boolean =
        a.contains("نعم") || a.contains("ايه") || a == "اي" || a.contains("اكيد") ||
            a.contains("شغلها") || a.contains("تمام") || a.contains("ايوه") || a.contains("اوكي")

    private val wantPrefixes = listOf(
        "اريد اسمع ", "ابي اسمع ", "اني اريد اسمع ", "اريد اشغل ", "اسمعني ", "اسمعلي ",
        "دزلي ", "حطلي ", "جيبلي ", "سويلي "
    )

    private fun dialect(n: String): String {
        for (p in wantPrefixes) {
            if (n.startsWith(p) && n.length > p.length + 1) return "شغل " + n.substring(p.length)
        }
        return n
    }

    private const val NO_DATA = "للحين ما عندي سجل كافي بهالفترة. اسمع شوية وارجع اسألني."

    private fun digitsToAscii(t: String): String =
        t.map { if (it in '٠'..'٩') '0' + (it - '٠') else it }.joinToString("")

    private fun num(n: String): Double? =
        Regex("(\\d+(?:[.,]\\d+)?)").find(n)?.groupValues?.get(1)?.replace(',', '.')?.toDoubleOrNull()

    private fun moodOf(t: String): String? = when {
        t.contains("حزن") || t.contains("حزين") || t.contains("زعلان") || t.contains("مكتئب") ||
            t.contains("كئيب") || t.contains("ضايج") || t.contains("بكي") -> "حزين"
        t.contains("هادي") || t.contains("هادئ") || t.contains("رايق") || t.contains("استرخاء") ||
            t.contains("ريلاكس") || t.contains("روقان") -> "هادئ"
        t.contains("حماس") || t.contains("نشاط") || t.contains("رياض") || t.contains("جيم") ||
            t.contains("طاقه") -> "حماس"
        t.contains("تركيز") || t.contains("دراس") || t.contains("مذاكر") -> "تركيز"
        t.contains("نوم") || t.contains("نايم") || t.contains("انام") -> "نوم"
        else -> null
    }

    private fun control(n: String, vm: PlayerViewModel): String? {
        fun has(vararg w: String): Boolean = w.any { n.contains(it) }
        val off = has("طفي", "الغ", "ايقاف", "عطل")

        if (has("معادل")) {
            val name = when {
                has("بشري") -> "صوت بشري"
                has("جهير", "باس") -> "جهير"
                has("راب") -> "راب"
                has("هادي", "هادئ") -> "هادئ"
                has("عادي") || off -> "عادي"
                else -> null
            }
            if (name == null) {
                return "المعادل عندي: " + EqPresets.joinToString("، ") { it.first } +
                    ". مثلاً: شغل المعادل صوت بشري."
            }
            vm.setEqPreset(name)
            return "تمام، فعلت المعادل: " + name
        }

        if (has("سرعه")) {
            val v = num(n)
            when {
                v != null -> vm.speedTo(v.toFloat().coerceIn(0.5f, 2f))
                has("ابطا", "بطي", "بطء", "نزل", "خفض", "اقل") -> vm.speedTo((vm.speed - 0.25f).coerceAtLeast(0.5f))
                has("اسرع", "زيد", "ارفع", "اكثر") -> vm.speedTo((vm.speed + 0.25f).coerceAtMost(2f))
                else -> vm.speedTo(1f)
            }
            return "السرعة صارت " + vm.speed.toString().removeSuffix(".0") + "x"
        }

        val sleepIntent = has("نومني", "مؤقت") || (has("بعد") && has("طفي", "وقف"))
        if (sleepIntent) {
            if (has("الغ", "الغاء")) {
                vm.cancelSleep()
                return "الغيت المؤقت."
            }
            if (has("بعد الاغنيه", "بعد هاي الاغنيه", "نهايه الاغنيه")) {
                vm.sleepAfterSong()
                return "راح أطفي بعد ما تخلص هذه الأغنية."
            }
            val v = num(n)
            if (v != null) {
                val mins = if (has("ساعه")) (v * 60).toInt() else v.toInt()
                vm.startSleep(mins.coerceIn(1, 600))
                return "تمام، راح أطفي بعد " + mins + " دقيقة."
            }
            return "كم دقيقة؟ مثلاً: نوّمني بعد 30 دقيقة."
        }

        if (has("عشوائي")) {
            vm.shuffleTo(!off)
            return if (off) "طفيت العشوائي." else "شغلت العشوائي."
        }

        if (has("كرر", "تكرار")) {
            val mode = when {
                off -> Player.REPEAT_MODE_OFF
                has("الكل", "القائمه") -> Player.REPEAT_MODE_ALL
                else -> Player.REPEAT_MODE_ONE
            }
            vm.repeatTo(mode)
            return when (mode) {
                Player.REPEAT_MODE_OFF -> "طفيت التكرار."
                Player.REPEAT_MODE_ALL -> "راح أكرر القائمة كلها."
                else -> "راح أكرر هذه الأغنية."
            }
        }

        if (has("قدم", "تقدم") || (has("ارجع", "رجع") && has("ثانيه", "ثواني"))) {
            val sec = num(n)?.toInt() ?: vm.skipSec
            val fwd = has("قدم", "تقدم")
            vm.skipBy(if (fwd) sec else -sec)
            return (if (fwd) "قدمت " else "رجعت ") + sec + " ثانية."
        }

        if (has("محرم")) {
            vm.muharramTo(!off)
            return if (off) "طفيت وضع محرم." else "شغلت وضع محرم."
        }

        if (has("الصوت")) {
            val v = num(n)
            if (v != null) {
                vm.volumeSetPct(v.toInt())
                return "الصوت " + v.toInt() + "%."
            }
            if (has("ارفع", "زيد", "اعلى", "عالي")) {
                vm.volumeStep(true)
                return "رفعت الصوت."
            }
            if (has("نزل", "خفض", "وطي", "اقل")) {
                vm.volumeStep(false)
                return "نزلت الصوت."
            }
        }

        if ((has("الصوره") || has("الغلاف")) && has("مربع", "دائري", "مدور")) {
            val sq = has("مربع")
            vm.coverTo(sq)
            return if (sq) "خليت الصورة مربعة." else "خليت الصورة دائرية."
        }

        if (has("لون")) {
            val idx = when {
                has("ذهبي", "اصفر") -> 0
                has("اخضر") -> 1
                has("ازرق") -> 2
                has("بنفسجي") -> 3
                has("برتقالي") -> 4
                has("احمر") -> 5
                has("وردي") -> 6
                has("تركواز", "سماوي") -> 7
                else -> -1
            }
            if (idx >= 0) {
                vm.saveAccent(AccentColors[idx])
                return "غيرت اللون."
            }
            return "الألوان اللي عندي: ذهبي، أخضر، أزرق، بنفسجي، برتقالي، أحمر، وردي، تركوازي."
        }

        if (has("خط فاصل", "خطوط فاصله", "فواصل")) {
            vm.dividersTo(!off)
            return if (off) "طفيت الخطوط الفاصلة." else "شغلت الخطوط الفاصلة."
        }

        if (has("افتح", "وديني") || has("صنف الاغاني", "صنفلي")) {
            val dest = when {
                has("اعدادات") -> "settings"
                has("تصنيف", "صنف") -> "smart"
                has("مكرر") -> "dups"
                else -> null
            }
            if (dest != null) {
                vm.requestNav(dest)
                return "تمام."
            }
        }

        if (has("الجايه", "التاليه", "تخطي", "بدل الاغنيه", "غير الاغنيه")) {
            vm.next()
            return "تمام، الأغنية الجاية."
        }
        if (has("السابقه", "الي قبلها", "اللي قبلها")) {
            vm.prev()
            return "رجعت للأغنية السابقة."
        }
        if ((n.startsWith("وقف") || n.startsWith("سكت") || n == "بس") && !has("بعد")) {
            vm.pause()
            return "وقفت."
        }
        return null
    }

    private fun cat(n: String): String? = catWords.firstOrNull { n.contains(it.first) }?.second

    private fun t(s: String): String = if (s.length > 40) s.take(40) + "…" else s

    private fun fmt(ts: Long): String =
        java.text.SimpleDateFormat("d/M HH:mm", java.util.Locale.US).format(java.util.Date(ts))

    private fun dayStart(offsetDays: Int): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        c.add(Calendar.DAY_OF_YEAR, offsetDays)
        return c.timeInMillis
    }

    private fun range(n: String): Pair<Long, Long>? = when {
        n.contains("اليوم") -> dayStart(0) to Long.MAX_VALUE
        n.contains("امس") -> dayStart(-1) to dayStart(0)
        n.contains("اسبوع") -> dayStart(-6) to Long.MAX_VALUE
        n.contains("شهر") -> dayStart(-29) to Long.MAX_VALUE
        else -> null
    }

    private fun rangeName(n: String): String = when {
        n.contains("اليوم") -> "اليوم"
        n.contains("امس") -> "أمس"
        n.contains("اسبوع") -> "هالأسبوع"
        n.contains("شهر") -> "هالشهر"
        else -> ""
    }

    private fun partName(n: String): String = when {
        n.contains("ليل") -> "بالليل"
        n.contains("صبح") -> "الصبح"
        n.contains("ظهر") || n.contains("عصر") -> "بعد الظهر"
        n.contains("مغرب") || n.contains("مساء") -> "بالمساء"
        else -> ""
    }

    private fun inPart(n: String, h: Int): Boolean = when {
        n.contains("ليل") -> h >= 21 || h < 5
        n.contains("صبح") -> h in 5..11
        n.contains("ظهر") || n.contains("عصر") -> h in 12..17
        n.contains("مغرب") || n.contains("مساء") -> h in 18..20
        else -> true
    }

    private fun hourOf(ts: Long): Int {
        val c = Calendar.getInstance()
        c.timeInMillis = ts
        return c.get(Calendar.HOUR_OF_DAY)
    }

    private fun eventsIn(vm: PlayerViewModel, n: String): List<Event> {
        var ev = vm.readEvents()
        val r = range(n)
        if (r != null) ev = ev.filter { it.ts >= r.first && it.ts < r.second }
        if (partName(n).isNotEmpty()) ev = ev.filter { inPart(n, hourOf(it.ts)) }
        return ev
    }

    private fun ctxText(n: String): String {
        val parts = listOf(rangeName(n), partName(n)).filter { it.isNotEmpty() }
        return if (parts.isEmpty()) "" else " " + parts.joinToString(" ")
    }

    private fun topSongs(vm: PlayerViewModel, ev: List<Event>, limit: Int): List<Pair<Song, Int>> {
        val byKey = vm.raw.associateBy { vm.songKey(it) }
        return ev.groupingBy { it.key }.eachCount().entries.sortedByDescending { it.value }
            .mapNotNull { e -> byKey[e.key]?.let { it to e.value } }.take(limit)
    }

    private var lastSong: Song? = null
    private var pending: ((String) -> String?)? = null

    private val vocabRaw = listOf(
        "معادل", "سرعه", "نومني", "مؤقت", "عشوائي", "تكرار", "محرم", "الصوت", "الصوره", "الغلاف",
        "مربع", "دائري", "افتح", "اعدادات", "تصنيف", "مكرر", "التاليه", "الجايه", "السابقه", "شغل",
        "شغللي", "اكثر", "اغنيه", "اغاني", "سمعت", "سمعتها", "مفضله", "قران", "دعاء", "ادعيه",
        "حسيني", "عراقي", "عربي", "موسيقى", "اجنبي", "حزين", "هادي", "حماس", "تركيز", "اسرع", "ابطا",
        "صنف", "وافق", "وريني", "انتظار", "قائمه", "رتب", "الاسم", "التاريخ", "المده", "الفنان",
        "تذكر", "ملاحظاتي", "اليوم", "اسبوع", "الليل", "الصبح", "المساء", "بالليل", "كرر", "وقف",
        "ارفع", "خفض", "نزل", "طفي", "ضيف", "اضف", "الاقتراحات", "التحليل", "عميق", "سريع", "اسمع",
        "حلل", "استمع", "الاغاني", "مكتبتي", "الصوره", "المعادل", "شكرا", "مساعده",
        "اقترح", "اقترحلي", "فاجئني", "شلونك", "غيرها"
    )
    private val vocab: List<String> by lazy { vocabRaw.map { normAr(it) }.distinct() }
    private val vocabSet: Set<String> by lazy { vocab.toSet() }

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]
            d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + (if (a[i - 1] == b[j - 1]) 0 else 1))
                prev = tmp
            }
        }
        return d[b.length]
    }

    private fun fixTypos(n: String): String =
        n.split(" ").joinToString(" ") { w ->
            if (w.length < 4 || w in vocabSet) {
                w
            } else {
                val lim = if (w.length >= 7) 2 else 1
                var best: String? = null
                var bd = lim + 1
                for (v in vocab) {
                    if (kotlin.math.abs(v.length - w.length) > lim) continue
                    val dd = lev(w, v)
                    if (dd < bd) {
                        bd = dd
                        best = v
                    }
                }
                best ?: w
            }
        }

    private fun findSongs(vm: PlayerViewModel, n: String, limit: Int): List<Pair<Song, Int>> {
        val toks = n.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 3 && it !in stop }
        if (toks.isEmpty()) return emptyList()
        val out = ArrayList<Pair<Song, Int>>()
        for (s in vm.raw) {
            val title = normAr((s.title + " " + s.artist).lowercase())
            var sc = 0
            for (w in toks) if (title.contains(w)) sc++
            if (sc > 0) out.add(s to sc)
        }
        return out.sortedWith(
            compareByDescending<Pair<Song, Int>> { it.second }.thenBy { it.first.title.length }
        ).take(limit)
    }

    private fun findSong(vm: PlayerViewModel, n: String): Song? = findSongs(vm, n, 1).firstOrNull()?.first

    private fun acceptAt(vm: PlayerViewModel, th: Double): String {
        val c = vm.suggestions.count { it.conf >= th }
        if (c == 0) return "ماكو اقتراحات بهالنسبة. جرّب نسبة أقل."
        vm.acceptSuggestions(th)
        val left = vm.suggestions.size
        return "تمام، صنفت " + c + " أغنية." +
            (if (left > 0) " باقي " + left + " اقتراح نسبته أقل." else " خلصت كل الاقتراحات.")
    }

    private fun helpText(): String =
        "أكدر أسوي لك:\n" +
            "• أشغل: شغل قرآن، شغل لي شي حزين، شغل اسم أغنية، شغل المفضلة\n" +
            "• أصنف مكتبتك: صنف الأغاني، وبعدها وافق على الكل أو وافق فوق 90\n" +
            "• أحلل أغانيك: حلل الأغاني، استماع عميق\n" +
            "• أتحكم: السرعة، الصوت، المعادل، العشوائي، التكرار، مؤقت النوم\n" +
            "• أقترح: اقترح لي أغنية، فاجئني\n" +
            "• أرتب: رتب حسب الاسم، ضيفها للمفضلة، ضيفها للانتظار، خلي هاي حزينة\n" +
            "• أجاوب عن سماعك: شنو أكثر أغاني سمعتها هالأسبوع؟\n" +
            "• أتذكر: تذكر إني أحب ..."

    fun answer(raw: String, vm: PlayerViewModel): String {
        val n0 = digitsToAscii(normAr(raw.lowercase())).replace("؟", " ").replace("?", " ").trim()
        val pend = pending
        if (pend != null) {
            pending = null
            val r = pend(n0)
            if (r != null) return r
        }
        val n = fixTypos(dialect(n0))
        fun has(vararg w: String): Boolean = w.any { n.contains(it) }

        if (n in setOf("شغلها", "شغله", "شغل هاي", "شغل هي")) {
            val ls = lastSong ?: vm.current
            if (ls != null) {
                lastSong = ls
                vm.playList(listOf(ls))
                return "شغلتها: «" + t(ls.title) + "»"
            }
        }
        if (has("اقترح", "فاجئني")) {
            val p = vm.suggestForChat() ?: return "المكتبة فاضية، ماكو شي أقترحه."
            val g = p.first
            lastSong = g
            pending = { a ->
                when {
                    a.contains("غيرها") || a.contains("غير") || a.contains("ثانيه") -> answer("اقترح", vm)
                    yes(a) -> {
                        vm.playPicked(g)
                        "شغلت: «" + t(g.title) + "»"
                    }
                    else -> null
                }
            }
            return "أقترح عليك «" + t(g.title) + "»" +
                (if (g.artist.isNotBlank()) " - " + t(g.artist) else "") +
                " (" + p.second + "). أشغلها؟ اكتب نعم، أو «غيرها» لو تريد غيرها."
        }

        if (n.startsWith("تذكر") && !has("شنو")) {
            val note = raw.trim().substringAfter("تذكر").trim()
            if (note.isBlank()) return "شنو تريدني أتذكر؟"
            vm.addNote(note)
            return "تمام، حفظتها: «" + t(note) + "»"
        }
        if (has("شنو تتذكر", "شنو تعرف عني", "ملاحظاتي")) {
            val ns = vm.notes()
            if (ns.isEmpty()) return "ماكو شي محفوظ. كلي: تذكر إني أحب ..."
            return "اللي أتذكره عنك:\n" + ns.joinToString("\n") { "• " + it }
        }
        if (n.startsWith("انسى")) {
            vm.clearNotes()
            return "مسحت كل الملاحظات."
        }

        if (n in setOf("هلا", "هلو", "مرحبا", "سلام", "السلام عليكم", "اهلين", "هلا بيك", "هلا والله", "صباح الخير", "مساء الخير")) {
            return "هلا بيك! شتريد أسوي لك؟ اكتب «شنو تكدر تسوي» وأوريك."
        }
        if (n.length < 30 && has("شكرا", "يعطيك العافيه", "عاشت ايدك", "تسلم ايدك", "مشكور")) {
            return "الله يسلمك! أي شي ثاني؟"
        }
        if (has("شنو تكدر", "شتكدر", "شنو تسوي", "مساعده", "الاوامر", "شنو اكدر اسوي")) return helpText()
        if (has("شنو شغال", "شنو اسم هاي الاغنيه", "اسم الاغنيه")) {
            val c = vm.current ?: return "ماكو شي شغال هسه."
            lastSong = c
            return "شغال هسه: «" + t(c.title) + "»" + (if (c.artist.isNotBlank()) " - " + t(c.artist) else "")
        }

        if (has("حلل", "استمع") && has("الاغاني", "اغاني", "مكتبتي") && !has("عميق", "سريع")) {
            vm.startAnalysis()
            return "بديت الاستماع للأغاني. يشتغل بالخلفية حتى لو طفيت الشاشة (يظهر إشعار بالتقدم)، ويكمل من وين وقف. الأفضل والجوال على الشاحن. تقدر تتابعه من التصنيف الذكي."
        }
        if (has("وقف", "اوقف") && has("التحليل", "الاستماع")) {
            vm.stopAnalysis()
            return "وقفت الاستماع."
        }
        if (has("عميق") && has("استماع", "تحليل", "نمط", "فعل", "شغل")) {
            vm.setDeep(true)
            return "فعلت الاستماع العميق (أبطأ بس أدق، يسمع عدة مقاطع من كل أغنية). قلي «حلل الأغاني» وراح يعيد تحليل المكتبة."
        }
        if (has("سريع") && has("استماع", "تحليل", "نمط")) {
            vm.setDeep(false)
            return "رجعت للاستماع السريع."
        }

        if (n.startsWith("صنف") || has("صنفلي", "صنف الاغاني", "صنف مكتبتي")) {
            return vm.assistClassify()
        }
        if (has("وافق", "اقبل", "اعتمد")) {
            if (vm.suggestions.isEmpty()) return "ماكو اقتراحات للحين. قلي «صنف الأغاني» وأطلع لك اقتراحات."
            val pct = num(n)
            if (has("الكل", "كلها", "كلهم")) return acceptAt(vm, 0.0)
            if (pct != null) return acceptAt(vm, (if (pct > 1.0) pct / 100.0 else pct).coerceIn(0.0, 1.0))
            pending = { a ->
                val v = num(a)
                when {
                    a.contains("الكل") -> acceptAt(vm, 0.0)
                    v != null -> acceptAt(vm, (if (v > 1.0) v / 100.0 else v).coerceIn(0.0, 1.0))
                    else -> null
                }
            }
            return "عندي " + vm.suggestions.size + " اقتراح. أقبلها كلها لو بس اللي نسبتها فوق حد معين؟ اكتب «الكل» أو رقم مثل 90."
        }
        if (has("وريني", "اعرض") && has("اقتراح", "تصنيف", "نتايج", "وريني") && vm.suggestions.isNotEmpty()) {
            vm.requestNav("smart")
            return "تمام، افتحتها لك."
        }
        if (has("ارفض", "تجاهل", "الغ") && has("الاقتراحات", "اقتراح")) {
            vm.clearSuggestions()
            return "مسحت الاقتراحات، ما تغيّر شي."
        }

        val ctl = control(n, vm)
        if (ctl != null) return ctl

        fun subject(): Song? {
            val byText = findSong(vm, n0)
            if (byText != null) return byText
            if (has("هاي", "الحاليه", "اسمعها", "اسمعه")) return vm.current ?: lastSong
            return lastSong ?: vm.current
        }

        if (has("مفضل") && has("ضيف", "اضف", "حط", "خلي", "شيل", "احذف", "الغ", "ازل") && !n.startsWith("شغل")) {
            val s = subject() ?: return "أي أغنية؟ شغل أغنية أو اكتب اسمها."
            lastSong = s
            val remove = has("شيل", "احذف", "الغ", "ازل")
            val inFav = s.path in vm.favs
            if (remove) {
                if (inFav) vm.toggleFav(s)
                return "شلتها من المفضلة: «" + t(s.title) + "»"
            }
            if (!inFav) vm.toggleFav(s)
            return "ضفتها للمفضلة: «" + t(s.title) + "»"
        }

        if (has("انتظار") && has("ضيف", "اضف", "حط")) {
            val s = subject() ?: return "أي أغنية؟ شغل أغنية أو اكتب اسمها."
            lastSong = s
            vm.addToQueue(s)
            return "ضفتها لقائمة الانتظار: «" + t(s.title) + "»"
        }
        if (has("بعد هاي", "بعد الحاليه", "بعدها") && has("ضيف", "اضف", "حط", "شغل") && !n.startsWith("شغل ")) {
            val s = subject() ?: return "أي أغنية؟ شغل أغنية أو اكتب اسمها."
            lastSong = s
            vm.playNext(s)
            return "راح أشغلها بعد الأغنية الحالية: «" + t(s.title) + "»"
        }

        val md2 = moodOf(n)
        if (md2 != null && has("خلي", "خليها", "اضف", "ضيف", "حط", "اعتبر") && !n.startsWith("شغل") && !has("مفضل")) {
            val s = subject() ?: return "أي أغنية؟ شغل أغنية أو اكتب اسمها."
            lastSong = s
            if (md2 !in vm.songMoodSet(s)) vm.toggleSongMood(s, md2)
            return "تمام، خليتها مزاج " + md2 + ": «" + t(s.title) + "»"
        }

        if (has("رتب")) {
            val key = when {
                has("الاسم", "اسم") -> "name"
                has("التاريخ", "الاضافه", "احدث", "الجديد") -> "date"
                has("المده", "الطول") -> "dur"
                has("الفنان") -> "artist"
                has("الافتراضي", "عادي") -> "def"
                else -> null
            }
            if (key == null) return "رتبها حسب شنو؟ الاسم، التاريخ، المدة، لو الفنان؟"
            vm.sortBy(key)
            if (has("تنازلي", "احدث", "الجديد")) vm.sortDir(false)
            if (has("تصاعدي", "اقدم")) vm.sortDir(true)
            return "رتبت المكتبة: " + sortName(key) + "."
        }

        if (n.startsWith("شغل") || has("شغللي") || n.startsWith("كمل")) {
            val words0 = n0.split(" ").filter { it.isNotBlank() }
            val words = n.split(" ").filter { it.isNotBlank() }
            fun cut(w: List<String>): String {
                var x = w.drop(1).joinToString(" ")
                if (x == "لي") x = "" else if (x.startsWith("لي ")) x = x.substring(3)
                return x.trim()
            }
            val target0 = cut(words0)
            val target = cut(words)
            if (target.isBlank()) {
                vm.resume()
                return "كملت التشغيل."
            }
            if (target == "ها" || target == "هي" || target == "هاي") {
                val s = lastSong ?: return "شنو تقصد بـ«ها»؟ اكتب اسم الأغنية."
                vm.playList(listOf(s))
                return "شغلت: " + t(s.title)
            }
            if (target == "شي" || target == "اي شي" || target == "شي عشوائي") {
                val l = vm.songs.shuffled().take(100)
                if (l.isEmpty()) return "المكتبة فاضية."
                vm.playList(l)
                return "شغلت لك شي عشوائي."
            }
            if (target.contains("قائمه") || target.contains("بلاي ليست")) {
                val nm = vm.playlists.keys.firstOrNull { k ->
                    val kn = normAr(k.lowercase())
                    target0.contains(kn) || kn.contains(target0.replace("قائمه", "").trim()) && target0.replace("قائمه", "").isNotBlank()
                }
                if (nm == null) return "ما لقيت قائمة بهالاسم. قوائمك: " + (if (vm.playlists.isEmpty()) "ماكو" else vm.playlists.keys.joinToString("، "))
                val l = vm.playlistSongs(nm)
                if (l.isEmpty()) return "قائمة «" + nm + "» فاضية."
                vm.playList(l)
                return "شغلت قائمة «" + nm + "» (" + l.size + " أغنية)"
            }
            val md = moodOf(target)
            val c = cat(target)
            val picked: Pair<String, List<Song>>? = when {
                target.contains("مفضل") -> "المفضلة" to vm.songs.filter { it.path in vm.favs }
                target.contains("اكثر") && target.contains("سمع") ->
                    "الأكثر سماعاً" to vm.songs.filter { vm.playCount(it) > 0 }
                        .sortedByDescending { vm.playCount(it) }.take(50)
                md != null -> ("مزاج " + md) to vm.moodSongs(md).shuffled()
                c != null -> c to vm.songs.filter { vm.cats[it.path] == c }.shuffled()
                else -> null
            }
            if (picked != null) {
                if (picked.second.isEmpty()) return "ما لقيت شي بهالقسم للحين."
                vm.playList(picked.second)
                return "شغلت: " + t(picked.first) + " (" + picked.second.size + " أغنية)"
            }
            val cands = findSongs(vm, target0, 30)
            if (cands.isEmpty()) return "ما لقيت شي أشغله بهالاسم. جرّب: شغل قرآن، أو شغل اسم الأغنية."
            val topSc = cands[0].second
            val tied = cands.filter { it.second == topSc }.map { it.first }
            val exact = tied.firstOrNull { normAr(it.title.lowercase()).trim() == target0 }
            if (tied.size == 1 || exact != null) {
                val s = exact ?: tied[0]
                lastSong = s
                vm.playList(listOf(s))
                return "شغلت: " + t(s.title)
            }
            val list = tied.take(5)
            pending = { a ->
                val k = num(a)?.toInt()
                when {
                    k != null && k in 1..list.size -> {
                        lastSong = list[k - 1]
                        vm.playList(listOf(list[k - 1]))
                        "شغلت: " + t(list[k - 1].title)
                    }
                    a.contains("الكل") -> {
                        vm.playList(tied.shuffled())
                        "شغلت " + tied.size + " أغنية."
                    }
                    else -> null
                }
            }
            return "لقيت أكثر من أغنية قريبة، أي وحدة تقصد؟\n" +
                list.mapIndexed { i, s ->
                    (i + 1).toString() + ") " + t(s.title) + (if (s.artist.isNotBlank()) " - " + t(s.artist) else "")
                }.joinToString("\n") + "\nاكتب الرقم، أو «الكل» أشغلها كلها."
        }

        if (has("كم مره") && has("سمعت", "شغلت", "اسمع")) {
            val s = findSong(vm, n0) ?: vm.current ?: lastSong
                ?: return "ما كدرت أعرف أي أغنية تقصد. شغل أغنية أو اكتب اسمها."
            lastSong = s
            val cnt = vm.playCount(s)
            val last = vm.lastPlayedAt(s)
            return "سمعت «" + t(s.title) + "» " + cnt + " مرة" +
                (if (last > 0) "، وآخر مرة " + fmt(last) else "") + "."
        }

        if (has("اسمع", "سمعت") && partName(n).isNotEmpty() && has("شنو", "اي", "ايش")) {
            val ev = eventsIn(vm, n)
            val tally = ev.filter { it.cat.isNotEmpty() }.groupingBy { it.cat }.eachCount()
                .entries.sortedByDescending { it.value }.take(3)
            if (tally.isEmpty()) return NO_DATA
            return "أكثر شي تسمعه" + ctxText(n) + ":\n" +
                tally.joinToString("\n") { "• " + it.key + " (" + it.value + " مرة)" }
        }

        if (has("اكثر") && has("قسم", "نوع", "اصناف")) {
            val tally = eventsIn(vm, n).filter { it.cat.isNotEmpty() }.groupingBy { it.cat }.eachCount()
                .entries.sortedByDescending { it.value }.take(3)
            if (tally.isEmpty()) return NO_DATA
            return "أكثر الأقسام" + ctxText(n) + ":\n" +
                tally.joinToString("\n") { "• " + it.key + " (" + it.value + " مرة)" }
        }

        if (has("اكثر") && has("اغنيه", "اغاني", "سمعته", "سمعتها", "شي")) {
            val top = topSongs(vm, eventsIn(vm, n), 5)
            if (top.isEmpty()) return NO_DATA
            return "أكثر أغاني سمعتها" + ctxText(n) + ":\n" +
                top.mapIndexed { i, p -> (i + 1).toString() + ". " + t(p.first.title) + " (" + p.second + ")" }
                    .joinToString("\n")
        }

        if (has("شنو سمعت", "شسمعت", "اخر شي سمعت", "اخر اغنيه", "اخر اغاني")) {
            val byKey = vm.raw.associateBy { vm.songKey(it) }
            val rec = eventsIn(vm, n).sortedByDescending { it.ts }.distinctBy { it.key }
                .mapNotNull { byKey[it.key] }.take(8)
            if (rec.isEmpty()) return NO_DATA
            return "سمعت" + ctxText(n) + ":\n" + rec.joinToString("\n") { "• " + t(it.title) }
        }

        if (has("كم") && has("اغنيه", "اغاني") && has("عندي", "بالمكتبه", "مكتبتي")) {
            val c = cat(n)
            return if (c != null) {
                "عندك " + vm.songs.count { vm.cats[it.path] == c } + " أغنية بقسم " + c + "."
            } else {
                "عندك " + vm.songs.size + " أغنية، منها " + vm.songs.count { it.path in vm.cats } + " مصنفة."
            }
        }

        if (has("ما سمعتها", "ما سمعت", "منسيه", "نسيتها")) {
            val never = vm.songs.filter { vm.playCount(it) == 0 }
            if (never.isEmpty()) return "كل أغانيك سمعتها مرة على الأقل."
            return "عندك " + never.size + " أغنية ما سمعتها للحين، مثلاً:\n" +
                never.shuffled().take(5).joinToString("\n") { "• " + t(it.title) }
        }

        if (n.length < 25) {
            if (has("شلونك", "شخبارك", "شحالك", "شلونكم")) return "تمام الحمد لله، جاهز أخدمك. شتريد أشغل لك؟"
            if (has("منو انت", "شنو انت", "شنو اسمك", "منو سواك")) {
                return "أني مساعد تطبيق Music. أشغل لك أغانيك، أرتب مكتبتك، وأجاوب عن اللي سمعته."
            }
            if (has("احبك", "حبيبي", "تحفه", "ممتاز", "حلو")) return "تسلم! تريد أقترح لك أغنية؟ اكتب «اقترح لي»."
            if (has("ملل", "زهقان", "طفران", "ضايج")) return "ما عليك، خلي أقترح لك شي. اكتب «اقترح لي» أو «شغل شي هادئ»."
        }

        val guess = if (n0.split(" ").size <= 5) findSongs(vm, n0, 1).firstOrNull() else null
        if (guess != null) {
            val g = guess.first
            pending = { a ->
                if (a.contains("نعم") || a.contains("ايه") || a.contains("اي") || a.contains("اكيد") ||
                    a.contains("شغلها") || a.contains("تمام") || a.contains("ايوه")
                ) {
                    lastSong = g
                    vm.playList(listOf(g))
                    "شغلت: " + t(g.title)
                } else {
                    null
                }
            }
            return "ما فهمت بالضبط، بس لقيت أغنية قريبة: «" + t(g.title) + "». تريد أشغلها؟ اكتب نعم."
        }

        return "ما فهمت قصدك زين. تريد أشغل شي، لو أجاوب عن سماعك، لو أتحكم بالتطبيق؟\n" +
            "اكتب «شنو تكدر تسوي» وأوريك كل شي، أو جرّب:\n" +
            "• هاي الأغنية كم مرة سمعتها؟\n" +
            "• شنو أكثر قسم أسمعه بالليل؟\n" +
            "• صنف الأغاني\n" +
            "• شغل لي شي حزين\n" +
            "• اقترح لي أغنية\n" +
            "• ضيفها للمفضلة"
    }

    private fun sortName(k: String): String = when (k) {
        "name" -> "حسب الاسم"
        "date" -> "حسب تاريخ الإضافة"
        "dur" -> "حسب المدة"
        "artist" -> "حسب الفنان"
        else -> "الترتيب الافتراضي"
    }
}
