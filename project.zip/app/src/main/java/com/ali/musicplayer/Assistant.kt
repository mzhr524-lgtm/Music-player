package com.ali.musicplayer

import java.util.Calendar

data class Event(val ts: Long, val key: Int, val cat: String)

object Assistant {
    private val catWords = listOf(
        "قران" to "قرآن", "دعاء" to "أدعية", "ادعيه" to "أدعية", "حسيني" to "حسينيات",
        "لطمي" to "حسينيات", "عراقي" to "أغاني عراقية", "عربي" to "أغاني عربية", "راب" to "راب",
        "موال" to "موال", "شعر" to "شعر", "موسيق" to "موسيقى", "اجنبي" to "أغاني أجنبية"
    )

    private val stop = setOf(
        "كم", "مره", "سمعت", "سمعتها", "شغلت", "اغنيه", "الاغنيه", "هاي", "هذي", "هذه", "هذا",
        "شغل", "لي", "اغاني", "بالمكتبه", "عندي", "شنو", "اسمع", "مال", "اللي", "الحاليه"
    )

    private const val NO_DATA = "للحين ما عندي سجل كافي بهالفترة. اسمع شوية وارجع اسألني."

    private fun cat(n: String): String? = catWords.firstOrNull { n.contains(it.first) }?.second

    private fun t(s: String): String = if (s.length > 40) s.take(40) + "…" else s

    private fun fmt(ts: Long): String =
        java.text.SimpleDateFormat("d/M HH:mm", java.util.Locale.US).format(java.util.Date(ts))

    private fun dayStart(offsetDays: Int): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        c.add(Calendar.DAY_OF_YEAR, offsetDays)
        return c.timeInMillis
    }

    private fun range(n: String): Pair<Long, Long>? = when {
        n.contains("اليوم") -> dayStart(0) to Long.MAX_VALUE
        n.contains("امس") -> dayStart(-1) to dayStart(0)
        n.contains("اسبوع") -> dayStart(-6) to Long.MAX_VALUE
        n.contains("شهر") -> dayStart(-29) to Long.MAX_VALUE
        else -> null
    }

    private fun rangeName(n: String): String = when {
        n.contains("اليوم") -> "اليوم"
        n.contains("امس") -> "أمس"
        n.contains("اسبوع") -> "هالأسبوع"
        n.contains("شهر") -> "هالشهر"
        else -> ""
    }

    private fun partName(n: String): String = when {
        n.contains("ليل") -> "بالليل"
        n.contains("صبح") -> "الصبح"
        n.contains("ظهر") || n.contains("عصر") -> "بعد الظهر"
        n.contains("مغرب") || n.contains("مساء") -> "بالمساء"
        else -> ""
    }

    private fun inPart(n: String, h: Int): Boolean = when {
        n.contains("ليل") -> h >= 21 || h < 5
        n.contains("صبح") -> h in 5..11
        n.contains("ظهر") || n.contains("عصر") -> h in 12..17
        n.contains("مغرب") || n.contains("مساء") -> h in 18..20
        else -> true
    }

    private fun hourOf(ts: Long): Int {
        val c = Calendar.getInstance()
        c.timeInMillis = ts
        return c.get(Calendar.HOUR_OF_DAY)
    }

    private fun eventsIn(vm: PlayerViewModel, n: String): List<Event> {
        var ev = vm.readEvents()
        val r = range(n)
        if (r != null) ev = ev.filter { it.ts >= r.first && it.ts < r.second }
        if (partName(n).isNotEmpty()) ev = ev.filter { inPart(n, hourOf(it.ts)) }
        return ev
    }

    private fun ctxText(n: String): String {
        val parts = listOf(rangeName(n), partName(n)).filter { it.isNotEmpty() }
        return if (parts.isEmpty()) "" else " " + parts.joinToString(" ")
    }

    private fun topSongs(vm: PlayerViewModel, ev: List<Event>, limit: Int): List<Pair<Song, Int>> {
        val byKey = vm.raw.associateBy { vm.songKey(it) }
        return ev.groupingBy { it.key }.eachCount().entries.sortedByDescending { it.value }
            .mapNotNull { e -> byKey[e.key]?.let { it to e.value } }.take(limit)
    }

    private fun findSong(vm: PlayerViewModel, n: String): Song? {
        val toks = n.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 3 && it !in stop }
        if (toks.isEmpty()) return null
        var best: Song? = null
        var bestScore = 0
        for (s in vm.raw) {
            val title = normAr(s.title.lowercase())
            var sc = 0
            for (w in toks) if (title.contains(w)) sc++
            val b = best
            if (sc > bestScore || (sc == bestScore && sc > 0 && b != null && s.title.length < b.title.length)) {
                best = s
                bestScore = sc
            }
        }
        return if (bestScore >= 1) best else null
    }

    fun answer(raw: String, vm: PlayerViewModel): String {
        val n = normAr(raw.lowercase()).replace("؟", " ").replace("?", " ").trim()
        fun has(vararg w: String): Boolean = w.any { n.contains(it) }

        if (n.startsWith("تذكر") && !has("شنو")) {
            val note = raw.trim().substringAfter("تذكر").trim()
            if (note.isBlank()) return "شنو تريدني أتذكر؟"
            vm.addNote(note)
            return "تمام، حفظتها: «" + t(note) + "»"
        }
        if (has("شنو تتذكر", "شنو تعرف عني", "ملاحظاتي")) {
            val ns = vm.notes()
            if (ns.isEmpty()) return "ماكو شي محفوظ. كلي: تذكر إني أحب ..."
            return "اللي أتذكره عنك:\n" + ns.joinToString("\n") { "• " + it }
        }
        if (n.startsWith("انسى")) {
            vm.clearNotes()
            return "مسحت كل الملاحظات."
        }

        if (n.startsWith("شغل") || has("شغللي")) {
            val target = n.removePrefix("شغللي").removePrefix("شغل").trim().removePrefix("لي").trim()
            val c = cat(target)
            val picked: Pair<String, List<Song>>? = when {
                target.contains("مفضل") -> "المفضلة" to vm.songs.filter { it.path in vm.favs }
                target.contains("اكثر") && target.contains("سمع") ->
                    "الأكثر سماعاً" to vm.songs.filter { vm.playCount(it) > 0 }
                        .sortedByDescending { vm.playCount(it) }.take(50)
                c != null -> c to vm.songs.filter { vm.cats[it.path] == c }.shuffled()
                else -> findSong(vm, target)?.let { it.title to listOf(it) }
            }
            if (picked == null || picked.second.isEmpty()) {
                return "ما لقيت شي أشغله بهالاسم. جرّب: شغل قرآن، أو شغل اسم الأغنية."
            }
            vm.playList(picked.second)
            return "شغلت: " + t(picked.first) + " (" + picked.second.size + " أغنية)"
        }

        if (has("كم مره") && has("سمعت", "شغلت", "اسمع")) {
            val s = findSong(vm, n) ?: vm.current
                ?: return "ما كدرت أعرف أي أغنية تقصد. شغل أغنية أو اكتب اسمها."
            val cnt = vm.playCount(s)
            val last = vm.lastPlayedAt(s)
            return "سمعت «" + t(s.title) + "» " + cnt + " مرة" +
                (if (last > 0) "، وآخر مرة " + fmt(last) else "") + "."
        }

        if (has("اسمع", "سمعت") && partName(n).isNotEmpty() && has("شنو", "اي", "ايش")) {
            val ev = eventsIn(vm, n)
            val tally = ev.filter { it.cat.isNotEmpty() }.groupingBy { it.cat }.eachCount()
                .entries.sortedByDescending { it.value }.take(3)
            if (tally.isEmpty()) return NO_DATA
            return "أكثر شي تسمعه" + ctxText(n) + ":\n" +
                tally.joinToString("\n") { "• " + it.key + " (" + it.value + " مرة)" }
        }

        if (has("اكثر") && has("قسم", "نوع", "اصناف")) {
            val tally = eventsIn(vm, n).filter { it.cat.isNotEmpty() }.groupingBy { it.cat }.eachCount()
                .entries.sortedByDescending { it.value }.take(3)
            if (tally.isEmpty()) return NO_DATA
            return "أكثر الأقسام" + ctxText(n) + ":\n" +
                tally.joinToString("\n") { "• " + it.key + " (" + it.value + " مرة)" }
        }

        if (has("اكثر") && has("اغنيه", "اغاني", "سمعته", "سمعتها", "شي")) {
            val top = topSongs(vm, eventsIn(vm, n), 5)
            if (top.isEmpty()) return NO_DATA
            return "أكثر أغاني سمعتها" + ctxText(n) + ":\n" +
                top.mapIndexed { i, p -> (i + 1).toString() + ". " + t(p.first.title) + " (" + p.second + ")" }
                    .joinToString("\n")
        }

        if (has("شنو سمعت", "شسمعت", "اخر شي سمعت", "اخر اغنيه", "اخر اغاني")) {
            val byKey = vm.raw.associateBy { vm.songKey(it) }
            val rec = eventsIn(vm, n).sortedByDescending { it.ts }.distinctBy { it.key }
                .mapNotNull { byKey[it.key] }.take(8)
            if (rec.isEmpty()) return NO_DATA
            return "سمعت" + ctxText(n) + ":\n" + rec.joinToString("\n") { "• " + t(it.title) }
        }

        if (has("كم") && has("اغنيه", "اغاني") && has("عندي", "بالمكتبه", "مكتبتي")) {
            val c = cat(n)
            return if (c != null) {
                "عندك " + vm.songs.count { vm.cats[it.path] == c } + " أغنية بقسم " + c + "."
            } else {
                "عندك " + vm.songs.size + " أغنية، منها " + vm.songs.count { it.path in vm.cats } + " مصنفة."
            }
        }

        if (has("ما سمعتها", "ما سمعت", "منسيه", "نسيتها")) {
            val never = vm.songs.filter { vm.playCount(it) == 0 }
            if (never.isEmpty()) return "كل أغانيك سمعتها مرة على الأقل."
            return "عندك " + never.size + " أغنية ما سمعتها للحين، مثلاً:\n" +
                never.shuffled().take(5).joinToString("\n") { "• " + t(it.title) }
        }

        return "ما فهمت سؤالك زين. جرّب مثلاً:\n" +
            "• هاي الأغنية كم مرة سمعتها؟\n" +
            "• شنو أكثر أغاني سمعتها هالأسبوع؟\n" +
            "• شنو أكثر قسم أسمعه بالليل؟\n" +
            "• شنو سمعت اليوم؟\n" +
            "• أغاني ما سمعتها\n" +
            "• كم أغنية عندي بقسم الراب؟\n" +
            "• شغل لي موال\n" +
            "• تذكر إني أحب ..."
    }
}
