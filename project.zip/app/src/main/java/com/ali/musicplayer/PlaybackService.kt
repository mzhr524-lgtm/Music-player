package com.ali.musicplayer

import android.Manifest
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.media.audiofx.Equalizer
import android.media.audiofx.Visualizer
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private var eq: Equalizer? = null
    private var viz: Visualizer? = null
    private var curId = C.AUDIO_SESSION_ID_UNSET
    private val smooth = FloatArray(32)
    private lateinit var prefs: SharedPreferences
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "eq") applyEq()
        if (key == "vizTick") setupViz(curId)
    }

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("lib", MODE_PRIVATE)
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                curId = audioSessionId
                setupEq(audioSessionId)
                setupViz(audioSessionId)
            }
        })
        curId = player.audioSessionId
        setupEq(curId)
        setupViz(curId)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        session = MediaSession.Builder(this, player).build()
    }

    private fun setupEq(id: Int) {
        eq?.release()
        eq = null
        if (id == C.AUDIO_SESSION_ID_UNSET) return
        try {
            eq = Equalizer(0, id).also { it.enabled = true }
            applyEq()
        } catch (e: Exception) {
            eq = null
        }
    }

    private fun applyEq() {
        val e = eq ?: return
        try {
            val levels = prefs.getString("eq", "")!!.split(",").mapNotNull { it.toIntOrNull() }
            val range = e.bandLevelRange
            for (b in 0 until e.numberOfBands) {
                val lv = levels.getOrElse(b) { 0 }.coerceIn(range[0].toInt(), range[1].toInt())
                e.setBandLevel(b.toShort(), lv.toShort())
            }
        } catch (ex: Exception) {
        }
    }

    private fun setupViz(id: Int) {
        try { viz?.release() } catch (e: Exception) { }
        viz = null
        if (id == C.AUDIO_SESSION_ID_UNSET) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) return
        try {
            val v = Visualizer(id)
            v.enabled = false
            v.captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024)
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(vis: Visualizer?, waveform: ByteArray?, samplingRate: Int) {}
                override fun onFftDataCapture(vis: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                    if (fft != null) pushFft(fft)
                }
            }, Visualizer.getMaxCaptureRate() / 2, false, true)
            v.enabled = true
            viz = v
        } catch (e: Exception) {
            viz = null
        }
    }

    private fun pushFft(fft: ByteArray) {
        val n = fft.size / 2
        val bins = (n * 0.45f).toInt().coerceAtLeast(32)
        val out = FloatArray(32)
        for (b in 0 until 32) {
            val from = 1 + b * bins / 32
            val to = minOf(1 + (b + 1) * bins / 32, n)
            var m = 0f
            for (k in from until to) {
                val re = fft[2 * k].toInt()
                val im = fft[2 * k + 1].toInt()
                m = maxOf(m, kotlin.math.sqrt((re * re + im * im).toFloat()))
            }
            val level = (kotlin.math.sqrt(m / 90f) * (1f + b / 20f)).coerceIn(0f, 1f)
            smooth[b] = maxOf(level, smooth[b] * 0.8f)
            out[b] = smooth[b]
        }
        Spectrum.bands = out
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        try { viz?.release() } catch (e: Exception) { }
        eq?.release()
        session?.run { player.release(); release() }
        session = null
        super.onDestroy()
    }
}
