package com.ali.musicplayer

import android.content.SharedPreferences
import android.media.audiofx.Equalizer
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private var eq: Equalizer? = null
    private lateinit var prefs: SharedPreferences
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "eq") applyEq()
    }

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("lib", MODE_PRIVATE)
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                setupEq(audioSessionId)
            }
        })
        setupEq(player.audioSessionId)
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        session = MediaSession.Builder(this, player).build()
    }

    private fun setupEq(id: Int) {
        eq?.release()
        eq = null
        if (id == C.AUDIO_SESSION_ID_UNSET) return
        try {
            eq = Equalizer(0, id).also { it.enabled = true }
            applyEq()
        } catch (e: Exception) {
            eq = null
        }
    }

    private fun applyEq() {
        val e = eq ?: return
        try {
            val levels = prefs.getString("eq", "")!!.split(",").mapNotNull { it.toIntOrNull() }
            val range = e.bandLevelRange
            for (b in 0 until e.numberOfBands) {
                val lv = levels.getOrElse(b) { 0 }.coerceIn(range[0].toInt(), range[1].toInt())
                e.setBandLevel(b.toShort(), lv.toShort())
            }
        } catch (ex: Exception) {
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onDestroy() {
        prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
        eq?.release()
        session?.run { player.release(); release() }
        session = null
        super.onDestroy()
    }
}
