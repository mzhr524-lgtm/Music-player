package com.ali.musicplayer

import android.app.Application
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore.Audio.Media
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import org.json.JSONObject
import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Job

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val uri: Uri,
    val folder: String,
    val path: String
)

object MediaScanner {
    @Suppress("DEPRECATION")
    fun scan(ctx: Context, minMs: Long): List<Song> {
        val out = ArrayList<Song>()
        val proj = arrayOf(Media._ID, Media.TITLE, Media.ARTIST, Media.DURATION, Media.DATA, Media.SIZE)
        val sel = "${Media.DURATION} >= $minMs AND ${Media.IS_RINGTONE} = 0 AND " +
            "${Media.IS_NOTIFICATION} = 0 AND ${Media.IS_ALARM} = 0"
        ctx.contentResolver.query(Media.EXTERNAL_CONTENT_URI, proj, sel, null, "${Media.TITLE} ASC")?.use { c ->
            val iId = c.getColumnIndexOrThrow(Media._ID)
            val iTitle = c.getColumnIndexOrThrow(Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(Media.ARTIST)
            val iDur = c.getColumnIndexOrThrow(Media.DURATION)
            val iData = c.getColumnIndexOrThrow(Media.DATA)
            val iSize = c.getColumnIndexOrThrow(Media.SIZE)
            val seen = HashSet<String>()
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val path = c.getString(iData) ?: ""
                if (!seen.add("${c.getLong(iSize)}|${c.getLong(iDur)}")) continue
                val artist = c.getString(iArtist)?.takeIf { it != "<unknown>" } ?: ""
                out += Song(
                    id = id,
                    title = c.getString(iTitle) ?: "",
                    artist = artist,
                    durationMs = c.getLong(iDur),
                    uri = ContentUris.withAppendedId(Media.EXTERNAL_CONTENT_URI, id),
                    folder = File(path).parentFile?.name ?: "",
                    path = path
                )
            }
        }
        return out
    }
}

class PlayerViewModel(app: Application) : AndroidViewModel(app) {
    var songs by mutableStateOf<List<Song>>(emptyList())
        private set
    var current by mutableStateOf<Song?>(null)
        private set
    var playing by mutableStateOf(false)
        private set
    var position by mutableStateOf(0L)
        private set
    var duration by mutableStateOf(0L)
        private set

    private val prefs = app.getSharedPreferences("lib", Context.MODE_PRIVATE)

    var cats by mutableStateOf(loadMap())
        private set
    var favs by mutableStateOf<Set<String>>(prefs.getStringSet("favs", emptySet())?.toSet() ?: emptySet())
        private set

    var minSec by mutableStateOf(prefs.getInt("minSec", 10))
        private set
    var bgBright by mutableStateOf(prefs.getFloat("bgBright", 0.5f))
        private set
    var bgBlur by mutableStateOf(prefs.getFloat("bgBlur", 8f))
        private set
    var bg by mutableStateOf<ImageBitmap?>(loadBg())
        private set
    var eqLevels by mutableStateOf<List<Int>>(loadEq())
        private set
    var sleepLeft by mutableStateOf(0L)
        private set
    var sleepEndOfSong by mutableStateOf(false)
        private set

    private var sleepJob: Job? = null
    private var controller: MediaController? = null

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            val c = future.get()
            controller = c
            playing = c.isPlaying
            c.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    playing = isPlaying
                }

                override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                    current = songs.firstOrNull { it.id.toString() == item?.mediaId }
                    position = 0L
                    if (sleepEndOfSong && reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) {
                        controller?.pause()
                        sleepEndOfSong = false
                    }
                }
            })
        }, ContextCompat.getMainExecutor(app))

        viewModelScope.launch {
            while (true) {
                delay(500)
                controller?.let { c ->
                    if (c.isPlaying) {
                        position = c.currentPosition
                        duration = c.duration.coerceAtLeast(0L)
                    }
                }
            }
        }
    }

    fun load() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) { MediaScanner.scan(getApplication(), minSec * 1000L) }
            songs = list
        }
    }

    fun play(list: List<Song>, index: Int) {
        val c = controller ?: return
        c.setMediaItems(list.map { it.toItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    private fun loadMap(): Map<String, String> {
        val o = JSONObject(prefs.getString("cats", "{}") ?: "{}")
        return o.keys().asSequence().associateWith { o.getString(it) }
    }

    fun setCategory(s: Song, cat: String?) {
        cats = if (cat == null) cats - s.path else cats + (s.path to cat)
        prefs.edit().putString("cats", JSONObject(cats).toString()).apply()
    }

    fun toggleFav(s: Song) {
        favs = if (s.path in favs) favs - s.path else favs + s.path
        prefs.edit().putStringSet("favs", favs).apply()
    }

    private fun loadEq(): List<Int> {
        val l = (prefs.getString("eq", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }
        return List(5) { l.getOrElse(it) { 0 } }
    }

    fun setEq(levels: List<Int>) {
        eqLevels = levels
        prefs.edit().putString("eq", levels.joinToString(",")).apply()
    }

    fun updateMinSec(v: Int) {
        minSec = v
        prefs.edit().putInt("minSec", v).apply()
        load()
    }

    fun updateBright(v: Float) {
        bgBright = v
        prefs.edit().putFloat("bgBright", v).apply()
    }

    fun updateBlur(v: Float) {
        bgBlur = v
        prefs.edit().putFloat("bgBlur", v).apply()
    }

    private fun bgFile() = File(getApplication<Application>().filesDir, "bg.jpg")

    private fun decodeBg(f: File): ImageBitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / s > 1600) s *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = s }
        return BitmapFactory.decodeFile(f.path, opts)?.asImageBitmap()
    }

    private fun loadBg(): ImageBitmap? = bgFile().takeIf { it.exists() }?.let { decodeBg(it) }

    fun setBgFromUri(uri: Uri) {
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                val f = bgFile()
                getApplication<Application>().contentResolver.openInputStream(uri)?.use { i ->
                    f.outputStream().use { o -> i.copyTo(o) }
                }
                decodeBg(f)
            }
            bg = bmp
        }
    }

    fun clearBg() {
        bgFile().delete()
        bg = null
    }

    fun startSleep(minutes: Int) {
        cancelSleep()
        sleepJob = viewModelScope.launch {
            sleepLeft = minutes * 60L
            while (sleepLeft > 0) {
                delay(1000)
                sleepLeft--
            }
            val c = controller
            if (c != null) {
                for (i in 10 downTo 1) {
                    c.volume = i / 10f
                    delay(500)
                }
                c.pause()
                c.volume = 1f
            }
        }
    }

    fun sleepAfterSong() {
        cancelSleep()
        sleepEndOfSong = true
    }

    fun cancelSleep() {
        sleepJob?.cancel()
        sleepLeft = 0L
        sleepEndOfSong = false
    }

    fun toggle() {
        controller?.let { if (it.isPlaying) it.pause() else it.play() }
    }

    fun next() { controller?.seekToNextMediaItem() }

    fun prev() { controller?.seekToPreviousMediaItem() }

    fun seek(ms: Long) {
        controller?.seekTo(ms)
        position = ms
    }

    private fun Song.toItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist(artist).build())
        .build()
}
