package com.ali.musicplayer

import android.app.Application
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore.Audio.Media
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import org.json.JSONObject
import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Job
import android.media.MediaScannerConnection
import android.os.Environment
import android.widget.Toast
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import android.media.MediaMetadataRetriever
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.palette.graphics.Palette

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val uri: Uri,
    val folder: String,
    val path: String,
    val size: Long = 0L
)

object MediaScanner {
    @Suppress("DEPRECATION")
    fun scan(ctx: Context, minMs: Long): List<Song> {
        val out = ArrayList<Song>()
        val proj = arrayOf(Media._ID, Media.TITLE, Media.ARTIST, Media.DURATION, Media.DATA, Media.SIZE)
        val sel = "${Media.DURATION} >= $minMs AND ${Media.IS_RINGTONE} = 0 AND " +
            "${Media.IS_NOTIFICATION} = 0 AND ${Media.IS_ALARM} = 0"
        ctx.contentResolver.query(Media.EXTERNAL_CONTENT_URI, proj, sel, null, "${Media.TITLE} ASC")?.use { c ->
            val iId = c.getColumnIndexOrThrow(Media._ID)
            val iTitle = c.getColumnIndexOrThrow(Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(Media.ARTIST)
            val iDur = c.getColumnIndexOrThrow(Media.DURATION)
            val iData = c.getColumnIndexOrThrow(Media.DATA)
            val iSize = c.getColumnIndexOrThrow(Media.SIZE)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val path = c.getString(iData) ?: ""
                val artist = c.getString(iArtist)?.takeIf { it != "<unknown>" } ?: ""
                out += Song(
                    id = id,
                    title = c.getString(iTitle) ?: "",
                    artist = artist,
                    durationMs = c.getLong(iDur),
                    uri = ContentUris.withAppendedId(Media.EXTERNAL_CONTENT_URI, id),
                    folder = File(path).parentFile?.name ?: "",
                    path = path,
                    size = c.getLong(iSize)
                )
            }
        }
        return out
    }
}

class PlayerViewModel(app: Application) : AndroidViewModel(app) {
    var songs by mutableStateOf<List<Song>>(emptyList())
        private set
    var current by mutableStateOf<Song?>(null)
        private set
    var playing by mutableStateOf(false)
        private set
    var position by mutableStateOf(0L)
        private set
    var duration by mutableStateOf(0L)
        private set

    private val prefs = app.getSharedPreferences("lib", Context.MODE_PRIVATE)

    var cats by mutableStateOf(loadMap())
        private set
    var favs by mutableStateOf<Set<String>>(prefs.getStringSet("favs", emptySet())?.toSet() ?: emptySet())
        private set

    var minSec by mutableStateOf(prefs.getInt("minSec", 10))
        private set
    var bgBright by mutableStateOf(prefs.getFloat("bgBright", 0.5f))
        private set
    var bgBlur by mutableStateOf(prefs.getFloat("bgBlur", 8f))
        private set
    var bg by mutableStateOf<ImageBitmap?>(loadBg())
        private set
    var eqLevels by mutableStateOf<List<Int>>(loadEq())
        private set
    var sleepLeft by mutableStateOf(0L)
        private set
    var sleepEndOfSong by mutableStateOf(false)
        private set

    private var sleepJob: Job? = null
    private var artJob: Job? = null

    var raw by mutableStateOf<List<Song>>(emptyList())
        private set
    var dupGroups by mutableStateOf<List<List<Song>>>(emptyList())
        private set
    var shuffle by mutableStateOf(false)
        private set
    var repeatMode by mutableStateOf(0)
        private set
    var skipSec by mutableStateOf(prefs.getInt("skipSec", 15))
        private set
    var coverSquare by mutableStateOf(prefs.getBoolean("square", false))
        private set
    var art by mutableStateOf<ImageBitmap?>(null)
        private set
    var artColor by mutableStateOf(Color(0xFF3A2A5E))
        private set
    var hiddenDirs by mutableStateOf<Set<String>>(prefs.getStringSet("hiddenDirs", emptySet())?.toSet() ?: emptySet())
        private set
    var shownDirs by mutableStateOf<Set<String>>(prefs.getStringSet("shownDirs", emptySet())?.toSet() ?: emptySet())
        private set
    var autoVoice by mutableStateOf(prefs.getBoolean("autoVoice", true))
        private set
    private var controller: MediaController? = null

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            val c = future.get()
            controller = c
            playing = c.isPlaying
            c.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    playing = isPlaying
                }

                override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                    shuffle = shuffleModeEnabled
                }

                override fun onRepeatModeChanged(mode: Int) {
                    repeatMode = mode
                }

                override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                    current = raw.firstOrNull { it.id.toString() == item?.mediaId }
                    loadArt(current)
                    position = 0L
                    if (sleepEndOfSong && reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) {
                        controller?.pause()
                        sleepEndOfSong = false
                    }
                }
            })
        }, ContextCompat.getMainExecutor(app))

        viewModelScope.launch {
            while (true) {
                delay(500)
                controller?.let { c ->
                    if (c.isPlaying) {
                        position = c.currentPosition
                        duration = c.duration.coerceAtLeast(0L)
                    }
                }
            }
        }
    }

    fun load() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) { MediaScanner.scan(getApplication(), minSec * 1000L) }
            val groups = list.groupBy { it.size to it.durationMs }.values
            val keep = groups.map { g -> g.minByOrNull { it.path.length }!!.id }.toSet()
            raw = list.filter { it.id in keep }
            dupGroups = groups.filter { it.size > 1 }.map { g -> g.sortedBy { it.path.length } }
            applyFilter()
        }
    }

    fun play(list: List<Song>, index: Int) {
        val c = controller ?: return
        c.setMediaItems(list.map { it.toItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    private fun loadMap(): Map<String, String> {
        val o = JSONObject(prefs.getString("cats", "{}") ?: "{}")
        return o.keys().asSequence().associateWith { o.getString(it) }
    }

    fun setCategory(s: Song, cat: String?) {
        cats = if (cat == null) cats - s.path else cats + (s.path to cat)
        prefs.edit().putString("cats", JSONObject(cats).toString()).apply()
    }

    fun toggleFav(s: Song) {
        favs = if (s.path in favs) favs - s.path else favs + s.path
        prefs.edit().putStringSet("favs", favs).apply()
    }

    private fun voiceDir(dir: String): Boolean {
        val names = setOf(
            "recordings", "voice recorder", "voice notes", "whatsapp voice notes", "call", "calls",
            "sound recorder", "audio recorder", "voicenotes", "ptt"
        )
        return dir.lowercase().split("/").any {
            it in names || it.contains("voice note") || it.contains("call record")
        }
    }

    fun dirHidden(dir: String): Boolean =
        dir in hiddenDirs || (autoVoice && voiceDir(dir) && dir !in shownDirs)

    private fun applyFilter() {
        songs = raw.filter { !dirHidden(File(it.path).parent ?: "") }
    }

    fun folderStats(): List<Pair<String, Int>> =
        raw.groupBy { File(it.path).parent ?: "" }.map { it.key to it.value.size }.sortedByDescending { it.second }

    fun toggleDir(dir: String) {
        if (dirHidden(dir)) {
            hiddenDirs = hiddenDirs - dir
            shownDirs = shownDirs + dir
        } else {
            hiddenDirs = hiddenDirs + dir
            shownDirs = shownDirs - dir
        }
        prefs.edit().putStringSet("hiddenDirs", hiddenDirs).putStringSet("shownDirs", shownDirs).apply()
        applyFilter()
    }

    fun updateAutoVoice(v: Boolean) {
        autoVoice = v
        prefs.edit().putBoolean("autoVoice", v).apply()
        applyFilter()
    }

    fun setCategoryMany(list: List<Song>, cat: String?) {
        var m = cats
        for (s in list) m = if (cat == null) m - s.path else m + (s.path to cat)
        cats = m
        prefs.edit().putString("cats", JSONObject(cats).toString()).apply()
    }

    fun favMany(list: List<Song>, add: Boolean) {
        var f = favs
        for (s in list) f = if (add) f + s.path else f - s.path
        favs = f
        prefs.edit().putStringSet("favs", favs).apply()
    }

    fun rescan() {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val found = withContext(Dispatchers.IO) {
                val exts = setOf("mp3", "m4a", "aac", "wav", "flac", "ogg", "opus", "wma", "amr", "m4b")
                val out = ArrayList<String>()
                fun walk(d: File, depth: Int) {
                    if (depth > 8) return
                    val kids = d.listFiles() ?: return
                    for (f in kids) {
                        if (f.isDirectory) {
                            if (f.name != "Android" && !f.name.startsWith(".")) walk(f, depth + 1)
                        } else if (f.extension.lowercase() in exts) {
                            out.add(f.path)
                        }
                    }
                }
                walk(Environment.getExternalStorageDirectory(), 0)
                out
            }
            if (found.isNotEmpty()) {
                val done = CompletableDeferred<Unit>()
                val left = AtomicInteger(found.size)
                MediaScannerConnection.scanFile(ctx, found.toTypedArray(), null) { _, _ ->
                    if (left.decrementAndGet() == 0) done.complete(Unit)
                }
                withTimeoutOrNull(60_000L) { done.await() }
            }
            load()
            Toast.makeText(ctx, "تم فحص " + found.size + " ملف صوتي", Toast.LENGTH_LONG).show()
        }
    }

    fun pingViz() {
        prefs.edit().putLong("vizTick", System.currentTimeMillis()).apply()
    }

    fun toggleShuffle() {
        controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    }

    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    fun skip(sign: Int) {
        controller?.let { c ->
            c.seekTo((c.currentPosition + sign * skipSec * 1000L).coerceAtLeast(0L))
            position = c.currentPosition
        }
    }

    fun updateSkip(v: Int) {
        skipSec = v
        prefs.edit().putInt("skipSec", v).apply()
    }

    fun toggleCover() {
        coverSquare = !coverSquare
        prefs.edit().putBoolean("square", coverSquare).apply()
    }

    fun saveAccent(c: Color) {
        Gold = c
        prefs.edit().putInt("accent", c.toArgb()).apply()
    }

    private fun decodeSampled(bytes: ByteArray, maxDim: Int): android.graphics.Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var s = 1
        while (o.outWidth / s > maxDim) s *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = s }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }

    private fun loadArt(s: Song?) {
        artJob?.cancel()
        val fallback = 0xFF3A2A5E.toInt()
        if (s == null) {
            art = null
            artColor = Color(fallback)
            return
        }
        artJob = viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                val mmr = MediaMetadataRetriever()
                try {
                    mmr.setDataSource(getApplication<Application>(), s.uri)
                    val bytes = mmr.embeddedPicture
                    if (bytes == null) null else decodeSampled(bytes, 800)
                } catch (e: Exception) {
                    null
                } finally {
                    try { mmr.release() } catch (e: Exception) { }
                }
            }
            if (bmp == null) {
                art = null
                artColor = Color(fallback)
            } else {
                art = bmp.asImageBitmap()
                val rgb = withContext(Dispatchers.Default) {
                    val p = Palette.from(bmp).generate()
                    p.getDarkVibrantColor(p.getDominantColor(fallback))
                }
                artColor = Color(rgb)
            }
        }
    }

    private fun loadEq(): List<Int> {
        val l = (prefs.getString("eq", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }
        return List(5) { l.getOrElse(it) { 0 } }
    }

    fun setEq(levels: List<Int>) {
        eqLevels = levels
        prefs.edit().putString("eq", levels.joinToString(",")).apply()
    }

    fun updateMinSec(v: Int) {
        minSec = v
        prefs.edit().putInt("minSec", v).apply()
        load()
    }

    fun updateBright(v: Float) {
        bgBright = v
        prefs.edit().putFloat("bgBright", v).apply()
    }

    fun updateBlur(v: Float) {
        bgBlur = v
        prefs.edit().putFloat("bgBlur", v).apply()
    }

    private fun bgFile() = File(getApplication<Application>().filesDir, "bg.jpg")

    private fun decodeBg(f: File): ImageBitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / s > 1600) s *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = s }
        return BitmapFactory.decodeFile(f.path, opts)?.asImageBitmap()
    }

    private fun loadBg(): ImageBitmap? = bgFile().takeIf { it.exists() }?.let { decodeBg(it) }

    fun setBgFromUri(uri: Uri) {
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                val f = bgFile()
                getApplication<Application>().contentResolver.openInputStream(uri)?.use { i ->
                    f.outputStream().use { o -> i.copyTo(o) }
                }
                decodeBg(f)
            }
            bg = bmp
        }
    }

    fun clearBg() {
        bgFile().delete()
        bg = null
    }

    fun startSleep(minutes: Int) {
        cancelSleep()
        sleepJob = viewModelScope.launch {
            sleepLeft = minutes * 60L
            while (sleepLeft > 0) {
                delay(1000)
                sleepLeft--
            }
            val c = controller
            if (c != null) {
                for (i in 10 downTo 1) {
                    c.volume = i / 10f
                    delay(500)
                }
                c.pause()
                c.volume = 1f
            }
        }
    }

    fun sleepAfterSong() {
        cancelSleep()
        sleepEndOfSong = true
    }

    fun cancelSleep() {
        sleepJob?.cancel()
        sleepLeft = 0L
        sleepEndOfSong = false
    }

    fun toggle() {
        controller?.let { if (it.isPlaying) it.pause() else it.play() }
    }

    fun next() { controller?.seekToNextMediaItem() }

    fun prev() { controller?.seekToPreviousMediaItem() }

    fun seek(ms: Long) {
        controller?.seekTo(ms)
        position = ms
    }

    private fun Song.toItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist(artist).build())
        .build()
}

object Spectrum {
    var bands by mutableStateOf(FloatArray(32))
}
