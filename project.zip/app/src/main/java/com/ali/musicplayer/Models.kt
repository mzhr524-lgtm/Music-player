package com.ali.musicplayer

import android.app.Application
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore.Audio.Media
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val uri: Uri,
    val folder: String
)

object MediaScanner {
    @Suppress("DEPRECATION")
    fun scan(ctx: Context): List<Song> {
        val out = ArrayList<Song>()
        val proj = arrayOf(Media._ID, Media.TITLE, Media.ARTIST, Media.DURATION, Media.DATA)
        val sel = "${Media.DURATION} >= 10000 AND ${Media.IS_RINGTONE} = 0 AND " +
            "${Media.IS_NOTIFICATION} = 0 AND ${Media.IS_ALARM} = 0"
        ctx.contentResolver.query(Media.EXTERNAL_CONTENT_URI, proj, sel, null, "${Media.TITLE} ASC")?.use { c ->
            val iId = c.getColumnIndexOrThrow(Media._ID)
            val iTitle = c.getColumnIndexOrThrow(Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(Media.ARTIST)
            val iDur = c.getColumnIndexOrThrow(Media.DURATION)
            val iData = c.getColumnIndexOrThrow(Media.DATA)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val artist = c.getString(iArtist)?.takeIf { it != "<unknown>" } ?: ""
                out += Song(
                    id = id,
                    title = c.getString(iTitle) ?: "",
                    artist = artist,
                    durationMs = c.getLong(iDur),
                    uri = ContentUris.withAppendedId(Media.EXTERNAL_CONTENT_URI, id),
                    folder = File(c.getString(iData) ?: "").parentFile?.name ?: ""
                )
            }
        }
        return out
    }
}

class PlayerViewModel(app: Application) : AndroidViewModel(app) {
    var songs by mutableStateOf<List<Song>>(emptyList())
        private set
    var current by mutableStateOf<Song?>(null)
        private set
    var playing by mutableStateOf(false)
        private set
    var position by mutableStateOf(0L)
        private set
    var duration by mutableStateOf(0L)
        private set

    private var controller: MediaController? = null

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            val c = future.get()
            controller = c
            playing = c.isPlaying
            c.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    playing = isPlaying
                }

                override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                    current = songs.firstOrNull { it.id.toString() == item?.mediaId }
                    position = 0L
                }
            })
        }, ContextCompat.getMainExecutor(app))

        viewModelScope.launch {
            while (true) {
                delay(500)
                controller?.let { c ->
                    if (c.isPlaying) {
                        position = c.currentPosition
                        duration = c.duration.coerceAtLeast(0L)
                    }
                }
            }
        }
    }

    fun load() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) { MediaScanner.scan(getApplication()) }
            songs = list
        }
    }

    fun play(index: Int) {
        val c = controller ?: return
        c.setMediaItems(songs.map { it.toItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    fun toggle() {
        controller?.let { if (it.isPlaying) it.pause() else it.play() }
    }

    fun next() { controller?.seekToNextMediaItem() }

    fun prev() { controller?.seekToPreviousMediaItem() }

    fun seek(ms: Long) {
        controller?.seekTo(ms)
        position = ms
    }

    private fun Song.toItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist(artist).build())
        .build()
}
