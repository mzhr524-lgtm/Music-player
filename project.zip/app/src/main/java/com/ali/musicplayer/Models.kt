package com.ali.musicplayer

import android.app.Application
import android.content.ComponentName
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore.Audio.Media
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import org.json.JSONObject
import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Job
import androidx.media3.common.C
import androidx.media3.common.Timeline
import kotlinx.coroutines.isActive
import android.media.AudioManager
import org.json.JSONArray
import androidx.media3.common.PlaybackParameters
import android.media.MediaScannerConnection
import android.os.Environment
import android.widget.Toast
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import android.media.MediaMetadataRetriever
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.palette.graphics.Palette

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val uri: Uri,
    val folder: String,
    val path: String,
    val size: Long = 0L,
    val dateAdded: Long = 0L
)

object MediaScanner {
    @Suppress("DEPRECATION")
    fun scan(ctx: Context, minMs: Long): List<Song> {
        val out = ArrayList<Song>()
        val proj = arrayOf(Media._ID, Media.TITLE, Media.ARTIST, Media.DURATION, Media.DATA, Media.SIZE, Media.DATE_ADDED)
        val sel = "${Media.DURATION} >= $minMs AND ${Media.IS_RINGTONE} = 0 AND " +
            "${Media.IS_NOTIFICATION} = 0 AND ${Media.IS_ALARM} = 0"
        ctx.contentResolver.query(Media.EXTERNAL_CONTENT_URI, proj, sel, null, "${Media.TITLE} ASC")?.use { c ->
            val iId = c.getColumnIndexOrThrow(Media._ID)
            val iTitle = c.getColumnIndexOrThrow(Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(Media.ARTIST)
            val iDur = c.getColumnIndexOrThrow(Media.DURATION)
            val iData = c.getColumnIndexOrThrow(Media.DATA)
            val iSize = c.getColumnIndexOrThrow(Media.SIZE)
            val iAdded = c.getColumnIndexOrThrow(Media.DATE_ADDED)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val path = c.getString(iData) ?: ""
                val artist = c.getString(iArtist)?.takeIf { it != "<unknown>" } ?: ""
                out += Song(
                    id = id,
                    title = c.getString(iTitle) ?: "",
                    artist = artist,
                    durationMs = c.getLong(iDur),
                    uri = ContentUris.withAppendedId(Media.EXTERNAL_CONTENT_URI, id),
                    folder = File(path).parentFile?.name ?: "",
                    path = path,
                    size = c.getLong(iSize),
                    dateAdded = c.getLong(iAdded)
                )
            }
        }
        return out
    }
}

class PlayerViewModel(app: Application) : AndroidViewModel(app) {
    var songs by mutableStateOf<List<Song>>(emptyList())
        private set
    var current by mutableStateOf<Song?>(null)
        private set
    var playing by mutableStateOf(false)
        private set
    var position by mutableStateOf(0L)
        private set
    var duration by mutableStateOf(0L)
        private set

    private val prefs = app.getSharedPreferences("lib", Context.MODE_PRIVATE)

    var cats by mutableStateOf(loadMap())
        private set
    var favs by mutableStateOf<Set<String>>(prefs.getStringSet("favs", emptySet())?.toSet() ?: emptySet())
        private set

    var minSec by mutableStateOf(prefs.getInt("minSec", 10))
        private set
    var bgBright by mutableStateOf(prefs.getFloat("bgBright", 0.5f))
        private set
    var bgBlur by mutableStateOf(prefs.getFloat("bgBlur", 8f))
        private set
    var bg by mutableStateOf<ImageBitmap?>(loadBg())
        private set
    var eqLevels by mutableStateOf<List<Int>>(loadEq())
        private set
    var sleepLeft by mutableStateOf(0L)
        private set
    var sleepEndOfSong by mutableStateOf(false)
        private set

    private var sleepJob: Job? = null
    private var artJob: Job? = null

    var raw by mutableStateOf<List<Song>>(emptyList())
        private set
    var dupGroups by mutableStateOf<List<List<Song>>>(emptyList())
        private set
    var analyzing by mutableStateOf(false)
        private set
    var analysisDone by mutableStateOf(0)
        private set
    var analysisTotal by mutableStateOf(0)
        private set
    var audioVersion by mutableStateOf(0)
        private set
    private val audioMap = HashMap<Int, FloatArray>()
    private val deepSet = HashSet<Int>()
    var deepMode by mutableStateOf(prefs.getBoolean("deepMode", false))
    var openSuggest by mutableStateOf(prefs.getBoolean("openSuggest", true))
        private set
    var suggestSong by mutableStateOf<Song?>(null)
        private set
    var suggestWhy by mutableStateOf("")
        private set
    private var suggestDone = false
    private val suggestSeen = ArrayList<Long>()
    private var assistFromChat = false
    private var audioLoaded = false
    private var analysisJob: Job? = null
    private var fMu = FloatArray(0)
    private var fSd = FloatArray(0)
    private var energyCuts: FloatArray? = null
    var sortKey by mutableStateOf(prefs.getString("sortKey", "def") ?: "def")
        private set
    var sortAsc by mutableStateOf(prefs.getBoolean("sortAsc", true))
        private set
    var playlists by mutableStateOf(loadPlaylists())
        private set
    var queue by mutableStateOf<List<Pair<Int, Song>>>(emptyList())
        private set
    var moodMap by mutableStateOf(loadMoodMap())
        private set
    var songMoods by mutableStateOf(loadSongMoods())
        private set
    var dividers by mutableStateOf(prefs.getBoolean("dividers", true))
        private set
    var nav by mutableStateOf<String?>(null)
        private set
    var smartInfo by mutableStateOf("")
        private set
    var suggestions by mutableStateOf<List<Suggestion>>(emptyList())
        private set
    var smartBusy by mutableStateOf(false)
        private set
    var muharram by mutableStateOf(prefs.getBoolean("muharram", false))
        private set
    var speed by mutableStateOf(prefs.getFloat("speed", 1f))
        private set
    var resumeMin by mutableStateOf(prefs.getInt("resumeMin", 10))
        private set
    var lyricLines by mutableStateOf<List<Pair<Long, String>>>(emptyList())
        private set
    private var tick = 0
    private var listenAcc = 0L
    private var counted = false
    var plays by mutableStateOf(loadPlays())
        private set
    var lastPlay by mutableStateOf(loadLast())
        private set
    var chat by mutableStateOf<List<Pair<Boolean, String>>>(emptyList())
        private set
    var shuffle by mutableStateOf(false)
        private set
    var repeatMode by mutableStateOf(0)
        private set
    var skipSec by mutableStateOf(prefs.getInt("skipSec", 15))
        private set
    var coverSquare by mutableStateOf(prefs.getBoolean("square", false))
        private set
    var art by mutableStateOf<ImageBitmap?>(null)
        private set
    var artColor by mutableStateOf(Color(0xFF3A2A5E))
        private set
    var hiddenDirs by mutableStateOf<Set<String>>(prefs.getStringSet("hiddenDirs", emptySet())?.toSet() ?: emptySet())
        private set
    var shownDirs by mutableStateOf<Set<String>>(prefs.getStringSet("shownDirs", emptySet())?.toSet() ?: emptySet())
        private set
    var autoVoice by mutableStateOf(prefs.getBoolean("autoVoice", true))
        private set
    private var controller: MediaController? = null

    init {
        val token = SessionToken(app, ComponentName(app, PlaybackService::class.java))
        val future = MediaController.Builder(app, token).buildAsync()
        future.addListener({
            val c = future.get()
            controller = c
            playing = c.isPlaying
            c.setPlaybackSpeed(speed)
            c.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    playing = isPlaying
                    if (!isPlaying) saveResume()
                }

                override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                    shuffle = shuffleModeEnabled
                    refreshQueue()
                }

                override fun onRepeatModeChanged(mode: Int) {
                    repeatMode = mode
                }

                override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
                    speed = playbackParameters.speed
                }

                override fun onTimelineChanged(timeline: Timeline, reason: Int) {
                    refreshQueue()
                }

                override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                    current = raw.firstOrNull { it.id.toString() == item?.mediaId }
                    loadArt(current)
                    loadLyrics(current)
                    refreshQueue()
                    position = 0L
                    listenAcc = 0L
                    counted = false
                    if (sleepEndOfSong && reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) {
                        controller?.pause()
                        sleepEndOfSong = false
                    }
                }
            })
        }, ContextCompat.getMainExecutor(app))

        viewModelScope.launch {
            while (true) {
                delay(500)
                controller?.let { c ->
                    if (c.isPlaying) {
                        position = c.currentPosition
                        duration = c.duration.coerceAtLeast(0L)
                        tick++
                        val cur = current
                        if (tick % 10 == 0 && cur != null && resumeMin > 0 &&
                            cur.durationMs >= resumeMin * 60_000L
                        ) {
                            prefs.edit().putLong("pos_" + cur.id, position).apply()
                        }
                        listenAcc += 500L
                        if (!counted && cur != null && listenAcc >= minOf(30_000L, cur.durationMs / 2)) {
                            counted = true
                            registerPlay(cur)
                        }
                    }
                }
            }
        }
    }

    fun load() {
        viewModelScope.launch {
            val list = withContext(Dispatchers.IO) { MediaScanner.scan(getApplication(), minSec * 1000L) }
            val groups = list.groupBy { it.size to it.durationMs }.values
            val keep = groups.map { g -> g.minByOrNull { it.path.length }!!.id }.toSet()
            raw = list.filter { it.id in keep }
            dupGroups = groups.filter { it.size > 1 }.map { g -> g.sortedBy { it.path.length } }
            applyFilter()
            maybeSuggest()
            if (!audioLoaded) {
                audioLoaded = true
                loadAudioFile()
            }
        }
    }

    fun play(list: List<Song>, index: Int) {
        val c = controller ?: return
        c.setMediaItems(list.map { it.toItem() }, index, resumeStart(list[index]))
        c.prepare()
        c.play()
    }

    private fun loadMap(): Map<String, String> {
        val o = JSONObject(prefs.getString("cats", "{}") ?: "{}")
        return o.keys().asSequence().associateWith { o.getString(it) }
    }

    fun setCategory(s: Song, cat: String?) {
        cats = if (cat == null) cats - s.path else cats + (s.path to cat)
        prefs.edit().putString("cats", JSONObject(cats).toString()).apply()
    }

    fun toggleFav(s: Song) {
        favs = if (s.path in favs) favs - s.path else favs + s.path
        prefs.edit().putStringSet("favs", favs).apply()
    }

    private fun voiceDir(dir: String): Boolean {
        val names = setOf(
            "recordings", "voice recorder", "voice notes", "whatsapp voice notes", "call", "calls",
            "sound recorder", "audio recorder", "voicenotes", "ptt"
        )
        return dir.lowercase().split("/").any {
            it in names || it.contains("voice note") || it.contains("call record")
        }
    }

    fun dirHidden(dir: String): Boolean =
        dir in hiddenDirs || (autoVoice && voiceDir(dir) && dir !in shownDirs)

    private fun applyFilter() {
        songs = raw.filter { !dirHidden(File(it.path).parent ?: "") }
    }

    fun folderStats(): List<Pair<String, Int>> =
        raw.groupBy { File(it.path).parent ?: "" }.map { it.key to it.value.size }.sortedByDescending { it.second }

    fun toggleDir(dir: String) {
        if (dirHidden(dir)) {
            hiddenDirs = hiddenDirs - dir
            shownDirs = shownDirs + dir
        } else {
            hiddenDirs = hiddenDirs + dir
            shownDirs = shownDirs - dir
        }
        prefs.edit().putStringSet("hiddenDirs", hiddenDirs).putStringSet("shownDirs", shownDirs).apply()
        applyFilter()
    }

    fun updateAutoVoice(v: Boolean) {
        autoVoice = v
        prefs.edit().putBoolean("autoVoice", v).apply()
        applyFilter()
    }

    fun setCategoryMany(list: List<Song>, cat: String?) {
        var m = cats
        for (s in list) m = if (cat == null) m - s.path else m + (s.path to cat)
        cats = m
        prefs.edit().putString("cats", JSONObject(cats).toString()).apply()
    }

    fun favMany(list: List<Song>, add: Boolean) {
        var f = favs
        for (s in list) f = if (add) f + s.path else f - s.path
        favs = f
        prefs.edit().putStringSet("favs", favs).apply()
    }

    fun rescan() {
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val found = withContext(Dispatchers.IO) {
                val exts = setOf("mp3", "m4a", "aac", "wav", "flac", "ogg", "opus", "wma", "amr", "m4b")
                val out = ArrayList<String>()
                fun walk(d: File, depth: Int) {
                    if (depth > 8) return
                    val kids = d.listFiles() ?: return
                    for (f in kids) {
                        if (f.isDirectory) {
                            if (f.name != "Android" && !f.name.startsWith(".")) walk(f, depth + 1)
                        } else if (f.extension.lowercase() in exts) {
                            out.add(f.path)
                        }
                    }
                }
                walk(Environment.getExternalStorageDirectory(), 0)
                out
            }
            if (found.isNotEmpty()) {
                val done = CompletableDeferred<Unit>()
                val left = AtomicInteger(found.size)
                MediaScannerConnection.scanFile(ctx, found.toTypedArray(), null) { _, _ ->
                    if (left.decrementAndGet() == 0) done.complete(Unit)
                }
                withTimeoutOrNull(60_000L) { done.await() }
            }
            load()
            Toast.makeText(ctx, "تم فحص " + found.size + " ملف صوتي", Toast.LENGTH_LONG).show()
        }
    }

    fun runSmart() {
        if (smartBusy) return
        smartBusy = true
        viewModelScope.launch {
            val catsNow = cats
            val all = raw
            val vis = songs
            val feats = HashMap(audioMap)
            val res = withContext(Dispatchers.Default) { SmartTrainer.run(all, vis, catsNow, feats) }
            smartInfo = res.first
            suggestions = res.second
            smartBusy = false
            if (assistFromChat) {
                assistFromChat = false
                chat = chat + (false to suggestionSummary())
                Toast.makeText(getApplication<Application>(), "المساعد خلّص تحليل التصنيف", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun assistClassify(): String {
        if (smartBusy) return "أشتغل على التحليل هسه، أخبرك أول ما أخلص."
        if (cats.size < 10) {
            return "التصنيف الذكي يتعلم من اللي صنفته أنت. صنّف على الأقل 10 أغاني بنفسك (يفضل 30)، وبعدها كلي: صنف الأغاني."
        }
        assistFromChat = true
        runSmart()
        return "تمام، جاري تحليل المكتبة (ياخذ ثواني)... أخبرك أول ما أخلص."
    }

    fun suggestionSummary(): String {
        if (suggestions.isEmpty()) return smartInfo.ifBlank { "ما طلعت اقتراحات." }
        val n = suggestions.size
        val c90 = suggestions.count { it.conf >= 0.9 }
        val c80 = suggestions.count { it.conf >= 0.8 }
        val c70 = suggestions.count { it.conf >= 0.7 }
        val top = suggestions.groupingBy { it.cat }.eachCount().entries
            .sortedByDescending { it.value }.take(4)
        return "طلعت " + n + " اقتراح:\n" +
            "• فوق 90%: " + c90 + "\n• فوق 80%: " + c80 + "\n• فوق 70%: " + c70 + "\n" +
            "أكثر الأقسام: " + top.joinToString("، ") { it.key + " (" + it.value + ")" } + "\n" +
            "كلي: «وافق على الكل» أو «وافق فوق 90» أو «وريني»."
    }

    fun setDeep(on: Boolean) {
        deepMode = on
        prefs.edit().putBoolean("deepMode", on).apply()
    }

    fun updateOpenSuggest(v: Boolean) {
        openSuggest = v
        prefs.edit().putBoolean("openSuggest", v).apply()
        if (!v) suggestSong = null
    }

    private fun pickSong(): Pair<Song, String>? {
        val now = System.currentTimeMillis()
        val curId = current?.id
        var pool = songs.filter { it.id != curId && it.id !in suggestSeen }
        if (pool.isEmpty()) {
            suggestSeen.clear()
            pool = songs.filter { it.id != curId }
        }
        if (pool.isEmpty()) return null
        if (muharram) {
            val mp = pool.filter { (cats[it.path] ?: "") in MuharramCats }
            if (mp.isNotEmpty()) pool = mp
        }
        val ws = pool.map { s ->
            val pc = playCount(s)
            val last = lastPlayedAt(s)
            var w = 1.0
            if (s.path in favs) w += 3.0
            w += minOf(pc, 10) * 0.4
            if (pc == 0) w += 1.0
            if (last > 0L && now - last < 6L * 3600_000L) w *= 0.1
            else if (last > 0L && now - last < 24L * 3600_000L) w *= 0.4
            w
        }
        var r = kotlin.random.Random(System.nanoTime()).nextDouble() * ws.sum()
        var idx = ws.size - 1
        for (i in ws.indices) {
            r -= ws[i]
            if (r <= 0.0) {
                idx = i
                break
            }
        }
        val s = pool[idx]
        val pc = playCount(s)
        val last = lastPlayedAt(s)
        val why = when {
            s.path in favs -> "من مفضلتك"
            pc >= 3 -> "من أكثر اللي تسمعه"
            pc == 0 -> "ما سمعتها للحين"
            last > 0L && now - last > 14L * 86400_000L -> "من فترة ما سمعتها"
            else -> "اقتراح مفاجئ"
        }
        return s to why
    }

    fun maybeSuggest() {
        if (suggestDone || !openSuggest) return
        if (current != null || playing || songs.isEmpty()) return
        suggestDone = true
        val p = pickSong() ?: return
        suggestSeen.add(p.first.id)
        suggestSong = p.first
        suggestWhy = p.second
    }

    fun nextSuggestion() {
        val p = pickSong() ?: return
        suggestSeen.add(p.first.id)
        suggestSong = p.first
        suggestWhy = p.second
    }

    fun dismissSuggestion() {
        suggestSong = null
    }

    fun playSuggestion() {
        val s = suggestSong ?: return
        suggestSong = null
        playPicked(s)
    }

    fun playPicked(s: Song) {
        val c = cats[s.path]
        val rest = songs.filter { it.id != s.id && (c == null || cats[it.path] == c) }.shuffled().take(40)
        play(listOf(s) + rest, 0)
    }

    fun suggestForChat(): Pair<Song, String>? {
        val p = pickSong()
        if (p != null) suggestSeen.add(p.first.id)
        return p
    }

    fun acceptSuggestion(sg: Suggestion) {
        setCategory(sg.song, sg.cat)
        suggestions = suggestions.filter { it.song.id != sg.song.id }
    }

    fun acceptSuggestions(minConf: Double) {
        val good = suggestions.filter { it.conf >= minConf }
        var m = cats
        for (sg in good) m = m + (sg.song.path to sg.cat)
        cats = m
        prefs.edit().putString("cats", JSONObject(cats).toString()).apply()
        suggestions = suggestions.filter { it.conf < minConf }
    }

    private fun loadPlays(): Map<Int, Int> {
        val o = JSONObject(prefs.getString("plays", "{}") ?: "{}")
        return o.keys().asSequence().associate { it.toInt() to o.getInt(it) }
    }

    private fun loadLast(): Map<Int, Long> {
        val o = JSONObject(prefs.getString("lastPlay", "{}") ?: "{}")
        return o.keys().asSequence().associate { it.toInt() to o.getLong(it) }
    }

    private fun registerPlay(s: Song) {
        val k = s.path.hashCode()
        val now = System.currentTimeMillis()
        plays = plays + (k to ((plays[k] ?: 0) + 1))
        lastPlay = lastPlay + (k to now)
        prefs.edit()
            .putString("plays", JSONObject(plays.mapKeys { it.key.toString() }).toString())
            .putString("lastPlay", JSONObject(lastPlay.mapKeys { it.key.toString() }).toString())
            .apply()
        val line = now.toString() + "|" + k + "|" + (cats[s.path] ?: "") + "\n"
        viewModelScope.launch(Dispatchers.IO) {
            File(getApplication<Application>().filesDir, "history.txt").appendText(line)
        }
    }

    fun songKey(s: Song): Int = s.path.hashCode()

    fun playCount(s: Song): Int = plays[s.path.hashCode()] ?: 0

    fun lastPlayedAt(s: Song): Long = lastPlay[s.path.hashCode()] ?: 0L

    fun readEvents(): List<Event> {
        val f = File(getApplication<Application>().filesDir, "history.txt")
        if (!f.exists()) return emptyList()
        val out = ArrayList<Event>()
        for (line in f.readLines()) {
            val p = line.split("|")
            if (p.size >= 3) {
                val ts = p[0].toLongOrNull()
                val k = p[1].toIntOrNull()
                if (ts != null && k != null) out.add(Event(ts, k, p[2]))
            }
        }
        return out
    }

    fun playList(list: List<Song>) {
        if (list.isNotEmpty()) play(list, 0)
    }

    fun addNote(t: String) {
        val cur = prefs.getString("notes", "") ?: ""
        prefs.edit().putString("notes", if (cur.isEmpty()) t else cur + "\n" + t).apply()
    }

    fun notes(): List<String> = (prefs.getString("notes", "") ?: "").split("\n").filter { it.isNotBlank() }

    fun clearNotes() {
        prefs.edit().remove("notes").apply()
    }

    fun ask(q: String) {
        val text = q.trim()
        if (text.isEmpty()) return
        val a = Assistant.answer(text, this)
        chat = chat + (true to text) + (false to a)
    }

    private fun loadMoodMap(): Map<String, Set<String>> {
        val s = prefs.getString("moodMap", null) ?: return DEFAULT_MOODS
        return try {
            val o = JSONObject(s)
            val m = HashMap<String, Set<String>>()
            for (k in o.keys()) {
                val a = o.getJSONArray(k)
                m[k] = (0 until a.length()).map { a.getString(it) }.toSet()
            }
            m
        } catch (e: Exception) {
            DEFAULT_MOODS
        }
    }

    private fun saveMoodMap() {
        val o = JSONObject()
        for ((k, v) in moodMap) o.put(k, JSONArray(v.toList()))
        prefs.edit().putString("moodMap", o.toString()).apply()
    }

    private fun loadSongMoods(): Map<String, Set<String>> {
        val s = prefs.getString("songMoods", null) ?: return emptyMap()
        return try {
            val o = JSONObject(s)
            val m = HashMap<String, Set<String>>()
            for (k in o.keys()) {
                val a = o.getJSONArray(k)
                m[k] = (0 until a.length()).map { a.getString(it) }.toSet()
            }
            m
        } catch (e: Exception) {
            emptyMap()
        }
    }

    private fun saveSongMoods() {
        val o = JSONObject()
        for ((k, v) in songMoods) o.put(k, JSONArray(v.toList()))
        prefs.edit().putString("songMoods", o.toString()).apply()
    }

    fun songMoodSet(s: Song): Set<String> = songMoods[s.path] ?: emptySet()

    private fun suggestedMoods(s: Song): Set<String> {
        val c = cats[s.path]
        val base: Set<String> =
            if (c == null) emptySet() else MoodNames.filter { m -> c in (moodMap[m] ?: emptySet()) }.toSet()
        if (c != null && c in SPEECH_CATS) return base
        return base + audioMoods(s)
    }

    fun moodSuggestions(mood: String): List<Song> =
        songs.filter { mood in suggestedMoods(it) && mood !in songMoodSet(it) }

    fun acceptMood(list: List<Song>, mood: String) {
        var m = songMoods
        for (s in list) m = m + (s.path to ((m[s.path] ?: emptySet()) + mood))
        songMoods = m
        saveSongMoods()
    }

    private fun zOf(f: FloatArray): FloatArray = FloatArray(f.size) { (f[it] - fMu[it]) / fSd[it] }

    private fun audioMoods(s: Song): Set<String> {
        if (audioVersion < 0) return emptySet()
        val f = audioMap[s.path.hashCode()] ?: return emptySet()
        val cuts = energyCuts ?: return emptySet()
        if (f.size != AudioAnalyzer.D || fMu.size != AudioAnalyzer.D) return emptySet()
        val z = zOf(f)
        val e = z[0] + z[5] + 0.5f * z[4]
        val out = HashSet<String>()
        if (e <= cuts[1]) out.add("هادئ")
        if (e <= cuts[0]) out.add("نوم")
        if (e >= cuts[3]) out.add("حماس")
        if (e >= cuts[0] && e <= cuts[2] && z[5] <= 0f) out.add("تركيز")
        if (e <= cuts[2] && z[4] <= -0.1f && f[9] >= 40f && f[9] <= 110f) out.add("حزين")
        return out
    }

    private fun audioFile() = File(getApplication<Application>().filesDir, "audio_v1.txt")

    private fun loadAudioFile() {
        val f = audioFile()
        if (f.exists()) {
            for (line in f.readLines()) {
                val i = line.indexOf(':')
                if (i <= 0) continue
                val k = line.substring(0, i).toIntOrNull() ?: continue
                val vals = line.substring(i + 1).split(",").mapNotNull { it.toFloatOrNull() }
                audioMap[k] = vals.toFloatArray()
            }
        }
        val df = File(getApplication<Application>().filesDir, "audio_deep.txt")
        if (df.exists()) df.readLines().forEach { l -> l.trim().toIntOrNull()?.let { deepSet.add(it) } }
        recomputeAudioStats()
    }

    private fun saveAudioFile() {
        audioFile().writeText(audioMap.entries.joinToString("\n") { e -> e.key.toString() + ":" + e.value.joinToString(",") })
        File(getApplication<Application>().filesDir, "audio_deep.txt").writeText(deepSet.joinToString("\n"))
    }

    private fun recomputeAudioStats() {
        val d = AudioAnalyzer.D
        val valid = audioMap.values.filter { it.size == d }
        if (valid.size >= 30) {
            fMu = FloatArray(d) { i -> valid.map { it[i] }.average().toFloat() }
            fSd = FloatArray(d) { i ->
                val m = fMu[i]
                kotlin.math.sqrt(valid.map { (it[i] - m) * (it[i] - m) }.average()).toFloat().coerceAtLeast(1e-6f)
            }
            val en = valid.map { f -> zOf(f).let { z -> z[0] + z[5] + 0.5f * z[4] } }.sorted()
            fun pct(p: Float): Float = en[((en.size - 1) * p).toInt()]
            energyCuts = floatArrayOf(pct(0.12f), pct(0.35f), pct(0.55f), pct(0.65f))
        } else {
            energyCuts = null
        }
        audioVersion++
    }

    fun audioStatus(): String {
        val touch = analysisDone + audioVersion
        val ok = audioMap.values.count { it.size == AudioAnalyzer.D }
        return "تم تحليل " + ok + " من " + raw.size + " أغنية" +
            (if (deepSet.isNotEmpty()) " (منها " + deepSet.size + " بالاستماع العميق)" else "") +
            (if (touch < 0) "?" else "")
    }

    fun startAnalysis() {
        if (analyzing) return
        val todo = raw.filter {
            it.durationMs > 20_000L &&
                (audioMap[it.path.hashCode()] == null || (deepMode && it.path.hashCode() !in deepSet))
        }
        if (todo.isEmpty()) {
            Toast.makeText(getApplication<Application>(), "كل الأغاني انحللت", Toast.LENGTH_SHORT).show()
            return
        }
        analyzing = true
        analysisTotal = todo.size
        analysisDone = 0
        AnalysisBridge.onStop = { stopAnalysis() }
        AnalysisService.start(getApplication<Application>(), 0, todo.size)
        analysisJob = viewModelScope.launch {
            val ctx = getApplication<Application>()
            var sinceSave = 0
            for (s in todo) {
                if (!isActive) break
                val deep = deepMode
                val f = withContext(Dispatchers.Default) {
                    if (deep) AudioAnalyzer.analyzeDeep(ctx, s.uri, s.durationMs)
                    else AudioAnalyzer.analyze(ctx, s.uri, s.durationMs)
                }
                val key = s.path.hashCode()
                if (f != null || audioMap[key] == null) audioMap[key] = f ?: FloatArray(0)
                if (deep) deepSet.add(key)
                analysisDone++
                sinceSave++
                if (analysisDone % 5 == 0) AnalysisService.update(ctx, analysisDone, analysisTotal)
                if (sinceSave >= 25) {
                    sinceSave = 0
                    saveAudioFile()
                }
            }
            saveAudioFile()
            recomputeAudioStats()
            analyzing = false
            AnalysisService.stop(ctx)
        }
    }

    fun stopAnalysis() {
        analysisJob?.cancel()
        analyzing = false
        AnalysisService.stop(getApplication<Application>())
        saveAudioFile()
        recomputeAudioStats()
    }

    fun moodSongs(mood: String): List<Song> = songs.filter { mood in songMoodSet(it) }

    fun toggleMoodCat(mood: String, cat: String) {
        val cur = moodMap[mood] ?: emptySet()
        moodMap = moodMap + (mood to (if (cat in cur) cur - cat else cur + cat))
        saveMoodMap()
    }

    fun toggleSongMood(s: Song, mood: String) {
        val cur = songMoodSet(s)
        songMoods = songMoods + (s.path to (if (mood in cur) cur - mood else cur + mood))
        saveSongMoods()
    }

    fun playMood(mood: String): Int {
        val list = moodSongs(mood).shuffled()
        if (list.isNotEmpty()) play(list, 0)
        return list.size
    }

    fun setEqPreset(name: String) {
        EqPresets.firstOrNull { it.first == name }?.second?.let { setEq(it) }
    }

    fun speedTo(v: Float) {
        controller?.setPlaybackSpeed(v)
        speed = v
        prefs.edit().putFloat("speed", v).apply()
    }

    fun shuffleTo(on: Boolean) {
        controller?.shuffleModeEnabled = on
    }

    fun repeatTo(mode: Int) {
        controller?.repeatMode = mode
    }

    fun skipBy(sec: Int) {
        controller?.let { c ->
            c.seekTo((c.currentPosition + sec * 1000L).coerceAtLeast(0L))
            position = c.currentPosition
        }
    }

    fun pause() {
        controller?.pause()
    }

    fun resume() {
        controller?.play()
    }

    fun muharramTo(on: Boolean) {
        muharram = on
        prefs.edit().putBoolean("muharram", on).apply()
    }

    fun coverTo(square: Boolean) {
        coverSquare = square
        prefs.edit().putBoolean("square", square).apply()
    }

    fun dividersTo(on: Boolean) {
        dividers = on
        prefs.edit().putBoolean("dividers", on).apply()
    }

    fun toggleDividers() {
        dividersTo(!dividers)
    }

    fun requestNav(dest: String) {
        nav = dest
    }

    fun clearNav() {
        nav = null
    }

    private fun audio(): AudioManager =
        getApplication<Application>().getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun volumeStep(up: Boolean) {
        audio().adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI
        )
    }

    fun volumeSetPct(p: Int) {
        val a = audio()
        val max = a.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        a.setStreamVolume(AudioManager.STREAM_MUSIC, p.coerceIn(0, 100) * max / 100, AudioManager.FLAG_SHOW_UI)
    }

    fun sortBy(key: String) {
        sortKey = key
        prefs.edit().putString("sortKey", key).apply()
    }

    fun sortDir(asc: Boolean) {
        sortAsc = asc
        prefs.edit().putBoolean("sortAsc", asc).apply()
    }

    fun sortSongs(list: List<Song>): List<Song> {
        val sorted = when (sortKey) {
            "name" -> list.sortedBy { it.title.lowercase() }
            "date" -> list.sortedBy { it.dateAdded }
            "dur" -> list.sortedBy { it.durationMs }
            "artist" -> list.sortedWith(compareBy<Song>({ it.artist.lowercase() }, { it.title.lowercase() }))
            else -> return list
        }
        return if (sortAsc) sorted else sorted.reversed()
    }

    private fun loadPlaylists(): Map<String, List<String>> {
        val s = prefs.getString("playlists", null) ?: return emptyMap()
        return try {
            val o = JSONObject(s)
            val m = LinkedHashMap<String, List<String>>()
            for (k in o.keys()) {
                val a = o.getJSONArray(k)
                m[k] = (0 until a.length()).map { a.getString(it) }
            }
            m
        } catch (e: Exception) {
            emptyMap()
        }
    }

    private fun savePlaylists() {
        val o = JSONObject()
        for ((k, v) in playlists) o.put(k, JSONArray(v))
        prefs.edit().putString("playlists", o.toString()).apply()
    }

    fun createPlaylist(name: String): Boolean {
        val n = name.trim()
        if (n.isEmpty() || n in playlists) return false
        playlists = playlists + (n to emptyList<String>())
        savePlaylists()
        return true
    }

    fun deletePlaylist(name: String) {
        playlists = playlists - name
        savePlaylists()
    }

    fun addToPlaylist(name: String, list: List<Song>): Pair<Int, Int> {
        val cur = playlists[name] ?: return 0 to 0
        val have = cur.toHashSet()
        val add = list.map { it.path }.distinct().filter { it !in have }
        playlists = playlists + (name to (cur + add))
        savePlaylists()
        return add.size to (list.size - add.size)
    }

    fun removeFromPlaylist(name: String, s: Song) {
        val cur = playlists[name] ?: return
        playlists = playlists + (name to cur.filter { it != s.path })
        savePlaylists()
    }

    fun playlistSongs(name: String): List<Song> {
        val byPath = raw.associateBy { it.path }
        return (playlists[name] ?: emptyList()).mapNotNull { byPath[it] }
    }

    fun refreshQueue() {
        val c = controller ?: return
        val tl = c.currentTimeline
        if (tl.isEmpty) {
            queue = emptyList()
            return
        }
        val byId = raw.associateBy { it.id.toString() }
        val out = ArrayList<Pair<Int, Song>>()
        var idx = c.currentMediaItemIndex
        var guard = 0
        while (idx != C.INDEX_UNSET && guard++ < 300) {
            val item = c.getMediaItemAt(idx)
            val song = byId[item.mediaId]
            if (song != null) out.add(idx to song)
            idx = tl.getNextWindowIndex(idx, Player.REPEAT_MODE_OFF, c.shuffleModeEnabled)
        }
        queue = out
    }

    fun jumpTo(idx: Int) {
        controller?.let {
            it.seekToDefaultPosition(idx)
            it.play()
        }
    }

    fun removeFromQueue(idx: Int) {
        controller?.removeMediaItem(idx)
    }

    fun playNext(s: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            play(listOf(s), 0)
            return
        }
        c.addMediaItem(c.currentMediaItemIndex + 1, s.toItem())
        val msg = if (c.shuffleModeEnabled) "أضيفت (مع العشوائي مكانها عشوائي)" else "راح تشتغل بعد الأغنية الحالية"
        Toast.makeText(getApplication<Application>(), msg, Toast.LENGTH_SHORT).show()
    }

    fun addToQueue(s: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            play(listOf(s), 0)
            return
        }
        c.addMediaItem(s.toItem())
        Toast.makeText(getApplication<Application>(), "أضيفت لقائمة الانتظار", Toast.LENGTH_SHORT).show()
    }

    fun toggleMuharram() {
        muharram = !muharram
        prefs.edit().putBoolean("muharram", muharram).apply()
    }

    fun updateResume(v: Int) {
        resumeMin = v
        prefs.edit().putInt("resumeMin", v).apply()
    }

    fun cycleSpeed() {
        val opts = listOf(0.75f, 1f, 1.25f, 1.5f, 2f)
        val i = opts.indexOfFirst { kotlin.math.abs(it - speed) < 0.01f }
        val next = opts[(i + 1) % opts.size]
        controller?.setPlaybackSpeed(next)
        speed = next
        prefs.edit().putFloat("speed", next).apply()
    }

    private fun saveResume() {
        val c = controller
        val cur = current
        if (c != null && cur != null && resumeMin > 0 && cur.durationMs >= resumeMin * 60_000L) {
            prefs.edit().putLong("pos_" + cur.id, c.currentPosition).apply()
        }
    }

    private fun resumeStart(s: Song): Long {
        if (resumeMin <= 0 || s.durationMs < resumeMin * 60_000L) return 0L
        val p = prefs.getLong("pos_" + s.id, 0L)
        return if (p > 5_000L && p < s.durationMs - 15_000L) p else 0L
    }

    private fun norm(t: String): String {
        val sb = StringBuilder()
        for (ch in t) {
            when {
                ch in '\u064B'..'\u0652' || ch == '\u0670' || ch == '\u0640' -> {}
                ch == 'أ' || ch == 'إ' || ch == 'آ' || ch == 'ٱ' -> sb.append('ا')
                ch == 'ة' -> sb.append('ه')
                ch == 'ى' -> sb.append('ي')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    private val surahRegex: List<Regex> by lazy {
        SURAHS.map { Regex("سوره\\s+" + Regex.escape(norm(it)) + "(?![\\p{L}])") }
    }

    private val surahCache = HashMap<Long, Int>()

    private fun surahOf(s: Song): Int = surahCache.getOrPut(s.id) {
        val t = norm(s.title)
        val i = surahRegex.indexOfFirst { it.containsMatchIn(t) }
        if (i < 0) 999 else i
    }

    fun sortQuran(list: List<Song>): List<Song> =
        list.sortedWith(compareBy<Song>({ surahOf(it) }, { it.title }))

    private fun lyricFile(s: Song): File {
        val dir = File(getApplication<Application>().filesDir, "lyrics")
        dir.mkdirs()
        return File(dir, "l" + s.path.hashCode() + ".txt")
    }

    private fun parseLyrics(t: String): List<Pair<Long, String>> {
        val re = Regex("^\\s*\\[(\\d+):(\\d+)(?:[.:](\\d+))?\\]\\s*(.*)$")
        val out = ArrayList<Pair<Long, String>>()
        for (raw in t.lines()) {
            val line = raw.trimEnd()
            if (line.isBlank()) continue
            val m = re.find(line)
            if (m != null) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val ms = (min * 60 + sec) * 1000 + (if (frac.isEmpty()) 0L else frac.padEnd(3, '0').take(3).toLong())
                out.add(ms to m.groupValues[4])
            } else if (!line.startsWith("[")) {
                out.add(-1L to line)
            }
        }
        return out
    }

    private fun loadLyrics(s: Song?) {
        if (s == null) {
            lyricLines = emptyList()
            return
        }
        viewModelScope.launch {
            lyricLines = withContext(Dispatchers.IO) {
                val f = lyricFile(s)
                if (f.exists()) parseLyrics(f.readText()) else emptyList()
            }
        }
    }

    fun saveLyrics(text: String) {
        val s = current ?: return
        lyricFile(s).writeText(text)
        lyricLines = parseLyrics(text)
    }

    fun importLyrics(uri: Uri) {
        viewModelScope.launch {
            val t = withContext(Dispatchers.IO) {
                getApplication<Application>().contentResolver.openInputStream(uri)
                    ?.bufferedReader()?.use { it.readText() }
            }
            if (t != null) saveLyrics(t)
        }
    }

    fun clearLyrics() {
        val s = current ?: return
        lyricFile(s).delete()
        lyricLines = emptyList()
    }

    var lastBackup by mutableStateOf(prefs.getLong("lastBackup", 0L))

    private fun backupText(): String {
        val root = JSONObject()
        root.put("v", 1)
        root.put("time", System.currentTimeMillis())
        val p = JSONObject()
        for ((k, v) in prefs.all) {
            if (k == "vizTick" || v == null) continue
            val o = JSONObject()
            when (v) {
                is Boolean -> { o.put("t", "b"); o.put("v", v) }
                is Int -> { o.put("t", "i"); o.put("v", v) }
                is Long -> { o.put("t", "l"); o.put("v", v) }
                is Float -> { o.put("t", "f"); o.put("v", v.toDouble()) }
                is String -> { o.put("t", "s"); o.put("v", v) }
                is Set<*> -> { o.put("t", "ss"); o.put("v", JSONArray(v.map { it.toString() })) }
                else -> continue
            }
            p.put(k, o)
        }
        val files = JSONObject()
        val dir = getApplication<Application>().filesDir
        for (n in listOf("history.txt", "audio_v1.txt", "audio_deep.txt")) {
            val f = File(dir, n)
            if (f.exists()) files.put(n, f.readText())
        }
        File(dir, "lyrics").listFiles()?.forEach { f ->
            if (f.isFile) files.put("lyrics/" + f.name, f.readText())
        }
        root.put("prefs", p)
        root.put("files", files)
        return root.toString()
    }

    fun exportBackup(uri: Uri) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val t = backupText()
                    val out = getApplication<Application>().contentResolver.openOutputStream(uri, "wt")
                    if (out == null) false else {
                        out.use { it.write(t.toByteArray(Charsets.UTF_8)) }
                        true
                    }
                } catch (e: Exception) {
                    false
                }
            }
            if (ok) {
                lastBackup = System.currentTimeMillis()
                prefs.edit().putLong("lastBackup", lastBackup).apply()
            }
            Toast.makeText(
                getApplication<Application>(),
                if (ok) "انحفظت النسخة الاحتياطية" else "فشل حفظ النسخة",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    fun importBackup(uri: Uri, onDone: () -> Unit) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    val t = getApplication<Application>().contentResolver.openInputStream(uri)
                        ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: return@withContext false
                    val root = JSONObject(t)
                    val p = root.getJSONObject("prefs")
                    val ed = prefs.edit().clear()
                    val keys = p.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        val o = p.getJSONObject(k)
                        when (o.getString("t")) {
                            "b" -> ed.putBoolean(k, o.getBoolean("v"))
                            "i" -> ed.putInt(k, o.getInt("v"))
                            "l" -> ed.putLong(k, o.getLong("v"))
                            "f" -> ed.putFloat(k, o.getDouble("v").toFloat())
                            "s" -> ed.putString(k, o.getString("v"))
                            "ss" -> {
                                val a = o.getJSONArray("v")
                                val set = mutableSetOf<String>()
                                for (i in 0 until a.length()) set.add(a.getString(i))
                                ed.putStringSet(k, set)
                            }
                        }
                    }
                    ed.commit()
                    val dir = getApplication<Application>().filesDir
                    val files = root.optJSONObject("files")
                    if (files != null) {
                        val fk = files.keys()
                        while (fk.hasNext()) {
                            val n = fk.next()
                            val okName = n == "history.txt" || n == "audio_v1.txt" || n == "audio_deep.txt" ||
                                (n.startsWith("lyrics/") && n.indexOf("..") < 0 && n.indexOf('/', 7) < 0)
                            if (!okName) continue
                            val f = File(dir, n)
                            f.parentFile?.mkdirs()
                            f.writeText(files.getString(n))
                        }
                    }
                    true
                } catch (e: Exception) {
                    false
                }
            }
            if (ok) onDone()
            else Toast.makeText(
                getApplication<Application>(), "الملف مو نسخة صالحة، ما تغيّر شي", Toast.LENGTH_LONG
            ).show()
        }
    }

    fun clearSuggestions() {
        suggestions = emptyList()
    }

    fun pingViz() {
        prefs.edit().putLong("vizTick", System.currentTimeMillis()).apply()
    }

    fun toggleShuffle() {
        controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    }

    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    fun skip(sign: Int) {
        controller?.let { c ->
            c.seekTo((c.currentPosition + sign * skipSec * 1000L).coerceAtLeast(0L))
            position = c.currentPosition
        }
    }

    fun updateSkip(v: Int) {
        skipSec = v
        prefs.edit().putInt("skipSec", v).apply()
    }

    fun toggleCover() {
        coverSquare = !coverSquare
        prefs.edit().putBoolean("square", coverSquare).apply()
    }

    fun saveAccent(c: Color) {
        Gold = c
        prefs.edit().putInt("accent", c.toArgb()).apply()
    }

    private fun decodeSampled(bytes: ByteArray, maxDim: Int): android.graphics.Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var s = 1
        while (o.outWidth / s > maxDim) s *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = s }
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }

    private fun loadArt(s: Song?) {
        artJob?.cancel()
        val fallback = 0xFF3A2A5E.toInt()
        if (s == null) {
            art = null
            artColor = Color(fallback)
            return
        }
        artJob = viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                val mmr = MediaMetadataRetriever()
                try {
                    mmr.setDataSource(getApplication<Application>(), s.uri)
                    val bytes = mmr.embeddedPicture
                    if (bytes == null) null else decodeSampled(bytes, 800)
                } catch (e: Exception) {
                    null
                } finally {
                    try { mmr.release() } catch (e: Exception) { }
                }
            }
            if (bmp == null) {
                art = null
                artColor = Color(fallback)
            } else {
                art = bmp.asImageBitmap()
                val rgb = withContext(Dispatchers.Default) {
                    val p = Palette.from(bmp).generate()
                    p.getDarkVibrantColor(p.getDominantColor(fallback))
                }
                artColor = Color(rgb)
            }
        }
    }

    private fun loadEq(): List<Int> {
        val l = (prefs.getString("eq", "") ?: "").split(",").mapNotNull { it.toIntOrNull() }
        return List(5) { l.getOrElse(it) { 0 } }
    }

    fun setEq(levels: List<Int>) {
        eqLevels = levels
        prefs.edit().putString("eq", levels.joinToString(",")).apply()
    }

    fun updateMinSec(v: Int) {
        minSec = v
        prefs.edit().putInt("minSec", v).apply()
        load()
    }

    fun updateBright(v: Float) {
        bgBright = v
        prefs.edit().putFloat("bgBright", v).apply()
    }

    fun updateBlur(v: Float) {
        bgBlur = v
        prefs.edit().putFloat("bgBlur", v).apply()
    }

    private fun bgFile() = File(getApplication<Application>().filesDir, "bg.jpg")

    private fun decodeBg(f: File): ImageBitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / s > 1600) s *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = s }
        return BitmapFactory.decodeFile(f.path, opts)?.asImageBitmap()
    }

    private fun loadBg(): ImageBitmap? = bgFile().takeIf { it.exists() }?.let { decodeBg(it) }

    fun setBgFromUri(uri: Uri) {
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                val f = bgFile()
                getApplication<Application>().contentResolver.openInputStream(uri)?.use { i ->
                    f.outputStream().use { o -> i.copyTo(o) }
                }
                decodeBg(f)
            }
            bg = bmp
        }
    }

    fun clearBg() {
        bgFile().delete()
        bg = null
    }

    fun startSleep(minutes: Int) {
        cancelSleep()
        sleepJob = viewModelScope.launch {
            sleepLeft = minutes * 60L
            while (sleepLeft > 0) {
                delay(1000)
                sleepLeft--
            }
            val c = controller
            if (c != null) {
                for (i in 10 downTo 1) {
                    c.volume = i / 10f
                    delay(500)
                }
                c.pause()
                c.volume = 1f
            }
        }
    }

    fun sleepAfterSong() {
        cancelSleep()
        sleepEndOfSong = true
    }

    fun cancelSleep() {
        sleepJob?.cancel()
        sleepLeft = 0L
        sleepEndOfSong = false
    }

    fun toggle() {
        controller?.let { if (it.isPlaying) it.pause() else it.play() }
    }

    fun next() { controller?.seekToNextMediaItem() }

    fun prev() { controller?.seekToPreviousMediaItem() }

    fun seek(ms: Long) {
        controller?.seekTo(ms)
        position = ms
    }

    private fun Song.toItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist(artist).build())
        .build()
}

object Spectrum {
    var bands by mutableStateOf(FloatArray(32))
}

private val SURAHS = listOf(
    "الفاتحة",
    "البقرة",
    "آل عمران",
    "النساء",
    "المائدة",
    "الأنعام",
    "الأعراف",
    "الأنفال",
    "التوبة",
    "يونس",
    "هود",
    "يوسف",
    "الرعد",
    "إبراهيم",
    "الحجر",
    "النحل",
    "الإسراء",
    "الكهف",
    "مريم",
    "طه",
    "الأنبياء",
    "الحج",
    "المؤمنون",
    "النور",
    "الفرقان",
    "الشعراء",
    "النمل",
    "القصص",
    "العنكبوت",
    "الروم",
    "لقمان",
    "السجدة",
    "الأحزاب",
    "سبأ",
    "فاطر",
    "يس",
    "الصافات",
    "ص",
    "الزمر",
    "غافر",
    "فصلت",
    "الشورى",
    "الزخرف",
    "الدخان",
    "الجاثية",
    "الأحقاف",
    "محمد",
    "الفتح",
    "الحجرات",
    "ق",
    "الذاريات",
    "الطور",
    "النجم",
    "القمر",
    "الرحمن",
    "الواقعة",
    "الحديد",
    "المجادلة",
    "الحشر",
    "الممتحنة",
    "الصف",
    "الجمعة",
    "المنافقون",
    "التغابن",
    "الطلاق",
    "التحريم",
    "الملك",
    "القلم",
    "الحاقة",
    "المعارج",
    "نوح",
    "الجن",
    "المزمل",
    "المدثر",
    "القيامة",
    "الإنسان",
    "المرسلات",
    "النبأ",
    "النازعات",
    "عبس",
    "التكوير",
    "الانفطار",
    "المطففين",
    "الانشقاق",
    "البروج",
    "الطارق",
    "الأعلى",
    "الغاشية",
    "الفجر",
    "البلد",
    "الشمس",
    "الليل",
    "الضحى",
    "الشرح",
    "التين",
    "العلق",
    "القدر",
    "البينة",
    "الزلزلة",
    "العاديات",
    "القارعة",
    "التكاثر",
    "العصر",
    "الهمزة",
    "الفيل",
    "قريش",
    "الماعون",
    "الكوثر",
    "الكافرون",
    "النصر",
    "المسد",
    "الإخلاص",
    "الفلق",
    "الناس"
)

val MoodNames = listOf("هادئ", "حزين", "حماس", "تركيز", "نوم")

val EqPresets = listOf(
    "عادي" to listOf(0, 0, 0, 0, 0),
    "جهير" to listOf(700, 500, 0, -100, 0),
    "صوت بشري" to listOf(-300, 0, 400, 500, 200),
    "راب" to listOf(600, 400, 0, 300, 400),
    "هادئ" to listOf(200, 200, 0, -200, -300)
)

private val DEFAULT_MOODS: Map<String, Set<String>> = mapOf(
    "هادئ" to setOf("قرآن", "أدعية", "موسيقى", "شعر"),
    "حزين" to setOf("موال", "حسينيات", "شعر"),
    "حماس" to setOf("راب"),
    "تركيز" to setOf("موسيقى", "قرآن"),
    "نوم" to setOf("قرآن", "أدعية")
)

private val SPEECH_CATS = setOf("قرآن", "أدعية", "شعر", "حسينيات")
